% Script to compare the intensity of tau in the proximal, mid, and distal
% axon. Uses paired points to compare trends


%D. Beaudet, Hendricks lab, 02/26/2024
close all, clear all, warning off, set(0,'DefaultFigureWindowStyle','docked');

datdir = ('/Volumes/ROG/Tau_intensity_data/');

files_coord = dir(fullfile(datdir, 'WTtau.xlsx'));
coords = readmatrix(fullfile(datdir,files_coord.name));
WT_ratio = [coords(:,4),coords(:,9),coords(:,14)];
clear files_coord coords
WT_ratio(WT_ratio<1.09)=NaN;

files_coord = dir(fullfile(datdir, 'APtau.xlsx'));
coords = readmatrix(fullfile(datdir,files_coord.name));
AP_ratio = [coords(:,4),coords(:,9),coords(:,14)];
clear files_coord coords
AP_ratio(AP_ratio<1.09)=NaN;

files_coord = dir(fullfile(datdir, 'E14tau.xlsx'));
coords = readmatrix(fullfile(datdir,files_coord.name));
E14_ratio = [coords(:,4),coords(:,9),coords(:,14)];
clear files_coord coords
E14_ratio(E14_ratio<1.09)=NaN;


for lg=1:length(WT_ratio)
    if isnan(WT_ratio(lg,2))
        Delta_Int_WT(lg,:)= nansum(diff([WT_ratio(lg,1),WT_ratio(lg,3)]));
    else
        Delta_Int_WT(lg,:)= nansum(diff(WT_ratio(lg,:)));
    end
end

for lg=1:length(AP_ratio)
    if isnan(AP_ratio(lg,2))
        Delta_Int_AP(lg,:)= nansum(diff([AP_ratio(lg,1),AP_ratio(lg,3)]));
    else
        Delta_Int_AP(lg,:)= nansum(diff(AP_ratio(lg,:)));
    end
end

for lg=1:length(E14_ratio)
    if isnan(E14_ratio(lg,2))
        Delta_Int_E14(lg,:)= nansum(diff([E14_ratio(lg,1),E14_ratio(lg,3)]));
    else
        Delta_Int_E14(lg,:)= nansum(diff(E14_ratio(lg,:)));
    end
end


red=[0.6350 0.0780 0.1840]; blue=[0 0.2470 0.4410];
col_wt= [];
for lc=1:length(Delta_Int_WT)
    if Delta_Int_WT(lc,:)>=0
        col_wt(lc,:)=red;
    else
        col_wt(lc,:)=blue;
    end
end
       
col_ap= [];
for lc=1:length(Delta_Int_AP)
    if Delta_Int_AP(lc,:)>=0
        col_ap(lc,:)=red;
    else
        col_ap(lc,:)=blue;
    end
end

col_e14= [];
for lc=1:length(Delta_Int_E14)
    if Delta_Int_E14(lc,:)>=0
        col_e14(lc,:)=red;
    else
        col_e14(lc,:)=blue;
    end
end

% check id difference between proximal to mid and mid to distal have
% significantly different values
Means_WT_ratio = nanmean(WT_ratio, 1);
Means_AP_ratio = nanmean(AP_ratio, 1); 
Means_E14_ratio = nanmean(E14_ratio, 1); 
std_WT_ratio = nanstd(WT_ratio, 0, 1);
std_AP_ratio = nanstd(AP_ratio, 0, 1); 
std_E14_ratio = nanstd(E14_ratio, 0, 1); 

%wt
WT_prox_mid_diff= WT_ratio(:,2)- WT_ratio(:,1);
WT_prox_mid_diff_isnan= WT_prox_mid_diff(~isnan(WT_prox_mid_diff));

WT_mid_dist_diff= WT_ratio(:,3)- WT_ratio(:,2);
WT_mid_dist_diff_isnan= WT_mid_dist_diff(~isnan(WT_mid_dist_diff));

WT_prox_dist_diff= WT_ratio(:,3)- WT_ratio(:,1);
WT_prox_dist_diff_isnan= WT_prox_dist_diff(~isnan(WT_prox_dist_diff));

WT_ratio_prox_mid=[WT_ratio(:,1),WT_ratio(:,2)];


[p_val_WT_ratio_prox_mid,h]=signrank(WT_ratio(:,1),WT_ratio(:,2));
[p_val_WT_ratio_prox_dist,h]=signrank(WT_ratio(:,1),WT_ratio(:,3));
[p_val_WT_ratio_mid_dist,h]=signrank(WT_ratio(:,2),WT_ratio(:,3));

%ap
AP_prox_mid_diff= AP_ratio(:,2)- AP_ratio(:,1);
AP_prox_mid_diff_isnan= AP_prox_mid_diff(~isnan(AP_prox_mid_diff));

AP_mid_dist_diff= AP_ratio(:,3)- AP_ratio(:,2);
AP_mid_dist_diff_isnan= AP_mid_dist_diff(~isnan(AP_mid_dist_diff));

AP_prox_dist_diff= AP_ratio(:,3)- AP_ratio(:,1);
AP_prox_dist_diff_isnan= AP_prox_dist_diff(~isnan(AP_prox_dist_diff));

[p_val_AP_ratio_prox_mid,h]=signrank(AP_ratio(:,1),AP_ratio(:,2));
[p_val_AP_ratio_prox_dist,h]=signrank(AP_ratio(:,1),AP_ratio(:,3));
[p_val_AP_ratio_mid_dist,h]=signrank(AP_ratio(:,2),AP_ratio(:,3));


%e14
E14_prox_mid_diff= E14_ratio(:,2)- E14_ratio(:,1);
E14_prox_mid_diff_isnan= E14_prox_mid_diff(~isnan(E14_prox_mid_diff));

E14_mid_dist_diff= E14_ratio(:,3)- E14_ratio(:,2);
E14_mid_dist_diff_isnan= E14_mid_dist_diff(~isnan(E14_mid_dist_diff));

E14_prox_dist_diff= E14_ratio(:,3)- E14_ratio(:,1);
E14_prox_dist_diff_isnan= E14_prox_dist_diff(~isnan(E14_prox_dist_diff));


[p_val_E14_ratio_prox_mid,h]=signrank(E14_ratio(:,1),E14_ratio(:,2));
[p_val_E14_ratio_prox_dist,h]=signrank(E14_ratio(:,1),E14_ratio(:,3));
[p_val_E14_ratio_mid_dist,h]=signrank(E14_ratio(:,2),E14_ratio(:,3));



x=[1,2,3];
%% Plot
figure(1);
%h1=boxplot(WT_ratio); hold on,
h1=notBoxPlot(WT_ratio);hold on,
box on;
%    xlim([0 4]);
%   ylim([0 15]);
   xlim([0 4]);
   ylim([0 60]);
   set(gca, 'YScale', 'log')
% barHandle = bar(Means_WT_ratio, 'FaceColor', [0.2 0.6 0.5]); % Customize color
% hold on;

% Add error bars
% numCols = size(Means_WT_ratio, 2);
% x = 1:numCols;
% errorbar(x, Means_WT_ratio, std_WT_ratio, 'k.', 'LineWidth', 1.5);

% figure(11);
for n=1:length(WT_ratio)
    WTRR=WT_ratio(n,:);
plot(x(isfinite(WT_ratio(n,:))),WTRR(isfinite(WT_ratio(n,:))),'Color', col_wt(n,:),'linewidth',2,...
  'Marker', '.', 'MarkerSize', 20); 
   hold on,
end
%  xlim([0 4]);
%  ylim([0 1.4]);
%   set(gca, 'YScale', 'log')


 
figure(2);
% h1=boxplot(AP_ratio); hold on,
 h1=notBoxPlot(AP_ratio);hold on,
% 
 box on;
% %  xlim([0 4]);
% %  ylim([0 15]);
   xlim([0 4]);
   ylim([0 60]);
  set(gca, 'YScale', 'log')
% barHandle = bar(Means_AP_ratio, 'FaceColor', [0.2 0.6 0.5]); % Customize color
hold on;

% Add error bars
% numCols = size(Means_AP_ratio, 2);
% x = 1:numCols;
% errorbar(x, Means_AP_ratio, std_AP_ratio, 'k.', 'LineWidth', 1.5);

% figure(22);
for n=1:length(AP_ratio)
    APRR=AP_ratio(n,:);
plot(x(isfinite(AP_ratio(n,:))),APRR(isfinite(AP_ratio(n,:))),'Color', col_ap(n,:),'linewidth',2,...
  'Marker', '.', 'MarkerSize', 20); 
   hold on,
end
%   xlim([0 4]);
%   ylim([0 1.4]);
% set(gca, 'YScale', 'log')

  
  
figure(3);
 %h1=boxplot(E14_ratio);hold on,
h1=notBoxPlot(E14_ratio);hold on,

box on;
%   xlim([0 4]);
%  ylim([0 15]);
   xlim([0 4]);
   ylim([0 60]);
%   set(gca, 'YScale', 'log')
% barHandle = bar(Means_E14_ratio, 'FaceColor', [0.2 0.6 0.5]); % Customize color
% hold on;

% Add error bars
% numCols = size(Means_E14_ratio, 2);
% x = 1:numCols;
% errorbar(x, Means_E14_ratio, std_E14_ratio, 'k.', 'LineWidth', 1.5);

 
% figure(33);
for n=1:length(E14_ratio)
    E14RR=E14_ratio(n,:);
plot(x(isfinite(E14_ratio(n,:))),E14RR(isfinite(E14_ratio(n,:))),'Color', col_e14(n,:),'linewidth',2,...
  'Marker', '.', 'MarkerSize', 20); 
   hold on,
end

% set(gca, 'YScale', 'log')
 
%  xlim([0 4]);
%  ylim([0 1.4]);

