
%% Script to measure the size and intensity of tau patches along MTs
%% Compares phospho-resistive tau to phosphomimetic tau and WT tau
%% Part Deux,

%% Beaudet, D., Hendricks Lab 11/06/23.


clear all, close all
set(0,'DefaultFigureWindowStyle','docked')
addpath('/Users/danielbeaudet/Desktop/MATLAB-Codes_My versions/');
 addpath('/Users/danielbeaudet/Desktop/Abdullah-codes-master-2/General codes/');
chos= [10,11,12]; %WT, AP, E14



for k_choose = chos
c=0;d=0;
       
       if k_choose==10 % WT tau all regions
         cd('/Volumes/ROG/WT_tau_patches_cropped/WT_tau_patches_cropped_all_regions/');
         matFiles= dir('*.mat');
         
        for k = 1 : length(matFiles)
            thisFileName = fullfile(pwd, matFiles(k).name); 
            Dat= load(thisFileName);
            DatALL_WT_allReg{k}=Dat;
        end
        clear Dat
        
               for nc=1:length(DatALL_WT_allReg)
                   
               AxontotalLength_WTar= sum(DatALL_WT_allReg{1, nc}.Axonlength_WT);
                   
               BG_Int_WTar(:,nc) = DatALL_WT_allReg{1, nc}.meanCoordsBG_WT;   
               PatchWidth_WTar{nc} = DatALL_WT_allReg{1, nc}.patchWidth_WT'; 
               Patch_int_WTar{nc} =  DatALL_WT_allReg{1, nc}.PatchInt_WT';
               BtwPatch_int_WTar{nc} =  DatALL_WT_allReg{1, nc}.btwPatchInt_WT';

               PatchFrequency_WT_allar{nc}= DatALL_WT_allReg{1, nc}.numPatches_WT./DatALL_WT_allReg{1, nc}.MTlength_WT;
               PatchFrequency_WTar= cell2mat(PatchFrequency_WT_allar); % frequency of tau patches (um^-1)
               MEanIntWTtau_allar{nc} = DatALL_WT_allReg{1, nc}.meanInt_WT./BG_Int_WTar(nc);
               Fract_WTtauar= cell2mat(MEanIntWTtau_allar); %fraction of tau on MT / in solution
               FractPatchWidth_WT_allar{nc}= DatALL_WT_allReg{1, nc}.sumPatchLength_WT./DatALL_WT_allReg{1, nc}.MTlength_WT;
               FractPatchWidth_WTar= cell2mat(FractPatchWidth_WT_allar); %fraction of microtubule covered by tau
               PatchWid_WT_allar  = cat(1,PatchWidth_WTar{:}); %all patch widths (um)
               meanInt_WT_allar{nc} = (DatALL_WT_allReg{1, nc}.meanInt_WT'); %all mean patch intensities
               MEANint_WT_allar= cat(1,meanInt_WT_allar{:});
                 
               PatchInt_WT_allar = cat(1,Patch_int_WTar{:}); % Mean Intensity of all patches
               BtwPatchInt_WT_allar = cat(1,BtwPatch_int_WTar{:}); % mean intensity of all areas between patches             
               Frac_Int_WTar{nc} = mean(Patch_int_WTar{nc})./mean(BtwPatch_int_WTar{nc});
               fracInt_WTar = cell2mat(Frac_Int_WTar);
               end
               
        elseif k_choose==11 % AP tau all regions
         cd('/Volumes/ROG/AP_tau_patches_cropped/AP_tau_patches_cropped_all_regions/');
         matFiles= dir('*.mat');

        for k = 1 : length(matFiles)
            thisFileName = fullfile(pwd, matFiles(k).name); 
            Dat= load(thisFileName);
            DatALL_AP_allReg{k}=Dat;
        end
        clear Dat
        
               for nc=1:length(DatALL_AP_allReg)
                   
               AxontotalLength_APar= sum(DatALL_AP_allReg{1, nc}.Axonlength_AP);
                   
               BG_Int_APar(:,nc) = DatALL_AP_allReg{1, nc}.meanCoordsBG_AP;   
               PatchWidth_APar{nc} = DatALL_AP_allReg{1, nc}.patchWidth_AP'; 
               Patch_int_APar{nc} =  DatALL_AP_allReg{1, nc}.PatchInt_AP';
               BtwPatch_int_APar{nc} =  DatALL_AP_allReg{1, nc}.btwPatchInt_AP';

               PatchFrequency_AP_allar{nc}= DatALL_AP_allReg{1, nc}.numPatches_AP./DatALL_AP_allReg{1, nc}.MTlength_AP;
               PatchFrequency_APar= cell2mat(PatchFrequency_AP_allar); % frequency of tau patches (um^-1)
               MEanIntAPtau_allar{nc} = DatALL_AP_allReg{1, nc}.meanInt_AP./BG_Int_APar(nc);
               Fract_APtauar= cell2mat(MEanIntAPtau_allar); %fraction of tau on MT / in solution
               FractPatchWidth_AP_allar{nc}= DatALL_AP_allReg{1, nc}.sumPatchLength_AP./DatALL_AP_allReg{1, nc}.MTlength_AP;
               FractPatchWidth_APar= cell2mat(FractPatchWidth_AP_allar); %fraction of microtubule covered by tau
               PatchWid_AP_allar  = cat(1,PatchWidth_APar{:}); %all patch widths (um)
               meanInt_AP_allar{nc} = (DatALL_AP_allReg{1, nc}.meanInt_AP'); %all mean patch intensities
               MEANint_AP_allar= cat(1,meanInt_AP_allar{:});
                 
               PatchInt_AP_allar = cat(1,Patch_int_APar{:}); % Mean Intensity of all patches
               BtwPatchInt_AP_allar = cat(1,BtwPatch_int_APar{:}); % mean intensity of all areas between patches             
               Frac_Int_APar{nc} = mean(Patch_int_APar{nc})./mean(BtwPatch_int_APar{nc});
               fracInt_APar = cell2mat(Frac_Int_APar);
               end
               
               
         elseif k_choose==12 % E14 tau all regions
         cd('/Volumes/ROG/E14_tau_patches_cropped_v2/E14_tau_patches_cropped_all_regions/');
         matFiles= dir('*.mat');

        for k = 1 : length(matFiles)
            thisFileName = fullfile(pwd, matFiles(k).name); 
            Dat= load(thisFileName);
            DatALL_E14_allReg{k}=Dat;
        end
        clear Dat
        
               for nc=1:length(DatALL_E14_allReg)
                   
               AxontotalLength_E14ar= sum(DatALL_E14_allReg{1, nc}.Axonlength_E14);
                   
               BG_Int_E14ar(:,nc) = DatALL_E14_allReg{1, nc}.meanCoordsBG_E14;   
               PatchWidth_E14ar{nc} = DatALL_E14_allReg{1, nc}.patchWidth_E14'; 
               Patch_int_E14ar{nc} =  DatALL_E14_allReg{1, nc}.PatchInt_E14';
               BtwPatch_int_E14ar{nc} =  DatALL_E14_allReg{1, nc}.btwPatchInt_E14';

               PatchFrequency_E14_allar{nc}= DatALL_E14_allReg{1, nc}.numPatches_E14./DatALL_E14_allReg{1, nc}.MTlength_E14;
               PatchFrequency_E14ar= cell2mat(PatchFrequency_E14_allar); % frequency of tau patches (um^-1)
               MEanIntE14tau_allar{nc} = DatALL_E14_allReg{1, nc}.meanInt_E14./BG_Int_E14ar(nc);
               Fract_E14tauar= cell2mat(MEanIntE14tau_allar); %fraction of tau on MT / in solution
               FractPatchWidth_E14_allar{nc}= DatALL_E14_allReg{1, nc}.sumPatchLength_E14./DatALL_E14_allReg{1, nc}.MTlength_E14;
               FractPatchWidth_E14ar= cell2mat(FractPatchWidth_E14_allar); %fraction of microtubule covered by tau
               PatchWid_E14_allar  = cat(1,PatchWidth_E14ar{:}); %all patch widths (um)
               meanInt_E14_allar{nc} = (DatALL_E14_allReg{1, nc}.meanInt_E14'); %all mean patch intensities
               MEANint_E14_allar= cat(1,meanInt_E14_allar{:});
                 
               PatchInt_E14_allar = cat(1,Patch_int_E14ar{:}); % Mean Intensity of all patches
               BtwPatchInt_E14_allar = cat(1,BtwPatch_int_E14ar{:}); % mean intensity of all areas between patches             
               Frac_Int_E14ar{nc} = mean(Patch_int_E14ar{nc})./mean(BtwPatch_int_E14ar{nc});
               fracInt_E14ar = cell2mat(Frac_Int_E14ar);
               end

    end

end 

%% Patch width- Find peak intensity of tau and measure width at half max 
kcol_grey=[0.1,0.1,0.1];
   
   %% patch frequency


nboot=10000;


[bci_wtar,bsums_wtar] = bootci(nboot,{@mean,PatchFrequency_WTar},'alpha',.05,'type','per');
bci_wtar=bci_wtar';
bmu_wtar = mean(bsums_wtar);

[bci_apar,bsums_apar] = bootci(nboot,{@mean,PatchFrequency_APar},'alpha',.05,'type','per');
bci_apar=bci_apar';
bmu_apar = mean(bsums_apar);

[bci_e14ar,bsums_e14ar] = bootci(nboot,{@mean,PatchFrequency_E14ar},'alpha',.05,'type','per');
bci_e14ar=bci_e14ar';
bmu_e14ar = mean(bsums_e14ar);



    figure(4), hold on,
    subplot(2,2,1)
 
    
     WTbarar  = bar(11 , bmu_wtar,'facealpha',0.9); hold on,
    errorbar(11, bmu_wtar, bci_wtar(1)-bmu_wtar,bci_wtar(2)-bmu_wtar, 'Color','k'); hold on,
    hold on,
    APbarar  = bar(12 , bmu_apar,'facealpha',0.3); 
    errorbar(12, bmu_apar, bci_apar(1)-bmu_apar,bci_apar(2)-bmu_apar, 'Color','k'); hold on,
    hold on,
    E14barar = bar(13 , bmu_e14ar,'facealpha',0.3); 
    errorbar(13, bmu_e14ar, bci_e14ar(1)-bmu_e14ar, bci_e14ar(2)-bmu_e14ar, 'Color','k'); hold on,
    hold on,
 
ylabel('Frequency of tau patch um^-1'); 
xticks([11,12,13]); set(gca,'xticklabel',{'WT','AP','E14'});

 WTbarar.FaceColor= 'k';
 APbarar.FaceColor= 'g';
 E14barar.FaceColor= 'b';
hold on,


    
    %% total tau patch length along microtubule
    
clear bci_wtar bsums_wtar bmu_wtar bci_apar bsums_apar bmu_apar bci_e14ar bsums_e14ar bmu_e14ar



[bci_wtar,bsums_wtar] = bootci(nboot,{@mean,FractPatchWidth_WTar},'alpha',.1,'type','per');
bci_wtar=bci_wtar';
bmu_wtar = mean(bsums_wtar);

[bci_apar,bsums_apar] = bootci(nboot,{@mean,FractPatchWidth_APar},'alpha',.1,'type','per');
bci_apar=bci_apar';
bmu_apar = mean(bsums_apar);

[bci_e14ar,bsums_e14ar] = bootci(nboot,{@mean,FractPatchWidth_E14ar},'alpha',.1,'type','per');
bci_e14ar=bci_e14ar';
bmu_e14ar = mean(bsums_e14ar);

    figure(6), hold on
       subplot(2,2,1) % measures total patch width over total cropped image
      
    WTbarar  = bar(11 , bmu_wtar*100,'facealpha',0.9); hold on,
    errorbar(11, bmu_wtar*100, (bci_wtar(1)-bmu_wtar)*100, (bci_wtar(2)-bmu_wtar)*100, 'Color','k'); hold on,
    APbarar  = bar(12 , bmu_apar*100,'facealpha',0.3); hold on,
    errorbar(12, bmu_apar*100, (bci_apar(1)-bmu_apar)*100, (bci_apar(2)-bmu_apar)*100, 'Color','k'); hold on,   
    E14barar = bar(13 , bmu_e14ar*100,'facealpha',0.3);hold on,
    errorbar(13, bmu_e14ar*100, (bci_e14ar(1)-bmu_e14ar)*100, (bci_e14ar(2)-bmu_e14ar)*100, 'Color','k'); hold on,
    
    
       ylabel('percentage of linescans covered by tau patch');
xticks([11,12,13]); set(gca,'xticklabel',{'WT','AP','E14'});

WTbarar.FaceColor= 'k';
APbarar.FaceColor= 'g';
E14barar.FaceColor= 'b';


 

%% total patch length over total axon length
% bootstrap to find sum of patches./ total length

clear bci_wtar bsums_wtar bmu_wtar bci_apar bsums_apar bmu_apar bci_e14ar bsums_e14ar bmu_e14ar



[bci_wtar,bsums_wtar] = bootci(nboot,{@sum,PatchWid_WT_allar},'alpha',.1,'type','per');
bsums_wtar=bsums_wtar./AxontotalLength_WTar;
bci_wtar=bci_wtar./AxontotalLength_WTar';
bmu_wtar = mean(bsums_wtar);
% 
[bci_apar,bsums_apar] = bootci(nboot,{@sum,PatchWid_AP_allar},'alpha',.1,'type','per');
bsums_apar=bsums_apar./AxontotalLength_APar;
bci_apar=bci_apar./AxontotalLength_APar';
bmu_apar = mean(bsums_apar);

[bci_e14ar,bsums_e14ar] = bootci(nboot,{@sum,PatchWid_E14_allar},'alpha',.1,'type','per');
bsums_e14ar=bsums_e14ar./AxontotalLength_E14ar;
bci_e14ar=bci_e14ar./AxontotalLength_E14ar';
bmu_e14ar = mean(bsums_e14ar);





%% Mean Patch width

clear bci_wtar bsums_wtar bmu_wtar bci_apar bsums_apar bmu_apar bci_e14ar bsums_e14ar bmu_e14ar


[bci_wtar,bsums_wtar] = bootci(nboot,{@mean,PatchWid_WT_allar},'alpha',.1,'type','per');
bci_wtar=bci_wtar';
bmu_wtar = mean(bsums_wtar);

[bci_apar,bsums_apar] = bootci(nboot,{@mean,PatchWid_AP_allar},'alpha',.1,'type','per');
bci_apar=bci_apar';
bmu_apar = mean(bsums_apar);

if isempty(PatchWid_E14_allar)
    bci_e14ar=[0,0]; bsums_e14ar=0;
    bmu_e14ar=0;
else
[bci_e14ar,bsums_e14ar] = bootci(nboot,{@mean,PatchWid_E14_allar},'alpha',.1,'type','per');
bci_e14ar=bci_e14ar';
bmu_e14ar = mean(bsums_e14ar);
end




figure(7), subplot(2,2,1),
  
    
    WTbarar  = bar(11 , bmu_wtar,'facealpha',0.9); hold on,
    errorbar(11, bmu_wtar, bci_wtar(1)-bmu_wtar, bci_wtar(2)-bmu_wtar, 'Color','k'); hold on,
    
    APbarar  = bar(12 , bmu_apar,'facealpha',0.3); hold on,
    errorbar(12, bmu_apar, bci_apar(1)-bmu_apar, bci_apar(2)-bmu_apar, 'Color','k'); hold on,
    
    E14barar = bar(13 , bmu_e14ar,'facealpha',0.3);hold on,
    errorbar(13, bmu_e14ar, bci_e14ar(1)-bmu_e14ar, bci_e14ar(2)-bmu_e14ar, 'Color','k'); hold on,
    
    
        ylabel('mean patch width (um)');
        title('mean width of tau patches in axon');

xticks([11,12,13]); set(gca,'xticklabel',{'WT','AP','E14'});

WTbarar.FaceColor= 'k';
APbarar.FaceColor= 'g';
E14barar.FaceColor= 'b';


clear bci_wtar bsums_wtar bmu_wtar bci_apar bsums_apar bmu_apar bci_e14ar bsums_e14ar bmu_e14ar





%% Mean patch Intensity vs. Mean Intensity btw patches

clear bci_wtar bsums_wtar bmu_wtar bci_apar bsums_apar bmu_apar bci_e14ar bsums_e14ar bmu_e14ar




[bci_wtPIar,bsums_wtPIar] = bootci(nboot,{@mean,PatchInt_WT_allar},'alpha',.01,'type','per');
[bci_wtBIar,bsums_wtBIar] = bootci(nboot,{@mean,BtwPatchInt_WT_allar},'alpha',.01,'type','per');
fract_wt_PoBar= bsums_wtPIar./bsums_wtBIar;
[bci_wtPoBar,bsums_wtPoBar] = bootci(nboot,{@mean,fract_wt_PoBar},'alpha',.01,'type','per');
bci_wtPoBar=bci_wtPoBar';
bmu_wtPIar = mean(bsums_wtPoBar);


[bci_apPIar,bsums_apPIar] = bootci(nboot,{@mean,PatchInt_AP_allar},'alpha',.01,'type','per');
[bci_apBIar,bsums_apBIar] = bootci(nboot,{@mean,BtwPatchInt_AP_allar},'alpha',.01,'type','per');
fract_ap_PoBar= bsums_apPIar./bsums_apBIar;
[bci_apPoBar,bsums_apPoBar] = bootci(nboot,{@mean,fract_ap_PoBar},'alpha',.01,'type','per');
bci_apPoBar=bci_apPoBar';
bmu_apPIar = mean(bsums_apPoBar);


[bci_ePIar,bsums_ePIar] = bootci(nboot,{@mean,PatchInt_E14_allar},'alpha',.01,'type','per');
[bci_eBIar,bsums_eBIar] = bootci(nboot,{@mean,BtwPatchInt_E14_allar},'alpha',.01,'type','per');
fract_e_PoBar= bsums_ePIar./bsums_eBIar;
[bci_ePoBar,bsums_ePoBar] = bootci(nboot,{@mean,fract_e_PoBar},'alpha',.01,'type','per');
bci_ePoBar=bci_ePoBar';
bmu_ePIar = mean(bsums_ePoBar);


   figure(8),
     subplot(2,2,1)
    
      WTbarar  = bar(11 , bmu_wtPIar,'facealpha',0.9); hold on,
      errorbar(11, bmu_wtPIar, bci_wtPoBar(1)-bmu_wtPIar, bci_wtPoBar(2)-bmu_wtPIar, 'Color','k'); hold on,

      APbarar  = bar(12 , bmu_apPIar,'facealpha',0.3); hold on,
      errorbar(12, bmu_apPIar, bci_apPoBar(1)-bmu_apPIar, bci_apPoBar(2)-bmu_apPIar, 'Color','k'); hold on,
    
      E14barar  = bar(13 , bmu_ePIar,'facealpha',0.3); hold on,
      errorbar(13, bmu_ePIar, bci_ePoBar(1)-bmu_ePIar, bci_ePoBar(2)-bmu_ePIar, 'Color','k'); hold on,
    
        ylabel('mean tau in patches / mean tau between patches');
ylim([1 1.4]);
xticks([11,12,13]); set(gca,'xticklabel',{'WT','AP','E14'});

WTbarar.FaceColor= 'k';
APbarar.FaceColor= 'g';
E14barar.FaceColor= 'b';


