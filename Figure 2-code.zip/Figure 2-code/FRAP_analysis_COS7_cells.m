%% MATLAB script that performs FRAP analysis

% D. Beaudet, Hendricks Lab, 2025

% input normalized data obtained from FIJI (Stower FRAP assessment), calculate the average, plot with
% STDev error bars, fit- single exp, comapre WT, AP, E14, assess difference in tau

clear all, close all
set(0,'DefaultFigureWindowStyle','docked')
addpath('/Users/danielbeaudet/Desktop/MATLAB-Codes_My versions/');

 mdGrey=[0.5 0.5 0.5];

chos= [1,2,3];%,4,5]; %WT, AP, E14

save_dir = ('/Volumes/ROG/FRAP_analysis/');

for choose = chos
    
    if choose==1
      datdir = ('/Volumes/ROG/FRAP_analysis/');
      frap_data = dir(fullfile(datdir, 'Plot_Values_WT*.csv')); 

            % reads .csv files of tau intensity and BG profiles
            Int_WT = readmatrix(fullfile(datdir,frap_data.name));      
    end
    
    if choose==2
      datdir = ('/Volumes/ROG/FRAP_analysis/');
      frap_data = dir(fullfile(datdir, 'Plot_Values_AP*.csv')); 

            % reads .csv files of tau intensity and BG profiles
            Int_AP = readmatrix(fullfile(datdir,frap_data.name));      
    end
    
    if choose==3
      datdir = ('/Volumes/ROG/FRAP_analysis/');
      frap_data = dir(fullfile(datdir, 'Plot_Values_E14*.csv')); 

            % reads .csv files of tau intensity and BG profiles
            Int_E14 = readmatrix(fullfile(datdir,frap_data.name));      
    end
       
end

[row_avg_WT, row_std_WT]= average_even_columns(Int_WT);
[row_avg_AP, row_std_AP]= average_even_columns(Int_AP);
[row_avg_E14, row_std_E14]= average_even_columns(Int_E14);


frames= [1:1:100]'; frames=frames*0.166;

exp_model = fittype('A*(1-exp(-t/tau))', 'independent','t','coefficients',{'A','tau'});
% exp_model = fittype('A*(1-exp(-tau*t))', 'independent','t','coefficients',{'A','tau'});
exp2_model = fittype('A1*(1-exp(-tau1*t)) + A2*(1-exp(-tau2*t))','independent','t','coefficients',{'A1','tau1','A2','tau2'});

    % Perform the fitting
    fit_result_WT  = fit(frames(5:end),row_avg_WT(5:end),exp_model,'Startpoint',[0.5,0.05],'Lower',[0 0],'Upper',[1 inf]);
    fit_result_AP  = fit(frames(5:end),row_avg_AP(5:end),exp_model,'Startpoint',[0.5,0.05],'Lower',[0 0],'Upper',[1 inf]);
    fit_result_E14  = fit(frames(5:end),row_avg_E14(5:end),exp_model,'Startpoint',[0.5,0.05],'Lower',[0 0],'Upper',[1 inf]);

%  % Perform the fitting
%     fit_result_WT  = fit(frames(5:end),row_avg_WT(5:end),exp2_model,'Startpoint',[0.5 0.05 0.1 0.01],'Lower',[0 0 0 0],'Upper',[1 inf 1 inf]);
%     fit_result_AP  = fit(frames(5:end),row_avg_AP(5:end),exp2_model,'Startpoint',[0.5 0.05 0.1 0.01],'Lower',[0 0 0 0],'Upper',[1 inf 1 inf]);
%     fit_result_E14  = fit(frames(5:end),row_avg_E14(5:end),exp2_model,'Startpoint',[0.5 0.05 0.1 0.01],'Lower',[0 0 0 0],'Upper',[1 inf 1 inf]);


figure(1),hold on, ylim([0 1.1]);
%     plot(frames, row_avg_WT, 'b');%, 'LineWidth', 2);
%     %errorbar(frames, row_avg_WT, row_std_WT,'o');
      patch([frames; flip(frames)], [row_avg_WT-row_std_WT; flip(row_avg_WT+row_std_WT)], 'b', 'FaceAlpha',0.25, 'EdgeColor','none')
     hL=plot(fit_result_WT, frames(5:end), row_avg_WT(5:end),'b.');% 'r-', 'LineWidth', 2); % Fitted curve

%     plot(frames, row_avg_AP, 'g');%, 'LineWidth', 2);
%     %errorbar(frames, row_avg_WT, row_std_WT,'o');
     patch([frames; flip(frames)], [row_avg_AP-row_std_AP; flip(row_avg_AP+row_std_AP)], 'g', 'FaceAlpha',0.25, 'EdgeColor','none')
    hL1=plot(fit_result_AP, frames(5:end), row_avg_AP(5:end),'g.');% 'r-', 'LineWidth', 2); % Fitted curve

% %      plot(frames, row_avg_E14, 'r');%, 'LineWidth', 2);
% %     %errorbar(frames, row_avg_WT, row_std_WT,'o');
      patch([frames; flip(frames)], [row_avg_E14-row_std_E14; flip(row_avg_E14+row_std_E14)], 'r', 'FaceAlpha',0.25, 'EdgeColor','none')
     hL2=plot(fit_result_E14, frames(5:end), row_avg_E14(5:end),'r.');% 'r-', 'LineWidth', 2); % Fitted curve

     hL(1).MarkerSize=12;
     hL1(1).MarkerSize=12;
     hL2(1).MarkerSize=12;

    xlabel('frames');
    ylabel('norm. Int');
    title('FRAP WT tau');
    grid on;

    
    tau_WT= fit_result_WT.tau;% * 0.166;
    tau_AP= fit_result_AP.tau;% * 0.166;
    tau_E14= fit_result_E14.tau;% * 0.166;
    
    imm_WT= fit_result_WT.A;
    imm_AP= fit_result_AP.A;
    imm_E14= fit_result_E14.A;
    
    %%%%%%%%%%%%%%%%%%%%% DO not write anything after functions- end of code
    
    
    
function [row_avg, row_std] = average_even_columns(matrix)
    % Get the indices of even columns
    even_columns = 2:2:size(matrix, 2);
    
    % Extract the even columns from the matrix
    even_column_data = matrix(:, even_columns);
    
    % Compute the row-wise mean
    row_avg = mean(even_column_data, 2);
    
        % Compute the row-wise standard deviation
    row_std = std(even_column_data, 0, 2);
end


