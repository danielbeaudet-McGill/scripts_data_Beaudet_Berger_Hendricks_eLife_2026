
%% Script to measure the size and intensity of tau patches along MTs in vitro
%% Compares phospho-resistive tau to phosphomimetic tau and WT tau
%% Part Deux,

%% Beaudet, D., Hendricks Lab 11/06/23.


clear all, close all
set(0,'DefaultFigureWindowStyle','docked')
addpath('/Users/danielbeaudet/Desktop/MATLAB-Codes_My versions/');

chos= [1,2,3,4,5,6]; %WT, AP, E14



for k_choose = chos
c=0;d=0;
    if k_choose==1 % WT tau
      cd('/Users/danielbeaudet/Desktop/Tau_invitro_patch_data/WT_tau_MTs/');
    matFiles= dir('*.mat');

        for k = 1 : length(matFiles)    
            FileName = fullfile(pwd, matFiles(k).name); 
            Dat= load(FileName);
            DatALL_WT{k}=Dat;       
        end
        clear Dat

            for nc=1:length(DatALL_WT)
               BG_Int_WT(nc) = DatALL_WT{1, nc}.meanCoordsBG_WT;   
               PatchWidth_WT{nc} = DatALL_WT{1, nc}.patchWidth_WT'; 
               Patch_int_WT{nc} =  DatALL_WT{1, nc}.PatchInt_WT';
               BtwPatch_int_WT{nc} =  DatALL_WT{1, nc}.btwPatchInt_WT';

               PatchFrequency_WT_all{nc}= DatALL_WT{1, nc}.numPatches_WT./DatALL_WT{1, nc}.MTlength_WT;
               PatchFrequency_WT= cell2mat(PatchFrequency_WT_all); % frequency of tau patches (um^-1)
               MEanIntWTtau_all{nc} = DatALL_WT{1, nc}.meanInt_WT./BG_Int_WT(nc);
               Fract_WTtau= cell2mat(MEanIntWTtau_all); %fraction of tau on MT / in solution
               FractPatchWidth_WT_all{nc}= DatALL_WT{1, nc}.sumPatchLength_WT./DatALL_WT{1, nc}.MTlength_WT;
               FractPatchWidth_WT= cell2mat(FractPatchWidth_WT_all); %fraction of microtubule covered by tau
                PatchWid_WT_all  = cat(1,PatchWidth_WT{:}); %all patch widths (um)
                 meanInt_WT_all{nc} = (DatALL_WT{1, nc}.meanInt_WT'); %all mean patch intensities
                 MEANint_WT_all= cat(1,meanInt_WT_all{:}); % mean intensity of tau on each MT
                
                 PatchInt_WT_all = cat(1,Patch_int_WT{:}); % Mean Intensity of all patches
                 BtwPatchInt_WT_all = cat(1,BtwPatch_int_WT{:}); % mean intensity of all areas between patches
                 Frac_Int_WT{nc} = mean(Patch_int_WT{nc})./mean(BtwPatch_int_WT{nc});
                 fracInt_WT = cell2mat(Frac_Int_WT);

            end
            

    elseif k_choose==2 % AP tau
      cd('/Users/danielbeaudet/Desktop/Tau_invitro_patch_data/AP_tau_MTs/');

    matFiles= dir('*.mat');

        for k = 1 : length(matFiles)    
            FileName = fullfile(pwd, matFiles(k).name); 
            Dat= load(FileName);
            DatALL_AP{k}=Dat;
        end
        clear Dat
        
               for nc=1:length(DatALL_AP)
               BG_Int_AP(nc) = DatALL_AP{1, nc}.meanCoordsBG_AP;   
               PatchWidth_AP{nc} = DatALL_AP{1, nc}.patchWidth_AP';  
               Patch_int_AP{nc} =  DatALL_AP{1, nc}.PatchInt_AP';
               BtwPatch_int_AP{nc} =  DatALL_AP{1, nc}.btwPatchInt_AP';
  
               PatchFrequency_AP_all{nc}= DatALL_AP{1, nc}.numPatches_AP./DatALL_AP{1, nc}.MTlength_AP;
               PatchFrequency_AP= cell2mat(PatchFrequency_AP_all); % frequency of tau patches (um^-1)
               MEanIntAPtau_all{nc} = DatALL_AP{1, nc}.meanInt_AP./BG_Int_AP(nc);
               Fract_APtau= cell2mat(MEanIntAPtau_all); %fraction of tau on MT / in solution
               FractPatchWidth_AP_all{nc}= DatALL_AP{1, nc}.sumPatchLength_AP./DatALL_AP{1, nc}.MTlength_AP;
               FractPatchWidth_AP= cell2mat(FractPatchWidth_AP_all); %fraction of microtubule covered by tau
               PatchWid_AP_all  = cat(1,PatchWidth_AP{:}); %all patch widths (um)
               meanInt_AP_all{nc} = (DatALL_AP{1, nc}.meanInt_AP'); %all mean patch intensities
               MEANint_AP_all= cat(1,meanInt_AP_all{:});
               
                 PatchInt_AP_all = cat(1,Patch_int_AP{:}); % Mean Intensity of all patches
                 BtwPatchInt_AP_all = cat(1,BtwPatch_int_AP{:}); % mean intensity of all areas between patches
                 Frac_Int_AP{nc} = mean(Patch_int_AP{nc})./mean(BtwPatch_int_AP{nc});
                 fracInt_AP = cell2mat(Frac_Int_AP);

               end


    elseif k_choose==3 % E14 tau
     cd('/Users/danielbeaudet/Desktop/Tau_invitro_patch_data/E14_tau_MTs/');

    matFiles= dir('*.mat');
        for k = 1 : length(matFiles)
            thisFileName = fullfile(pwd, matFiles(k).name); 
            Dat= load(thisFileName);
            DatALL_E14{k}=Dat;
        end
        clear Dat
        
               for nc=1:length(DatALL_E14)
               BG_Int_E14(nc) = DatALL_E14{1, nc}.meanCoordsBG_E14;   
               PatchWidth_E14{nc} = DatALL_E14{1, nc}.patchWidth_E14'; 
               Patch_int_E14{nc} =  DatALL_E14{1, nc}.PatchInt_E14';
               BtwPatch_int_E14{nc} =  DatALL_E14{1, nc}.btwPatchInt_E14';

               PatchFrequency_E14_all{nc}= DatALL_E14{1, nc}.numPatches_E14./DatALL_E14{1, nc}.MTlength_E14;
               PatchFrequency_E14= cell2mat(PatchFrequency_E14_all); % frequency of tau patches (um^-1)
               MEanIntE14tau_all{nc} = DatALL_E14{1, nc}.meanInt_E14./BG_Int_E14(nc);
               Fract_E14tau= cell2mat(MEanIntE14tau_all); %fraction of tau on MT / in solution
               FractPatchWidth_E14_all{nc}= DatALL_E14{1, nc}.sumPatchLength_E14./DatALL_E14{1, nc}.MTlength_E14;
               FractPatchWidth_E14= cell2mat(FractPatchWidth_E14_all); %fraction of microtubule covered by tau
               PatchWid_E14_all  = cat(1,PatchWidth_E14{:}); %all patch widths (um)
               meanInt_E14_all{nc} = (DatALL_E14{1, nc}.meanInt_E14'); %all mean patch intensities
               MEANint_E14_all= cat(1,meanInt_E14_all{:});
                 
               PatchInt_E14_all = cat(1,Patch_int_E14{:}); % Mean Intensity of all patches
               BtwPatchInt_E14_all = cat(1,BtwPatch_int_E14{:}); % mean intensity of all areas between patches             
               Frac_Int_E14{nc} = mean(Patch_int_E14{nc})./mean(BtwPatch_int_E14{nc});
               fracInt_E14 = cell2mat(Frac_Int_E14);
               end
            
    elseif k_choose==4 % WT tau GMPCPP
        cd('/Users/danielbeaudet/Desktop/Tau_invitro_patch_data/WT_tau_GMPCPP/');

    matFiles= dir('*.mat');

        for k = 1 : length(matFiles)    
            FileName = fullfile(pwd, matFiles(k).name); 
            Dat= load(FileName);
            DatALL_WTg{k}=Dat;
        end
        clear Dat

            for nc=1:length(DatALL_WTg)
               BG_Int_WTg(nc) = DatALL_WTg{1, nc}.meanCoordsBG_WT;   
               PatchWidth_WTg{nc} = DatALL_WTg{1, nc}.patchWidth_WT';
               Patch_int_WTg{nc} =  DatALL_WTg{1, nc}.PatchInt_WT';
               BtwPatch_int_WTg{nc} =  DatALL_WTg{1, nc}.btwPatchInt_WT';

               PatchFrequency_WT_allg{nc}= DatALL_WTg{1, nc}.numPatches_WT./DatALL_WTg{1, nc}.MTlength_WT;
               PatchFrequency_WTg= cell2mat(PatchFrequency_WT_allg); % frequency of tau patches (um^-1)
               MEanIntWTtau_allg{nc} = DatALL_WTg{1, nc}.meanInt_WT./BG_Int_WTg(nc);
               Fract_WTtaug= cell2mat(MEanIntWTtau_allg); %fraction of tau on MT / in solution
               FractPatchWidth_WT_allg{nc}= DatALL_WTg{1, nc}.sumPatchLength_WT./DatALL_WTg{1, nc}.MTlength_WT;
               FractPatchWidth_WTg= cell2mat(FractPatchWidth_WT_allg); %fraction of microtubule covered by tau
                PatchWid_WT_allg  = cat(1,PatchWidth_WTg{:}); %all patch widths (um)
                 meanInt_WT_allg{nc} = (DatALL_WTg{1, nc}.meanInt_WT'); %all mean patch intensities
                 MEANint_WT_allg= cat(1,meanInt_WT_allg{:});

                 PatchInt_WT_allg = cat(1,Patch_int_WTg{:}); % Mean Intensity of all patches
                 BtwPatchInt_WT_allg = cat(1,BtwPatch_int_WTg{:}); % mean intensity of all areas between patches
            end

    elseif k_choose==5 % AP tau GMPCPP
        cd('/Users/danielbeaudet/Desktop/Tau_invitro_patch_data/AP_tau_GMPCPP/');

    matFiles= dir('*.mat');

        for k = 1 : length(matFiles)    
            FileName = fullfile(pwd, matFiles(k).name); 
            Dat= load(FileName);
            DatALL_APg{k}=Dat;
        end
        clear Dat
               for nc=1:length(DatALL_APg)
               BG_Int_APg(nc) = DatALL_APg{1, nc}.meanCoordsBG_AP;   
               PatchWidth_APg{nc} = DatALL_APg{1, nc}.patchWidth_AP';  
               Patch_int_APg{nc} =  DatALL_APg{1, nc}.PatchInt_AP';
               BtwPatch_int_APg{nc} =  DatALL_APg{1, nc}.btwPatchInt_AP';
  
               PatchFrequency_AP_allg{nc}= DatALL_APg{1, nc}.numPatches_AP./DatALL_APg{1, nc}.MTlength_AP;
               PatchFrequency_APg= cell2mat(PatchFrequency_AP_allg); % frequency of tau patches (um^-1)
               MEanIntAPtau_allg{nc} = DatALL_APg{1, nc}.meanInt_AP./BG_Int_APg(nc);
               Fract_APtaug= cell2mat(MEanIntAPtau_allg); %fraction of tau on MT / in solution
               FractPatchWidth_AP_allg{nc}= DatALL_APg{1, nc}.sumPatchLength_AP./DatALL_APg{1, nc}.MTlength_AP;
               FractPatchWidth_APg= cell2mat(FractPatchWidth_AP_allg); %fraction of microtubule covered by tau
               PatchWid_AP_allg  = cat(1,PatchWidth_APg{:}); %all patch widths (um)
               meanInt_AP_allg{nc} = (DatALL_APg{1, nc}.meanInt_AP'); %all mean patch intensities
               MEANint_AP_allg= cat(1,meanInt_AP_allg{:});

                 PatchInt_WT_allg = cat(1,Patch_int_APg{:}); % Mean Intensity of all patches
                 BtwPatchInt_WT_allg = cat(1,BtwPatch_int_APg{:}); % mean intensity of all areas between patches               
            end


    elseif k_choose==6 % E14 tau GMPCPP
        cd('/Users/danielbeaudet/Desktop/Tau_invitro_patch_data/E14_tau_GMPCPP/');

    matFiles= dir('*.mat');
        for k = 1 : length(matFiles)
            thisFileName = fullfile(pwd, matFiles(k).name); 
            Dat= load(thisFileName);
            DatALL_E14g{k}=Dat;
        end
        clear Dat
        
               for nc=1:length(DatALL_E14g)
               BG_Int_E14g(nc) = DatALL_E14g{1, nc}.meanCoordsBG_E14;   
               PatchWidth_E14g{nc} = DatALL_E14g{1, nc}.patchWidth_E14';
               Patch_int_E14g{nc} =  DatALL_E14g{1, nc}.PatchInt_E14';
               BtwPatch_int_E14g{nc} =  DatALL_E14g{1, nc}.btwPatchInt_E14';

               PatchFrequency_E14_allg{nc}= DatALL_E14g{1, nc}.numPatches_E14./DatALL_E14g{1, nc}.MTlength_E14;
               PatchFrequency_E14g= cell2mat(PatchFrequency_E14_allg); % frequency of tau patches (um^-1)
               MEanIntE14tau_allg{nc} = DatALL_E14g{1, nc}.meanInt_E14./BG_Int_E14g(nc);
               Fract_E14taug= cell2mat(MEanIntE14tau_allg); %fraction of tau on MT / in solution
               FractPatchWidth_E14_allg{nc}= DatALL_E14g{1, nc}.sumPatchLength_E14./DatALL_E14g{1, nc}.MTlength_E14;
               FractPatchWidth_E14g= cell2mat(FractPatchWidth_E14_allg); %fraction of microtubule covered by tau
               PatchWid_E14_allg  = cat(1,PatchWidth_E14g{:}); %all patch widths (um)
               meanInt_E14_allg{nc} = (DatALL_E14g{1, nc}.meanInt_E14'); %all mean patch intensities
               MEANint_E14_allg= cat(1,meanInt_E14_allg{:});
               
                 PatchInt_E14_allg = cat(1,Patch_int_E14g{:}); % Mean Intensity of all patches
                 BtwPatchInt_E14_allg = cat(1,BtwPatch_int_E14g{:}); % mean intensity of all areas between patches               
            end
    end

end 
    PatchWid_WT_all(PatchWid_WT_all<=0.16)= 0;
    PatchWid_AP_all(PatchWid_AP_all<=0.16)= 0;
    PatchWid_E14_all(PatchWid_E14_all<=0.16)= 0;


    PatchWid_WT_all  = nonzeros(PatchWid_WT_all);
    PatchWid_AP_all  = nonzeros(PatchWid_AP_all);
    PatchWid_E14_all = nonzeros(PatchWid_E14_all);
    
    PatchWid_WT_allg(PatchWid_WT_allg<=0.16)= 0;
    PatchWid_AP_allg(PatchWid_AP_allg<=0.16)= 0;
    PatchWid_E14_allg(PatchWid_E14_allg<=0.16)= 0;


    PatchWid_WT_allg  = nonzeros(PatchWid_WT_allg);
    PatchWid_AP_allg  = nonzeros(PatchWid_AP_allg);
    PatchWid_E14_allg = nonzeros(PatchWid_E14_allg);
    
    
 
    
%% Patch width- Find peak intensity of tau and measure width at half max 
kcol_grey=[0.1,0.1,0.1];
 % Need to count the number of peaks per um microtubule length, the
   % average intensity of tau along the microtubule compared to the average
   % intensity of tau in the environment, the fracrtion of length of tau
   % patches along microtubules per length of microtubule, and ideally the
   % mean patch width on microtubules.
   
   %% patch frequency


nboot=10000;

[bci_wt,bsums_wt] = bootci(nboot,{@mean,PatchFrequency_WT},'alpha',.05,'type','per');
bci_wt=bci_wt';
bmu_wt = mean(bsums_wt);

[bci_ap,bsums_ap] = bootci(nboot,{@mean,PatchFrequency_AP},'alpha',.05,'type','per');
bci_ap=bci_ap';
bmu_ap = mean(bsums_ap);

[bci_e14,bsums_e14] = bootci(nboot,{@mean,PatchFrequency_E14},'alpha',.05,'type','per');
bci_e14=bci_e14';
bmu_e14 = mean(bsums_e14);



[bci_wtg,bsums_wtg] = bootci(nboot,{@mean,PatchFrequency_WTg},'alpha',.05,'type','per');
bci_wtg=bci_wtg';
bmu_wtg = mean(bsums_wtg);

[bci_apg,bsums_apg] = bootci(nboot,{@mean,PatchFrequency_APg},'alpha',.05,'type','per');
bci_apg=bci_apg';
bmu_apg = mean(bsums_apg);

[bci_e14g,bsums_e14g] = bootci(nboot,{@mean,PatchFrequency_E14g},'alpha',.05,'type','per');
bci_e14g=bci_e14g';
bmu_e14g = mean(bsums_e14g);

% ttest for patch frequency
[h,pval_wt_T_pFreq,ci,stats] = ttest2(PatchFrequency_WT,PatchFrequency_WTg);
[h,pval_ap_T_pFreq,ci,stats] = ttest2(PatchFrequency_AP,PatchFrequency_APg);
[h,pval_e14_T_pFreq,ci,stats] = ttest2(PatchFrequency_E14,PatchFrequency_E14g);




    figure(4), hold on,
    subplot(2,2,1)
    WTbar  = bar(1 , bmu_wt,'facealpha',0.9); hold on,
    errorbar(1, bmu_wt, bci_wt(1)-bmu_wt); hold on,
    errorbar(1, bmu_wt, bci_wt(2)-bmu_wt); hold on,
    hold on,
    APbar  = bar(2 , bmu_ap,'facealpha',0.3); 
    errorbar(2, bmu_ap, bci_ap(1)-bmu_ap); hold on,
    errorbar(2, bmu_ap, bci_ap(2)-bmu_ap); hold on,
    hold on,
    
    E14bar = bar(3 , bmu_e14,'facealpha',0.3); 
    errorbar(3, bmu_e14, bci_e14(1)-bmu_e14); hold on,
    errorbar(3, bmu_e14, bci_e14(2)-bmu_e14); hold on,
    hold on,
    
    WTbarg  = bar(4 , bmu_wtg,'facealpha',0.9); hold on,
    errorbar(4, bmu_wtg, bci_wtg(1)-bmu_wtg); hold on,
    errorbar(4, bmu_wtg, bci_wtg(2)-bmu_wtg); hold on,
    hold on,
    APbarg  = bar(5 , bmu_apg,'facealpha',0.3); 
    errorbar(5, bmu_apg, bci_apg(1)-bmu_apg); hold on,
    errorbar(5, bmu_apg, bci_apg(2)-bmu_apg); hold on,
    hold on,
    E14barg = bar(6 , bmu_e14g,'facealpha',0.3); 
    errorbar(6, bmu_e14g, bci_e14g(1)-bmu_e14g); hold on,
    errorbar(6, bmu_e14g, bci_e14g(2)-bmu_e14g); hold on,
    hold on,
 
ylabel('Frequency of tau patch um^-1'); xlabel('Taxol                 GMPCPP');
xticks([1,2,3,4,5,6]); set(gca,'xticklabel',{'WT','AP','E14','WT','AP','E14'});
 WTbar.FaceColor= 'k';
 APbar.FaceColor= 'g';
 E14bar.FaceColor= 'b';
 WTbarg.FaceColor= 'k';
 APbarg.FaceColor= 'g';
 E14barg.FaceColor= 'b';
 
 

 
  nBins= 0:0.05:0.6;
    npPatchFreq_WT  = hist(PatchFrequency_WT, nBins);
    npPatchFreq_AP  = hist(PatchFrequency_AP, nBins);
    npPatchFreq_E14 = hist(PatchFrequency_E14, nBins);

    npPatchFreq_WTg  = hist(PatchFrequency_WTg, nBins);
    npPatchFreq_APg  = hist(PatchFrequency_APg, nBins);
    npPatchFreq_E14g = hist(PatchFrequency_E14g, nBins);


    
    subplot(2,2,2), hold on, 
WTbar  = bar([nBins]',[npPatchFreq_WT./sum(PatchFrequency_WT)]','facealpha', 0.9, 'BarWidth', 1);
hold on,
APbar  = bar([nBins]',[npPatchFreq_AP./sum(PatchFrequency_AP)]','facealpha',0.3, 'BarWidth', 1);
hold on,
E14bar = bar([nBins]',[npPatchFreq_E14./sum(PatchFrequency_E14)]','facealpha',0.3, 'BarWidth', 1);
ylabel('frequency'),xlabel('Patch Frequency (um-1)');
title('Taxol');
WTbar.FaceColor= 'k';
APbar.FaceColor= 'g';
E14bar.FaceColor= 'b';

   subplot(2,2,4), hold on,

WTbarg  = bar([nBins]',[npPatchFreq_WTg./sum(PatchFrequency_WTg)]','facealpha', 0.9, 'BarWidth', 1);
hold on,
APbarg  = bar([nBins]',[npPatchFreq_APg./sum(PatchFrequency_APg)]','facealpha',0.3, 'BarWidth', 1);
hold on,
E14barg = bar([nBins]',[npPatchFreq_E14g./sum(PatchFrequency_E14g)]','facealpha',0.3, 'BarWidth', 1);
title('GMPCPP');
ylabel('frequency'),xlabel('Patch Frequency (um-1)');
WTbarg.FaceColor= 'k';
APbarg.FaceColor= 'g';
E14barg.FaceColor= 'b';

subplot(2,2,3), hold on, 
NBP_WT=notBoxPlot(PatchFrequency_WT,1,'interval','tInterval','style','patch','jitter',0.5);
hold on,
NBP_AP=notBoxPlot(PatchFrequency_AP,2,'interval','tInterval','style','patch','jitter',0.5);
hold on,
NBP_E14=notBoxPlot(PatchFrequency_E14,3,'interval','tInterval','style','patch','jitter',0.5);
 set(NBP_WT.data,'MarkerFaceColor',[0.423 0.43 0.55], 'MarkerSize', 6);
 set(NBP_AP.data,'MarkerFaceColor',[0.3340 0.7690 0.2110], 'MarkerSize', 6);
 set(NBP_E14.data,'MarkerFaceColor',[0.3010 0.7450 0.9330], 'MarkerSize', 6);
 hold on,
 NBP_WTg=notBoxPlot(PatchFrequency_WTg,4,'interval','tInterval','style','patch','jitter',0.5);
hold on,
NBP_APg=notBoxPlot(PatchFrequency_APg,5,'interval','tInterval','style','patch','jitter',0.5);
hold on,
NBP_E14g=notBoxPlot(PatchFrequency_E14g,6,'interval','tInterval','style','patch','jitter',0.5);
 set(NBP_WTg.data,'MarkerFaceColor',[0.423 0.43 0.55], 'MarkerSize', 6);
 set(NBP_APg.data,'MarkerFaceColor',[0.3340 0.7690 0.2110], 'MarkerSize', 6);
 set(NBP_E14g.data,'MarkerFaceColor',[0.3010 0.7450 0.9330], 'MarkerSize', 6);
ylabel('Frequency of tau patch um^-1'); xlabel('Taxol                 GMPCPP');
xticks([1,2,3,4,5,6]); set(gca,'xticklabel',{'WT','AP','E14','WT','AP','E14'});



    %% fraction of tau on and off MT

clear bci_wt bsums_wt bmu_wt bci_ap bsums_ap bmu_ap bci_e14 bsums_e14 bmu_e14
clear bci_wtg bsums_wtg bmu_wtg bci_apg bsums_apg bmu_apg bci_e14g bsums_e14g bmu_e14g

[bci_wt,bsums_wt] = bootci(nboot,{@mean,Fract_WTtau},'alpha',.05,'type','per');
bci_wt=bci_wt';
bmu_wt = mean(bsums_wt);

[bci_ap,bsums_ap] = bootci(nboot,{@mean,Fract_APtau},'alpha',.05,'type','per');
bci_ap=bci_ap';
bmu_ap = mean(bsums_ap);

[bci_e14,bsums_e14] = bootci(nboot,{@mean,Fract_E14tau},'alpha',.05,'type','per');
bci_e14=bci_e14';
bmu_e14 = mean(bsums_e14);


[bci_wtg,bsums_wtg] = bootci(nboot,{@mean,Fract_WTtaug},'alpha',.05,'type','per');
bci_wtg=bci_wtg';
bmu_wtg = mean(bsums_wtg);

[bci_apg,bsums_apg] = bootci(nboot,{@mean,Fract_APtaug},'alpha',.05,'type','per');
bci_apg=bci_apg';
bmu_apg = mean(bsums_apg);

[bci_e14g,bsums_e14g] = bootci(nboot,{@mean,Fract_E14taug},'alpha',.05,'type','per');
bci_e14g=bci_e14g';
bmu_e14g = mean(bsums_e14g);
%% [h,p,ci,stats] = ttest2(x,y)

[h,pval_wt_TG_fI,ci,stats] = ttest2(Fract_WTtau,Fract_WTtaug);
[h,pval_ap_TG_fI,ci,stats] = ttest2(Fract_APtau,Fract_APtaug);
[h,pval_e14_TG_fI,ci,stats] = ttest2(Fract_E14tau,Fract_E14taug);

[h,pval_wt_ap_T_fI,ci,stats] = ttest2(Fract_WTtau,Fract_APtau);
[h,pval_wt_e14_T_fI,ci,stats] = ttest2(Fract_WTtau,Fract_E14tau);

[h,pval_wt_ap_T_fIg,ci,stats] = ttest2(Fract_WTtaug,Fract_APtaug);
[h,pval_wt_e14_T_fIg,ci,stats] = ttest2(Fract_WTtaug,Fract_E14taug);

    
    figure(5), hold on
    subplot(2,2,1)
    WTbar  = bar(1 , bmu_wt,'facealpha',0.9); hold on,
    errorbar(1, bmu_wt, bci_wt(1)-bmu_wt); hold on,
    errorbar(1, bmu_wt, bci_wt(2)-bmu_wt); hold on,
    hold on,
    APbar  = bar(2 , bmu_ap,'facealpha',0.3); hold on,
    errorbar(2, bmu_ap, bci_ap(1)-bmu_ap); hold on,
    errorbar(2, bmu_ap, bci_ap(2)-bmu_ap); hold on,
    hold on,
    E14bar = bar(3 , bmu_e14,'facealpha',0.3);
    errorbar(3, bmu_e14, bci_e14(1)-bmu_e14); hold on,
    errorbar(3, bmu_e14, bci_e14(2)-bmu_e14); hold on,
    hold on,
    
    WTbarg  = bar(4 , bmu_wtg,'facealpha',0.9); hold on,
    errorbar(4, bmu_wtg, bci_wtg(1)-bmu_wtg); hold on,
    errorbar(4, bmu_wtg, bci_wtg(2)-bmu_wtg); hold on,
    hold on,
    APbarg  = bar(5 , bmu_apg,'facealpha',0.3); hold on,
    errorbar(5, bmu_apg, bci_apg(1)-bmu_apg); hold on,
    errorbar(5, bmu_apg, bci_apg(2)-bmu_apg); hold on,
    hold on,
    E14barg = bar(6 , bmu_e14g,'facealpha',0.3);
    errorbar(6, bmu_e14g, bci_e14g(1)-bmu_e14g); hold on,
    errorbar(6, bmu_e14g, bci_e14g(2)-bmu_e14g); hold on,
    hold on,
     ylabel('Mean tau intensity on MT vs. in soln');
   ylim([0.9 2]);
xlabel('Taxol                 GMPCPP');
xticks([1,2,3,4,5,6]); set(gca,'xticklabel',{'WT','AP','E14','WT','AP','E14'});
WTbar.FaceColor= 'k';
APbar.FaceColor= 'g';
E14bar.FaceColor= 'b';

WTbarg.FaceColor= 'k';
APbarg.FaceColor= 'g';
E14barg.FaceColor= 'b';

 



 nBins= 0.5:0.1:5;
    npFract_WT  = hist(Fract_WTtau, nBins);
    npFract_AP  = hist(Fract_APtau, nBins);
    npFract_E14 = hist(Fract_E14tau, nBins);
    
    npFract_WTg  = hist(Fract_WTtaug, nBins);
    npFract_APg  = hist(Fract_APtaug, nBins);
    npFract_E14g = hist(Fract_E14taug, nBins);

    subplot(2,2,2), hold on, 
WTbar  = bar([nBins]',[npFract_WT./sum(npFract_WT)]','facealpha', 0.9, 'BarWidth', 1);
hold on,
APbar  = bar([nBins]',[npFract_AP./sum(npFract_AP)]','facealpha',0.3, 'BarWidth', 1);
hold on,
E14bar = bar([nBins]',[npFract_E14./sum(npFract_E14)]','facealpha',0.3, 'BarWidth', 1);
title('Taxol');
ylabel('frequency'),xlabel('tau intesnity on MT vs. soln');

WTbar.FaceColor= 'k';
APbar.FaceColor= 'g';
E14bar.FaceColor= 'b';


subplot(2,2,4), hold on, 
WTbarg  = bar([nBins]',[npFract_WTg./sum(npFract_WTg)]','facealpha', 0.9, 'BarWidth', 1);
hold on,
APbarg  = bar([nBins]',[npFract_APg./sum(npFract_APg)]','facealpha',0.3, 'BarWidth', 1);
hold on,
E14barg = bar([nBins]',[npFract_E14g./sum(npFract_E14g)]','facealpha',0.3, 'BarWidth', 1);
title('GMPCPP');
ylabel('frequency'),xlabel('tau intesnity on MT vs. soln');

WTbarg.FaceColor= 'k';
APbarg.FaceColor= 'g';
E14barg.FaceColor= 'b';

subplot(2,2,3), hold on, 
NBP_WT=notBoxPlot(Fract_WTtau,1,'interval','tInterval','style','patch','jitter',0.5);
hold on,
NBP_AP=notBoxPlot(Fract_APtau,2,'interval','tInterval','style','patch','jitter',0.5);
hold on,
NBP_E14=notBoxPlot(Fract_E14tau,3,'interval','tInterval','style','patch','jitter',0.5);
hold on,
NBP_WTg=notBoxPlot(Fract_WTtaug,4,'interval','tInterval','style','patch','jitter',0.5);
hold on,
NBP_APg=notBoxPlot(Fract_APtaug,5,'interval','tInterval','style','patch','jitter',0.5);
hold on,
NBP_E14g=notBoxPlot(Fract_E14taug,6,'interval','tInterval','style','patch','jitter',0.5);
 set(NBP_WT.data,'MarkerFaceColor',[0.423 0.43 0.55], 'MarkerSize', 6);
 set(NBP_AP.data,'MarkerFaceColor',[0.3340 0.7690 0.2110], 'MarkerSize', 6);
 set(NBP_E14.data,'MarkerFaceColor',[0.3010 0.7450 0.9330], 'MarkerSize', 6);
set(NBP_WTg.data,'MarkerFaceColor',[0.423 0.43 0.55], 'MarkerSize', 6);
 set(NBP_APg.data,'MarkerFaceColor',[0.3340 0.7690 0.2110], 'MarkerSize', 6);
 set(NBP_E14g.data,'MarkerFaceColor',[0.3010 0.7450 0.9330], 'MarkerSize', 6);

xlabel('Taxol                 GMPCPP');
xticks([1,2,3,4,5,6]); set(gca,'xticklabel',{'WT','AP','E14','WT','AP','E14'});
    
    
    %% total tau patch length along microtubule
    


clear bci_wt bsums_wt bmu_wt bci_ap bsums_ap bmu_ap bci_e14 bsums_e14 bmu_e14

[bci_wt,bsums_wt] = bootci(nboot,{@mean,FractPatchWidth_WT},'alpha',.1,'type','per');
bci_wt=bci_wt';
bmu_wt = mean(bsums_wt);

[bci_ap,bsums_ap] = bootci(nboot,{@mean,FractPatchWidth_AP},'alpha',.1,'type','per');
bci_ap=bci_ap';
bmu_ap = mean(bsums_ap);

[bci_e14,bsums_e14] = bootci(nboot,{@mean,FractPatchWidth_E14},'alpha',.1,'type','per');
bci_e14=bci_e14';
bmu_e14 = mean(bsums_e14);

    figure(6), hold on
       subplot(2,2,1)
    WTbar  = bar(1 , bmu_wt*100,'facealpha',0.9); hold on,
    errorbar(1, bmu_wt*100, (bci_wt(1)-bmu_wt)*100); hold on,
    errorbar(1, bmu_wt*100, (bci_wt(2)-bmu_wt)*100); hold on,
    APbar  = bar(2 , bmu_ap*100,'facealpha',0.3); hold on,
    errorbar(2, bmu_ap*100, (bci_ap(1)-bmu_ap)*100); hold on,
    errorbar(2, bmu_ap*100, (bci_ap(2)-bmu_ap)*100); hold on,
    E14bar = bar(3 , bmu_e14*100,'facealpha',0.3);hold on,
    errorbar(3, bmu_e14*100, (bci_e14(1)-bmu_e14)*100); hold on,
    errorbar(3, bmu_e14*100, (bci_e14(2)-bmu_e14)*100); hold on,
       ylabel('percentage of MT covered by tau patch');

xticks([1,2,3]); set(gca,'xticklabel',{'WT','AP','E14'});
WTbar.FaceColor= 'k';
APbar.FaceColor= 'g';
E14bar.FaceColor= 'b';
%% [h,p,ci,stats] = ttest2(x,y)
% test the percentage covereage of microtubules by patches
[h,pval_wt_ap_Pcov,ci,stats] = ttest2(bsums_wt,bsums_ap);
[h,pval_wt_e14_Pcov,ci,stats] = ttest2(bsums_wt,bsums_e14);



subplot(2,2,3), hold on, 
NBP_WT=notBoxPlot(FractPatchWidth_WT,1,'interval','tInterval','style','patch','jitter',0.5);
hold on,
NBP_AP=notBoxPlot(FractPatchWidth_AP,2,'interval','tInterval','style','patch','jitter',0.5);
hold on,
NBP_E14=notBoxPlot(FractPatchWidth_E14,3,'interval','tInterval','style','patch','jitter',0.5);
 set(NBP_WT.data,'MarkerFaceColor',[0.423 0.43 0.55], 'MarkerSize', 6);
 set(NBP_AP.data,'MarkerFaceColor',[0.3340 0.7690 0.2110], 'MarkerSize', 6);
 set(NBP_E14.data,'MarkerFaceColor',[0.3010 0.7450 0.9330], 'MarkerSize', 6);

 
    %% Mean Patch width


clear bci_wt bsums_wt bmu_wt bci_ap bsums_ap bmu_ap bci_e14 bsums_e14 bmu_e14

[bci_wt,bsums_wt] = bootci(nboot,{@mean,PatchWid_WT_all},'alpha',.1,'type','per');
bci_wt=bci_wt';
bmu_wt = mean(bsums_wt);

[bci_ap,bsums_ap] = bootci(nboot,{@mean,PatchWid_AP_all},'alpha',.1,'type','per');
bci_ap=bci_ap';
bmu_ap = mean(bsums_ap);

if isempty(PatchWid_E14_all)
    bci_e14=[0,0]; bsums_e14=0;
    bmu_e14=0;
else
[bci_e14,bsums_e14] = bootci(nboot,{@mean,PatchWid_E14_all},'alpha',.1,'type','per');
bci_e14=bci_e14';
bmu_e14 = mean(bsums_e14);
end
figure(7), subplot(2,2,1),
      WTbar  = bar(1 , bmu_wt,'facealpha',0.9); hold on,
    errorbar(1, bmu_wt, bci_wt(1)-bmu_wt); hold on,
    errorbar(1, bmu_wt, bci_wt(2)-bmu_wt); hold on,
    APbar  = bar(2 , bmu_ap,'facealpha',0.3); hold on,
    errorbar(2, bmu_ap, bci_ap(1)-bmu_ap); hold on,
    errorbar(2, bmu_ap, bci_ap(2)-bmu_ap); hold on,
    E14bar = bar(3 , bmu_e14,'facealpha',0.3);hold on,
    errorbar(3, bmu_e14, bci_e14(1)-bmu_e14); hold on,
    errorbar(3, bmu_e14, bci_e14(2)-bmu_e14); hold on,
        ylabel('mean patch width (um)');
        title('mean width of tau patches on MTs');

xticks([1,2,3]); set(gca,'xticklabel',{'WT','AP','E14'});
WTbar.FaceColor= 'k';
APbar.FaceColor= 'g';
E14bar.FaceColor= 'b';

cb=0;
pVal_WT_AP= bsums_wt-bsums_ap;
for nf=1:length(pVal_WT_AP)
if pVal_WT_AP(nf)>0
    cb=cb+1;
else 
end
end
pval_Patwid_WT_vs_AP=cb/nboot;

cb=0;
pVal_WT_E14= bsums_wt-bsums_e14;
for nf=1:length(pVal_WT_E14)
if pVal_WT_E14(nf)<0
    cb=cb+1;
else 
end
end
pval_Patwid_WT_vs_E14=cb/nboot;

cb=0;
pVal_AP_E14= bsums_ap-bsums_e14;
for nf=1:length(pVal_AP_E14)
if pVal_AP_E14(nf)<0
    cb=cb+1;
else 
end
end
pval_Patwid_AP_vs_E14=cb/nboot;



nBins= 0:0.5:15;
    npPatchWid_WT  = hist(PatchWid_WT_all, nBins);
    npPatchWid_AP  = hist(PatchWid_AP_all, nBins);
    npPatchWid_E14 = hist(PatchWid_E14_all, nBins);


    
    subplot(2,2,2), hold on, 
WTbar  = bar([nBins]',[npPatchWid_WT./sum(npPatchWid_WT)]','facealpha', 0.9, 'BarWidth', 1);
hold on,
APbar  = bar([nBins]',[npPatchWid_AP./sum(npPatchWid_AP)]','facealpha',0.3, 'BarWidth', 1);
hold on,
E14bar = bar([nBins]',[npPatchWid_E14./sum(npPatchWid_E14)]','facealpha',0.3, 'BarWidth', 1);

ylabel('frequency'),xlabel('Patch width (um)');

WTbar.FaceColor= 'k';
APbar.FaceColor= 'g';
E14bar.FaceColor= 'b';

subplot(2,2,3), hold on, 
NBP_WT=notBoxPlot(PatchWid_WT_all,1,'interval','tInterval','style','patch','jitter',0.5);
hold on,
NBP_AP=notBoxPlot(PatchWid_AP_all,2,'interval','tInterval','style','patch','jitter',0.5);
hold on,
NBP_E14=notBoxPlot(PatchWid_E14_all,3,'interval','tInterval','style','patch','jitter',0.5);
 set(NBP_WT.data,'MarkerFaceColor',[0.423 0.43 0.55], 'MarkerSize', 6);
 set(NBP_AP.data,'MarkerFaceColor',[0.3340 0.7690 0.2110], 'MarkerSize', 6);
 set(NBP_E14.data,'MarkerFaceColor',[0.3010 0.7450 0.9330], 'MarkerSize', 6);



    nBins= 2500:250:15000;
    npMeanInt_WT  = hist(MEANint_WT_all, nBins);
    npMeanInt_AP  = hist(MEANint_AP_all, nBins);
    npMeanInt_E14 = hist(MEANint_E14_all, nBins);

clear bci_wt bsums_wt bmu_wt bci_ap bsums_ap bmu_ap bci_e14 bsums_e14 bmu_e14

[bci_wt,bsums_wt] = bootci(nboot,{@mean,MEANint_WT_all},'alpha',.1,'type','per');
bci_wt=bci_wt';
bmu_wt = mean(bsums_wt);

[bci_ap,bsums_ap] = bootci(nboot,{@mean,MEANint_AP_all},'alpha',.1,'type','per');
bci_ap=bci_ap';
bmu_ap = mean(bsums_ap);

[bci_e14,bsums_e14] = bootci(nboot,{@mean,MEANint_E14_all},'alpha',.1,'type','per');
bci_e14=bci_e14';
bmu_e14 = mean(bsums_e14);



    figure(8),
     subplot(2,2,1)
    WTbar  = bar(1 , bmu_wt,'facealpha',0.9); hold on,
    errorbar(1, bmu_wt, bci_wt(1)-bmu_wt); hold on,
    errorbar(1, bmu_wt, bci_wt(2)-bmu_wt); hold on,
    APbar  = bar(2 , bmu_ap,'facealpha',0.3); hold on,
    errorbar(2, bmu_ap, bci_ap(1)-bmu_ap); hold on,
    errorbar(2, bmu_ap, bci_ap(2)-bmu_ap); hold on,
    E14bar = bar(3 , bmu_e14,'facealpha',0.3);hold on,
    errorbar(3, bmu_e14, bci_e14(1)-bmu_e14); hold on,
    errorbar(3, bmu_e14, bci_e14(2)-bmu_e14); hold on, 
    
    
    
        ylabel('mean tau intensity (a.u.)');

xticks([1,2,3]); set(gca,'xticklabel',{'WT','AP','E14'});
WTbar.FaceColor= 'k';
APbar.FaceColor= 'g';
E14bar.FaceColor= 'b';

    subplot(2,2,2), hold on, 
WTbar  = bar([nBins]',[npMeanInt_WT./sum(npMeanInt_WT)]','facealpha', 0.9, 'BarWidth', 1);
hold on,
APbar  = bar([nBins]',[npMeanInt_AP./sum(npMeanInt_AP)]','facealpha',0.3, 'BarWidth', 1);
hold on,
E14bar = bar([nBins]',[npMeanInt_E14./sum(npMeanInt_E14)]','facealpha',0.3, 'BarWidth', 1);

ylabel('frequency'),xlabel('mean tau intensity');

WTbar.FaceColor= 'k';
APbar.FaceColor= 'g';
E14bar.FaceColor= 'b';



%% Mean patch Intensity vs. Mean Intensity btw patches

clear bci_wt bsums_wt bmu_wt bci_ap bsums_ap bmu_ap bci_e14 bsums_e14 bmu_e14

[bci_wtPI,bsums_wtPI] = bootci(nboot,{@mean,PatchInt_WT_all},'alpha',.1,'type','per');
bci_wtPI=bci_wtPI';
bmu_wtPI = mean(bsums_wtPI);

[bci_apPI,bsums_apPI] = bootci(nboot,{@mean,PatchInt_AP_all},'alpha',.1,'type','per');
bci_apPI=bci_apPI';
bmu_apPI = mean(bsums_apPI);

[bci_e14PI,bsums_e14PI] = bootci(nboot,{@mean,PatchInt_E14_all},'alpha',.1,'type','per');
bci_e14PI=bci_e14PI';
bmu_e14PI = mean(bsums_e14PI);


[bci_wtBI,bsums_wtBI] = bootci(nboot,{@mean,BtwPatchInt_WT_all},'alpha',.1,'type','per');
bci_wtBI=bci_wtBI';
bmu_wtBI = mean(bsums_wtBI);

[bci_apBI,bsums_apBI] = bootci(nboot,{@mean,BtwPatchInt_AP_all},'alpha',.1,'type','per');
bci_apBI=bci_apBI';
bmu_apBI = mean(bsums_apBI);

[bci_e14BI,bsums_e14BI] = bootci(nboot,{@mean,BtwPatchInt_E14_all},'alpha',.1,'type','per');
bci_e14BI=bci_e14BI';
bmu_e14BI = mean(bsums_e14BI);

fr_bmu_wt= mean(bsums_wtPI./bsums_wtBI);
fr_bmu_ap= mean(bsums_apPI./bsums_apBI);
fr_bmu_e14= mean(bsums_e14PI./bsums_e14BI);

fr_wtM= mean(fracInt_WT);
fr_apM= mean(fracInt_AP);
fr_e14M= mean(fracInt_E14);

fr_wtSTD= std(fracInt_WT);
fr_apSTD= std(fracInt_AP);
fr_e14STD= std(fracInt_E14);

%% [h,p,ci,stats] = ttest2(x,y)
% ttest for the intensity of tau in patches vs in gaps
[h,pval_wt_ap_PG,ci,stats] = ttest2(fracInt_WT,fracInt_AP);
[h,pval_wt_e14_PG,ci,stats] = ttest2(fracInt_WT,fracInt_E14);




   figure(8),
     subplot(2,2,3)
    WTbar  = bar(1 , fr_wtM,'facealpha',0.9); hold on,
    errorbar(1, fr_wtM, fr_wtSTD); hold on,
    errorbar(1, fr_wtM, fr_wtSTD); hold on,
    APbar  = bar(2 , fr_apM,'facealpha',0.3); hold on,
    errorbar(2, fr_apM, fr_apSTD); hold on,
    errorbar(2, fr_apM, fr_apSTD); hold on,
    E14bar = bar(3 , fr_e14M,'facealpha',0.3);hold on,
    errorbar(3, fr_e14M, fr_e14STD); hold on,
    errorbar(3, fr_e14M, fr_e14STD); hold on, 
    
    
    
        ylabel('mean tau in patches / mean tau between patches');

xticks([1,2,3]); set(gca,'xticklabel',{'WT','AP','E14'});
WTbar.FaceColor= 'k';
APbar.FaceColor= 'g';
E14bar.FaceColor= 'b';
