%% Overlay data with per cell analysis
clear all; close all; clc; 
set(0,'DefaultFigureWindowStyle','docked');
addpath('/Users/danielbeaudet/Desktop/MATLAB-Codes_My versions/');

% first input total data,
% second, input per cell data,
% addpath('/Users/danielbeaudet/Desktop/');
addpath('/Volumes/ROG/Neurons_KymoButler_data/');
rng(1)
proxColor="#e0f3db";
midColor ="#a8ddb5";
distColor="#43a2ca";

dkBlue=[0 0.2470 0.4410];
lhtBlue=[0.3010 0.7450 0.9330];
Orng=[0.9290 0.6940 0.1250];
dkRed=[0.6350 0.0780 0.1840];
mdGrey=[0.5 0.5 0.5];

load('v2control_734_proximal_percell.mat', 'ba');
ba_ctl_prox= ba;
clear ba;

   load('v2control_734_mid_percell.mat', 'ba');
    ba_ctl_mid= ba;
    clear ba;
    
        load('v2control_734_distal_percell.mat', 'ba');
        ba_ctl_dist= ba;
        clear ba;
          
load('v2control_986_proximal_percell.mat', 'ba');
ba_ctl_prox=horzcat(ba_ctl_prox,ba);
clear ba;

    load('v2control_986_mid_percell.mat', 'ba');
    ba_ctl_mid=horzcat(ba_ctl_mid,ba);
    clear ba;
    
        load('v2control_986_distal_percell.mat', 'ba');
        ba_ctl_dist=horzcat(ba_ctl_dist,ba);
        clear ba;
                                
load('v2MAPTKO_734_proximal_percell.mat', 'ba');
ba_ko_prox=ba;
clear ba;

    load('v2MAPTKO_734_mid_percell.mat', 'ba');
    ba_ko_mid=ba;
    clear ba;
    
        load('v2MAPTKO_734_distal_percell.mat', 'ba');
        ba_ko_dist=ba;
        clear ba;
        
load('v2MAPTKO_986_proximal_percell.mat', 'ba');
ba_ko_prox=horzcat(ba_ko_prox,ba);
clear ba;

    load('v2MAPTKO_986_mid_percell.mat', 'ba');
    ba_ko_mid=horzcat(ba_ko_mid,ba);
    clear ba;
    
        load('v2MAPTKO_986_distal_percell.mat', 'ba');
        ba_ko_dist=horzcat(ba_ko_dist,ba);
        clear ba;
        
load('v2MAPTKO_WTtau_proximal_percell.mat', 'ba');
ba_wt_prox=ba;
clear ab;

    load('v2MAPTKO_WTtau_mid_percell.mat', 'ba');
    ba_wt_mid=ba;
    clear ab;
    
        load('v2MAPTKO_WTtau_distal_percell.mat', 'ba');
        ba_wt_dist=ba;
        clear ba;
        
load('v2MAPTKO_APtau_proximal_percell.mat', 'ba');
ba_ap_prox=ba;
clear ab;

    load('v2MAPTKO_APtau_mid_percell.mat', 'ba');
    ba_ap_mid=ba;
    clear ab;
    
        load('v2MAPTKO_APtau_distal_percell.mat', 'ba');
        ba_ap_dist=ba;
        clear ba;
        
load('v2MAPTKO_E14tau_proximal_percell.mat', 'ba');
ba_e14_prox=ba;
clear ab;

    load('v2MAPTKO_E14tau_mid_percell.mat', 'ba');
    ba_e14_mid=ba;
    clear ab;
    
        load('v2MAPTKO_E14tau_distal_percell.mat', 'ba');
        ba_e14_dist=ba;
        clear ba;        


 load('kymoSumData.mat');


ba_ctl_all = [ba_ctl_prox(:); ba_ctl_mid(:); ba_ctl_dist(:)];
ba_ko_all =  [ba_ko_prox(:); ba_ko_mid(:); ba_ko_dist(:)];
ba_wt_all =  [ba_wt_prox(:); ba_wt_mid(:); ba_wt_dist(:)];
ba_ap_all =  [ba_ap_prox(:); ba_ap_mid(:); ba_ap_dist(:)];
ba_e14_all = [ba_e14_prox(:); ba_e14_mid(:); ba_e14_dist(:)];


%% CTL all data per cell
sum_diff_time_ctl_all= [];%, 'Color', diffColor);
sum_proc_time_ctl_all= [];%, 'Color', procColor);
sum_stat_time_ctl_all= [];%, 'Color', statColor);
  
mean_proc_RL_plus_ctl_all= [];
mean_proc_RL_minus_ctl_all= [];

mean_proc_vel_plus_ctl_all=[];
mean_proc_vel_minus_ctl_all=[];
N_proc_plus_tracks_ctl_all=[];
N_proc_minus_tracks_ctl_all=[];
mean_proc_fracTime_plus_ctl_all=[];
mean_proc_fracTime_minus_ctl_all=[];
mean_revRate_ctl_all=[];

for mn=1:length(ba_ctl_all)

sum_diff_time_ctl_all= [sum_diff_time_ctl_all;(sum(ba_ctl_all(mn).diff_time)./ba_ctl_all(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_ctl_all= [sum_proc_time_ctl_all;(sum(ba_ctl_all(mn).proc_time)./ba_ctl_all(mn).total_time)];%, 'Color', procColor);
sum_stat_time_ctl_all= [sum_stat_time_ctl_all;(sum(ba_ctl_all(mn).stat_time)./ba_ctl_all(mn).total_time)];%, 'Color', statColor);

mean_proc_fracTime_plus_ctl_all= [mean_proc_fracTime_plus_ctl_all; mean(ba_ctl_all(mn).proc_plus_time)./((mean(ba_ctl_all(mn).proc_plus_time)+(mean(ba_ctl_all(mn).proc_minus_time))))];
mean_proc_fracTime_minus_ctl_all= [mean_proc_fracTime_minus_ctl_all; mean(ba_ctl_all(mn).proc_minus_time)./((mean(ba_ctl_all(mn).proc_plus_time)+(mean(ba_ctl_all(mn).proc_minus_time))))];

mean_proc_RL_plus_ctl_all= [mean_proc_RL_plus_ctl_all; mean(ba_ctl_all(mn).proc_plus_pos)];
mean_proc_RL_minus_ctl_all= [mean_proc_RL_minus_ctl_all; mean(ba_ctl_all(mn).proc_minus_pos)];

mean_proc_vel_plus_ctl_all=[mean_proc_vel_plus_ctl_all; mean(ba_ctl_all(mn).proc_plus_vel)];
mean_proc_vel_minus_ctl_all=[mean_proc_vel_minus_ctl_all; mean(ba_ctl_all(mn).proc_minus_vel)];

mean_revRate_ctl_all=[mean_revRate_ctl_all; mean(ba_ctl_all(mn).rev_rate)];


N_proc_plus_tracks_ctl_all=[N_proc_plus_tracks_ctl_all';ba_ctl_all(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_ctl_all=[N_proc_minus_tracks_ctl_all';ba_ctl_all(mn).N_proc_minus_tracks']';
end

%% CTL all data per cell
sum_diff_time_ctl_prox= [];%, 'Color', diffColor);
sum_proc_time_ctl_prox= [];%, 'Color', procColor);
sum_stat_time_ctl_prox= [];%, 'Color', statColor);
  
mean_proc_RL_plus_ctl_prox= [];
mean_proc_RL_minus_ctl_prox= [];

mean_proc_vel_plus_ctl_prox=[];
mean_proc_vel_minus_ctl_prox=[];
N_proc_plus_tracks_ctl_prox=[];
N_proc_minus_tracks_ctl_prox=[];

for mn=1:length(ba_ctl_prox)

sum_diff_time_ctl_prox= [sum_diff_time_ctl_prox;(sum(ba_ctl_prox(mn).diff_time)./ba_ctl_prox(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_ctl_prox= [sum_proc_time_ctl_prox;(sum(ba_ctl_prox(mn).proc_time)./ba_ctl_prox(mn).total_time)];%, 'Color', procColor);
sum_stat_time_ctl_prox= [sum_stat_time_ctl_prox;(sum(ba_ctl_prox(mn).stat_time)./ba_ctl_prox(mn).total_time)];%, 'Color', statColor);


mean_proc_RL_plus_ctl_prox= [mean_proc_RL_plus_ctl_prox; mean(ba_ctl_prox(mn).proc_plus_pos)];
mean_proc_RL_minus_ctl_prox= [mean_proc_RL_minus_ctl_prox; mean(ba_ctl_prox(mn).proc_minus_pos)];

mean_proc_vel_plus_ctl_prox=[mean_proc_vel_plus_ctl_prox; mean(ba_ctl_prox(mn).proc_plus_vel)];
mean_proc_vel_minus_ctl_prox=[mean_proc_vel_minus_ctl_prox; mean(ba_ctl_prox(mn).proc_minus_vel)];

N_proc_plus_tracks_ctl_prox=[N_proc_plus_tracks_ctl_prox';ba_ctl_prox(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_ctl_prox=[N_proc_minus_tracks_ctl_prox';ba_ctl_prox(mn).N_proc_minus_tracks']';
end

%% CTL mid data per cell
sum_diff_time_ctl_mid= [];%, 'Color', diffColor);
sum_proc_time_ctl_mid= [];%, 'Color', procColor);
sum_stat_time_ctl_mid= [];%, 'Color', statColor);
  
mean_proc_RL_plus_ctl_mid= [];
mean_proc_RL_minus_ctl_mid= [];

mean_proc_vel_plus_ctl_mid=[];
mean_proc_vel_minus_ctl_mid=[];
N_proc_plus_tracks_ctl_mid=[];
N_proc_minus_tracks_ctl_mid=[];

for mn=1:length(ba_ctl_mid)

sum_diff_time_ctl_mid= [sum_diff_time_ctl_mid;(sum(ba_ctl_mid(mn).diff_time)./ba_ctl_mid(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_ctl_mid= [sum_proc_time_ctl_mid;(sum(ba_ctl_mid(mn).proc_time)./ba_ctl_mid(mn).total_time)];%, 'Color', procColor);
sum_stat_time_ctl_mid= [sum_stat_time_ctl_mid;(sum(ba_ctl_mid(mn).stat_time)./ba_ctl_mid(mn).total_time)];%, 'Color', statColor);


mean_proc_RL_plus_ctl_mid= [mean_proc_RL_plus_ctl_mid; mean(ba_ctl_mid(mn).proc_plus_pos)];
mean_proc_RL_minus_ctl_mid= [mean_proc_RL_minus_ctl_mid; mean(ba_ctl_mid(mn).proc_minus_pos)];

mean_proc_vel_plus_ctl_mid=[mean_proc_vel_plus_ctl_mid; mean(ba_ctl_mid(mn).proc_plus_vel)];
mean_proc_vel_minus_ctl_mid=[mean_proc_vel_minus_ctl_mid; mean(ba_ctl_mid(mn).proc_minus_vel)];

N_proc_plus_tracks_ctl_mid=[N_proc_plus_tracks_ctl_mid';ba_ctl_mid(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_ctl_mid=[N_proc_minus_tracks_ctl_mid';ba_ctl_mid(mn).N_proc_minus_tracks']';
end


%% CTL dist data per cell
sum_diff_time_ctl_dist= [];%, 'Color', diffColor);
sum_proc_time_ctl_dist= [];%, 'Color', procColor);
sum_stat_time_ctl_dist= [];%, 'Color', statColor);
  
mean_proc_RL_plus_ctl_dist= [];
mean_proc_RL_minus_ctl_dist= [];

mean_proc_vel_plus_ctl_dist=[];
mean_proc_vel_minus_ctl_dist=[];
N_proc_plus_tracks_ctl_dist=[];
N_proc_minus_tracks_ctl_dist=[];

for mn=1:length(ba_ctl_dist)

sum_diff_time_ctl_dist= [sum_diff_time_ctl_dist;(sum(ba_ctl_dist(mn).diff_time)./ba_ctl_dist(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_ctl_dist= [sum_proc_time_ctl_dist;(sum(ba_ctl_dist(mn).proc_time)./ba_ctl_dist(mn).total_time)];%, 'Color', procColor);
sum_stat_time_ctl_dist= [sum_stat_time_ctl_dist;(sum(ba_ctl_dist(mn).stat_time)./ba_ctl_dist(mn).total_time)];%, 'Color', statColor);


mean_proc_RL_plus_ctl_dist= [mean_proc_RL_plus_ctl_dist; mean(ba_ctl_dist(mn).proc_plus_pos)];
mean_proc_RL_minus_ctl_dist= [mean_proc_RL_minus_ctl_dist; mean(ba_ctl_dist(mn).proc_minus_pos)];

mean_proc_vel_plus_ctl_dist=[mean_proc_vel_plus_ctl_dist; mean(ba_ctl_dist(mn).proc_plus_vel)];
mean_proc_vel_minus_ctl_dist=[mean_proc_vel_minus_ctl_dist; mean(ba_ctl_dist(mn).proc_minus_vel)];

N_proc_plus_tracks_ctl_dist=[N_proc_plus_tracks_ctl_dist';ba_ctl_dist(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_ctl_dist=[N_proc_minus_tracks_ctl_dist';ba_ctl_dist(mn).N_proc_minus_tracks']';
end


%% KO all data per cell
sum_diff_time_ko_all= [];%, 'Color', diffColor);
sum_proc_time_ko_all= [];%, 'Color', procColor);
sum_stat_time_ko_all= [];%, 'Color', statColor);
  
mean_proc_RL_plus_ko_all= [];
mean_proc_RL_minus_ko_all= [];

mean_proc_vel_plus_ko_all=[];
mean_proc_vel_minus_ko_all=[];
N_proc_plus_tracks_ko_all=[];
N_proc_minus_tracks_ko_all=[];
mean_proc_fracTime_plus_ko_all= [];
mean_proc_fracTime_minus_ko_all= [];
mean_revRate_ko_all=[];

for mn=1:length(ba_ko_all)

sum_diff_time_ko_all= [sum_diff_time_ko_all;(sum(ba_ko_all(mn).diff_time)./ba_ko_all(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_ko_all= [sum_proc_time_ko_all;(sum(ba_ko_all(mn).proc_time)./ba_ko_all(mn).total_time)];%, 'Color', procColor);
sum_stat_time_ko_all= [sum_stat_time_ko_all;(sum(ba_ko_all(mn).stat_time)./ba_ko_all(mn).total_time)];%, 'Color', statColor);

mean_proc_fracTime_plus_ko_all= [mean_proc_fracTime_plus_ko_all; mean(ba_ko_all(mn).proc_plus_time)./((mean(ba_ko_all(mn).proc_plus_time)+(mean(ba_ko_all(mn).proc_minus_time))))];
mean_proc_fracTime_minus_ko_all= [mean_proc_fracTime_minus_ko_all; mean(ba_ko_all(mn).proc_minus_time)./((mean(ba_ko_all(mn).proc_plus_time)+(mean(ba_ko_all(mn).proc_minus_time))))];

mean_proc_RL_plus_ko_all= [mean_proc_RL_plus_ko_all; mean(ba_ko_all(mn).proc_plus_pos)];
mean_proc_RL_minus_ko_all= [mean_proc_RL_minus_ko_all; mean(ba_ko_all(mn).proc_minus_pos)];

mean_proc_vel_plus_ko_all=[mean_proc_vel_plus_ko_all; mean(ba_ko_all(mn).proc_plus_vel)];
mean_proc_vel_minus_ko_all=[mean_proc_vel_minus_ko_all; mean(ba_ko_all(mn).proc_minus_vel)];

mean_revRate_ko_all=[mean_revRate_ko_all; mean(ba_ko_all(mn).rev_rate)];

N_proc_plus_tracks_ko_all=[N_proc_plus_tracks_ko_all';ba_ko_all(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_ko_all=[N_proc_minus_tracks_ko_all';ba_ko_all(mn).N_proc_minus_tracks']';
end

%% KO prox data per cell
sum_diff_time_ko_prox= [];%, 'Color', diffColor);
sum_proc_time_ko_prox= [];%, 'Color', procColor);
sum_stat_time_ko_prox= [];%, 'Color', statColor);
  
mean_proc_RL_plus_ko_prox= [];
mean_proc_RL_minus_ko_prox= [];

mean_proc_vel_plus_ko_prox=[];
mean_proc_vel_minus_ko_prox=[];
N_proc_plus_tracks_ko_prox=[];
N_proc_minus_tracks_ko_prox=[];

for mn=1:length(ba_ko_prox)

sum_diff_time_ko_prox= [sum_diff_time_ko_prox;(sum(ba_ko_prox(mn).diff_time)./ba_ko_prox(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_ko_prox= [sum_proc_time_ko_prox;(sum(ba_ko_prox(mn).proc_time)./ba_ko_prox(mn).total_time)];%, 'Color', procColor);
sum_stat_time_ko_prox= [sum_stat_time_ko_prox;(sum(ba_ko_prox(mn).stat_time)./ba_ko_prox(mn).total_time)];%, 'Color', statColor);


mean_proc_RL_plus_ko_prox= [mean_proc_RL_plus_ko_prox; mean(ba_ko_prox(mn).proc_plus_pos)];
mean_proc_RL_minus_ko_prox= [mean_proc_RL_minus_ko_prox; mean(ba_ko_prox(mn).proc_minus_pos)];

mean_proc_vel_plus_ko_prox=[mean_proc_vel_plus_ko_prox; mean(ba_ko_prox(mn).proc_plus_vel)];
mean_proc_vel_minus_ko_prox=[mean_proc_vel_minus_ko_prox; mean(ba_ko_prox(mn).proc_minus_vel)];

N_proc_plus_tracks_ko_prox=[N_proc_plus_tracks_ko_prox';ba_ko_prox(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_ko_prox=[N_proc_minus_tracks_ko_prox';ba_ko_prox(mn).N_proc_minus_tracks']';
end

%% KO mid data per cell
sum_diff_time_ko_mid= [];%, 'Color', diffColor);
sum_proc_time_ko_mid= [];%, 'Color', procColor);
sum_stat_time_ko_mid= [];%, 'Color', statColor);
  
mean_proc_RL_plus_ko_mid= [];
mean_proc_RL_minus_ko_mid= [];

mean_proc_vel_plus_ko_mid=[];
mean_proc_vel_minus_ko_mid=[];
N_proc_plus_tracks_ko_mid=[];
N_proc_minus_tracks_ko_mid=[];

for mn=1:length(ba_ko_mid)

sum_diff_time_ko_mid= [sum_diff_time_ko_mid;(sum(ba_ko_mid(mn).diff_time)./ba_ko_mid(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_ko_mid= [sum_proc_time_ko_mid;(sum(ba_ko_mid(mn).proc_time)./ba_ko_mid(mn).total_time)];%, 'Color', procColor);
sum_stat_time_ko_mid= [sum_stat_time_ko_mid;(sum(ba_ko_mid(mn).stat_time)./ba_ko_mid(mn).total_time)];%, 'Color', statColor);


mean_proc_RL_plus_ko_mid= [mean_proc_RL_plus_ko_mid; mean(ba_ko_mid(mn).proc_plus_pos)];
mean_proc_RL_minus_ko_mid= [mean_proc_RL_minus_ko_mid; mean(ba_ko_mid(mn).proc_minus_pos)];

mean_proc_vel_plus_ko_mid=[mean_proc_vel_plus_ko_mid; mean(ba_ko_mid(mn).proc_plus_vel)];
mean_proc_vel_minus_ko_mid=[mean_proc_vel_minus_ko_mid; mean(ba_ko_mid(mn).proc_minus_vel)];

N_proc_plus_tracks_ko_mid=[N_proc_plus_tracks_ko_mid';ba_ko_mid(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_ko_mid=[N_proc_minus_tracks_ko_mid';ba_ko_mid(mn).N_proc_minus_tracks']';
end


%% KO dist data per cell
sum_diff_time_ko_dist= [];%, 'Color', diffColor);
sum_proc_time_ko_dist= [];%, 'Color', procColor);
sum_stat_time_ko_dist= [];%, 'Color', statColor);
  
mean_proc_RL_plus_ko_dist= [];
mean_proc_RL_minus_ko_dist= [];

mean_proc_vel_plus_ko_dist=[];
mean_proc_vel_minus_ko_dist=[];
N_proc_plus_tracks_ko_dist=[];
N_proc_minus_tracks_ko_dist=[];

for mn=1:length(ba_ko_dist)

sum_diff_time_ko_dist= [sum_diff_time_ko_dist;(sum(ba_ko_dist(mn).diff_time)./ba_ko_dist(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_ko_dist= [sum_proc_time_ko_dist;(sum(ba_ko_dist(mn).proc_time)./ba_ko_dist(mn).total_time)];%, 'Color', procColor);
sum_stat_time_ko_dist= [sum_stat_time_ko_dist;(sum(ba_ko_dist(mn).stat_time)./ba_ko_dist(mn).total_time)];%, 'Color', statColor);


mean_proc_RL_plus_ko_dist= [mean_proc_RL_plus_ko_dist; mean(ba_ko_dist(mn).proc_plus_pos)];
mean_proc_RL_minus_ko_dist= [mean_proc_RL_minus_ko_dist; mean(ba_ko_dist(mn).proc_minus_pos)];

mean_proc_vel_plus_ko_dist=[mean_proc_vel_plus_ko_dist; mean(ba_ko_dist(mn).proc_plus_vel)];
mean_proc_vel_minus_ko_dist=[mean_proc_vel_minus_ko_dist; mean(ba_ko_dist(mn).proc_minus_vel)];

N_proc_plus_tracks_ko_dist=[N_proc_plus_tracks_ko_dist';ba_ko_dist(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_ko_dist=[N_proc_minus_tracks_ko_dist';ba_ko_dist(mn).N_proc_minus_tracks']';
end


%% WT all data per cell
sum_diff_time_wt_all= [];%, 'Color', diffColor);
sum_proc_time_wt_all= [];%, 'Color', procColor);
sum_stat_time_wt_all= [];%, 'Color', statColor);
  
mean_proc_RL_plus_wt_all= [];
mean_proc_RL_minus_wt_all= [];

mean_proc_vel_plus_wt_all=[];
mean_proc_vel_minus_wt_all=[];
N_proc_plus_tracks_wt_all=[];
N_proc_minus_tracks_wt_all=[];
mean_proc_fracTime_plus_wt_all= [];
mean_proc_fracTime_minus_wt_all= [];

mean_revRate_wt_all=[];

for mn=1:length(ba_wt_all)

sum_diff_time_wt_all= [sum_diff_time_wt_all;(sum(ba_wt_all(mn).diff_time)./ba_wt_all(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_wt_all= [sum_proc_time_wt_all;(sum(ba_wt_all(mn).proc_time)./ba_wt_all(mn).total_time)];%, 'Color', procColor);
sum_stat_time_wt_all= [sum_stat_time_wt_all;(sum(ba_wt_all(mn).stat_time)./ba_wt_all(mn).total_time)];%, 'Color', statColor);

mean_proc_fracTime_plus_wt_all= [mean_proc_fracTime_plus_wt_all; mean(ba_wt_all(mn).proc_plus_time)./((mean(ba_wt_all(mn).proc_plus_time)+(mean(ba_wt_all(mn).proc_minus_time))))];
mean_proc_fracTime_minus_wt_all= [mean_proc_fracTime_minus_wt_all; mean(ba_wt_all(mn).proc_minus_time)./((mean(ba_wt_all(mn).proc_plus_time)+(mean(ba_wt_all(mn).proc_minus_time))))];

mean_proc_RL_plus_wt_all= [mean_proc_RL_plus_wt_all; mean(ba_wt_all(mn).proc_plus_pos)];
mean_proc_RL_minus_wt_all= [mean_proc_RL_minus_wt_all; mean(ba_wt_all(mn).proc_minus_pos)];

mean_proc_vel_plus_wt_all=[mean_proc_vel_plus_wt_all; mean(ba_wt_all(mn).proc_plus_vel)];
mean_proc_vel_minus_wt_all=[mean_proc_vel_minus_wt_all; mean(ba_wt_all(mn).proc_minus_vel)];

mean_revRate_wt_all=[mean_revRate_wt_all; mean(ba_wt_all(mn).rev_rate)];


N_proc_plus_tracks_wt_all=[N_proc_plus_tracks_wt_all';ba_wt_all(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_wt_all=[N_proc_minus_tracks_wt_all';ba_wt_all(mn).N_proc_minus_tracks']';
end

%% WT prox data per cell
sum_diff_time_wt_prox= [];%, 'Color', diffColor);
sum_proc_time_wt_prox= [];%, 'Color', procColor);
sum_stat_time_wt_prox= [];%, 'Color', statColor);
  
mean_proc_RL_plus_wt_prox= [];
mean_proc_RL_minus_wt_prox= [];

mean_proc_vel_plus_wt_prox=[];
mean_proc_vel_minus_wt_prox=[];
N_proc_plus_tracks_wt_prox=[];
N_proc_minus_tracks_wt_prox=[];

for mn=1:length(ba_wt_prox)

sum_diff_time_wt_prox= [sum_diff_time_wt_prox;(sum(ba_wt_prox(mn).diff_time)./ba_wt_prox(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_wt_prox= [sum_proc_time_wt_prox;(sum(ba_wt_prox(mn).proc_time)./ba_wt_prox(mn).total_time)];%, 'Color', procColor);
sum_stat_time_wt_prox= [sum_stat_time_wt_prox;(sum(ba_wt_prox(mn).stat_time)./ba_wt_prox(mn).total_time)];%, 'Color', statColor);


mean_proc_RL_plus_wt_prox= [mean_proc_RL_plus_wt_prox; mean(ba_wt_prox(mn).proc_plus_pos)];
mean_proc_RL_minus_wt_prox= [mean_proc_RL_minus_wt_prox; mean(ba_wt_prox(mn).proc_minus_pos)];

mean_proc_vel_plus_wt_prox=[mean_proc_vel_plus_wt_prox; mean(ba_wt_prox(mn).proc_plus_vel)];
mean_proc_vel_minus_wt_prox=[mean_proc_vel_minus_wt_prox; mean(ba_wt_prox(mn).proc_minus_vel)];

N_proc_plus_tracks_wt_prox=[N_proc_plus_tracks_wt_prox';ba_wt_prox(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_wt_prox=[N_proc_minus_tracks_wt_prox';ba_wt_prox(mn).N_proc_minus_tracks']';
end

%% WT mid data per cell
sum_diff_time_wt_mid= [];%, 'Color', diffColor);
sum_proc_time_wt_mid= [];%, 'Color', procColor);
sum_stat_time_wt_mid= [];%, 'Color', statColor);
  
mean_proc_RL_plus_wt_mid= [];
mean_proc_RL_minus_wt_mid= [];

mean_proc_vel_plus_wt_mid=[];
mean_proc_vel_minus_wt_mid=[];
N_proc_plus_tracks_wt_mid=[];
N_proc_minus_tracks_wt_mid=[];

for mn=1:length(ba_wt_mid)

sum_diff_time_wt_mid= [sum_diff_time_wt_mid;(sum(ba_wt_mid(mn).diff_time)./ba_wt_mid(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_wt_mid= [sum_proc_time_wt_mid;(sum(ba_wt_mid(mn).proc_time)./ba_wt_mid(mn).total_time)];%, 'Color', procColor);
sum_stat_time_wt_mid= [sum_stat_time_wt_mid;(sum(ba_wt_mid(mn).stat_time)./ba_wt_mid(mn).total_time)];%, 'Color', statColor);

mean_proc_RL_plus_wt_mid= [mean_proc_RL_plus_wt_mid; mean(ba_wt_mid(mn).proc_plus_pos)];
mean_proc_RL_minus_wt_mid= [mean_proc_RL_minus_wt_mid; mean(ba_wt_mid(mn).proc_minus_pos)];

mean_proc_vel_plus_wt_mid=[mean_proc_vel_plus_wt_mid; mean(ba_wt_mid(mn).proc_plus_vel)];
mean_proc_vel_minus_wt_mid=[mean_proc_vel_minus_wt_mid; mean(ba_wt_mid(mn).proc_minus_vel)];

N_proc_plus_tracks_wt_mid=[N_proc_plus_tracks_wt_mid';ba_wt_mid(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_wt_mid=[N_proc_minus_tracks_wt_mid';ba_wt_mid(mn).N_proc_minus_tracks']';
end

%% WT dist data per cell
sum_diff_time_wt_dist= [];%, 'Color', diffColor);
sum_proc_time_wt_dist= [];%, 'Color', procColor);
sum_stat_time_wt_dist= [];%, 'Color', statColor);
  
mean_proc_RL_plus_wt_dist= [];
mean_proc_RL_minus_wt_dist= [];

mean_proc_vel_plus_wt_dist=[];
mean_proc_vel_minus_wt_dist=[];
N_proc_plus_tracks_wt_dist=[];
N_proc_minus_tracks_wt_dist=[];

for mn=1:length(ba_wt_dist)

sum_diff_time_wt_dist= [sum_diff_time_wt_dist;(sum(ba_wt_dist(mn).diff_time)./ba_wt_dist(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_wt_dist= [sum_proc_time_wt_dist;(sum(ba_wt_dist(mn).proc_time)./ba_wt_dist(mn).total_time)];%, 'Color', procColor);
sum_stat_time_wt_dist= [sum_stat_time_wt_dist;(sum(ba_wt_dist(mn).stat_time)./ba_wt_dist(mn).total_time)];%, 'Color', statColor);

mean_proc_RL_plus_wt_dist= [mean_proc_RL_plus_wt_dist; mean(ba_wt_dist(mn).proc_plus_pos)];
mean_proc_RL_minus_wt_dist= [mean_proc_RL_minus_wt_dist; mean(ba_wt_dist(mn).proc_minus_pos)];

mean_proc_vel_plus_wt_dist=[mean_proc_vel_plus_wt_dist; mean(ba_wt_dist(mn).proc_plus_vel)];
mean_proc_vel_minus_wt_dist=[mean_proc_vel_minus_wt_dist; mean(ba_wt_dist(mn).proc_minus_vel)];

N_proc_plus_tracks_wt_dist=[N_proc_plus_tracks_wt_dist';ba_wt_dist(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_wt_dist=[N_proc_minus_tracks_wt_dist';ba_wt_dist(mn).N_proc_minus_tracks']';
end


%% AP all data per cell
sum_diff_time_ap_all= [];%, 'Color', diffColor);
sum_proc_time_ap_all= [];%, 'Color', procColor);
sum_stat_time_ap_all= [];%, 'Color', statColor);
  
mean_proc_RL_plus_ap_all= [];
mean_proc_RL_minus_ap_all= [];

mean_proc_vel_plus_ap_all=[];
mean_proc_vel_minus_ap_all=[];
N_proc_plus_tracks_ap_all=[];
N_proc_minus_tracks_ap_all=[];
mean_proc_fracTime_plus_ap_all= [];
mean_proc_fracTime_minus_ap_all= [];

mean_revRate_ap_all=[];

for mn=1:length(ba_ap_all)

sum_diff_time_ap_all= [sum_diff_time_ap_all;(sum(ba_ap_all(mn).diff_time)./ba_ap_all(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_ap_all= [sum_proc_time_ap_all;(sum(ba_ap_all(mn).proc_time)./ba_ap_all(mn).total_time)];%, 'Color', procColor);
sum_stat_time_ap_all= [sum_stat_time_ap_all;(sum(ba_ap_all(mn).stat_time)./ba_ap_all(mn).total_time)];%, 'Color', statColor);

mean_proc_fracTime_plus_ap_all= [mean_proc_fracTime_plus_ap_all; mean(ba_ap_all(mn).proc_plus_time)./((mean(ba_ap_all(mn).proc_plus_time)+(mean(ba_ap_all(mn).proc_minus_time))))];
mean_proc_fracTime_minus_ap_all= [mean_proc_fracTime_minus_ap_all; mean(ba_ap_all(mn).proc_minus_time)./((mean(ba_ap_all(mn).proc_plus_time)+(mean(ba_ap_all(mn).proc_minus_time))))];

mean_proc_RL_plus_ap_all= [mean_proc_RL_plus_ap_all; mean(ba_ap_all(mn).proc_plus_pos)];
mean_proc_RL_minus_ap_all= [mean_proc_RL_minus_ap_all; mean(ba_ap_all(mn).proc_minus_pos)];

mean_proc_vel_plus_ap_all=[mean_proc_vel_plus_ap_all; mean(ba_ap_all(mn).proc_plus_vel)];
mean_proc_vel_minus_ap_all=[mean_proc_vel_minus_ap_all; mean(ba_ap_all(mn).proc_minus_vel)];

mean_revRate_ap_all=[mean_revRate_ap_all; mean(ba_ap_all(mn).rev_rate)];

N_proc_plus_tracks_ap_all=[N_proc_plus_tracks_ap_all';ba_ap_all(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_ap_all=[N_proc_minus_tracks_ap_all';ba_ap_all(mn).N_proc_minus_tracks']';
end

%% AP prox data per cell
sum_diff_time_ap_prox= [];%, 'Color', diffColor);
sum_proc_time_ap_prox= [];%, 'Color', procColor);
sum_stat_time_ap_prox= [];%, 'Color', statColor);
  
mean_proc_RL_plus_ap_prox= [];
mean_proc_RL_minus_ap_prox= [];

mean_proc_vel_plus_ap_prox=[];
mean_proc_vel_minus_ap_prox=[];
N_proc_plus_tracks_ap_prox=[];
N_proc_minus_tracks_ap_prox=[];

for mn=1:length(ba_ap_prox)

sum_diff_time_ap_prox= [sum_diff_time_ap_prox;(sum(ba_ap_prox(mn).diff_time)./ba_ap_prox(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_ap_prox= [sum_proc_time_ap_prox;(sum(ba_ap_prox(mn).proc_time)./ba_ap_prox(mn).total_time)];%, 'Color', procColor);
sum_stat_time_ap_prox= [sum_stat_time_ap_prox;(sum(ba_ap_prox(mn).stat_time)./ba_ap_prox(mn).total_time)];%, 'Color', statColor);

mean_proc_RL_plus_ap_prox= [mean_proc_RL_plus_ap_prox; mean(ba_ap_prox(mn).proc_plus_pos)];
mean_proc_RL_minus_ap_prox= [mean_proc_RL_minus_ap_prox; mean(ba_ap_prox(mn).proc_minus_pos)];

mean_proc_vel_plus_ap_prox=[mean_proc_vel_plus_ap_prox; mean(ba_ap_prox(mn).proc_plus_vel)];
mean_proc_vel_minus_ap_prox=[mean_proc_vel_minus_ap_prox; mean(ba_ap_prox(mn).proc_minus_vel)];

N_proc_plus_tracks_ap_prox=[N_proc_plus_tracks_ap_prox';ba_ap_prox(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_ap_prox=[N_proc_minus_tracks_ap_prox';ba_ap_prox(mn).N_proc_minus_tracks']';
end

%% AP mid data per cell
sum_diff_time_ap_mid= [];%, 'Color', diffColor);
sum_proc_time_ap_mid= [];%, 'Color', procColor);
sum_stat_time_ap_mid= [];%, 'Color', statColor);
  
mean_proc_RL_plus_ap_mid= [];
mean_proc_RL_minus_ap_mid= [];

mean_proc_vel_plus_ap_mid=[];
mean_proc_vel_minus_ap_mid=[];
N_proc_plus_tracks_ap_mid=[];
N_proc_minus_tracks_ap_mid=[];

for mn=1:length(ba_ap_mid)

sum_diff_time_ap_mid= [sum_diff_time_ap_mid;(sum(ba_ap_mid(mn).diff_time)./ba_ap_mid(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_ap_mid= [sum_proc_time_ap_mid;(sum(ba_ap_mid(mn).proc_time)./ba_ap_mid(mn).total_time)];%, 'Color', procColor);
sum_stat_time_ap_mid= [sum_stat_time_ap_mid;(sum(ba_ap_mid(mn).stat_time)./ba_ap_mid(mn).total_time)];%, 'Color', statColor);

mean_proc_RL_plus_ap_mid= [mean_proc_RL_plus_ap_mid; mean(ba_ap_mid(mn).proc_plus_pos)];
mean_proc_RL_minus_ap_mid= [mean_proc_RL_minus_ap_mid; mean(ba_ap_mid(mn).proc_minus_pos)];

mean_proc_vel_plus_ap_mid=[mean_proc_vel_plus_ap_mid; mean(ba_ap_mid(mn).proc_plus_vel)];
mean_proc_vel_minus_ap_mid=[mean_proc_vel_minus_ap_mid; mean(ba_ap_mid(mn).proc_minus_vel)];

N_proc_plus_tracks_ap_mid=[N_proc_plus_tracks_ap_mid';ba_ap_mid(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_ap_mid=[N_proc_minus_tracks_ap_mid';ba_ap_mid(mn).N_proc_minus_tracks']';
end


%% AP dist data per cell
sum_diff_time_ap_dist= [];%, 'Color', diffColor);
sum_proc_time_ap_dist= [];%, 'Color', procColor);
sum_stat_time_ap_dist= [];%, 'Color', statColor);
  
mean_proc_RL_plus_ap_dist= [];
mean_proc_RL_minus_ap_dist= [];

mean_proc_vel_plus_ap_dist=[];
mean_proc_vel_minus_ap_dist=[];
N_proc_plus_tracks_ap_dist=[];
N_proc_minus_tracks_ap_dist=[];

for mn=1:length(ba_ap_dist)

sum_diff_time_ap_dist= [sum_diff_time_ap_dist;(sum(ba_ap_dist(mn).diff_time)./ba_ap_dist(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_ap_dist= [sum_proc_time_ap_dist;(sum(ba_ap_dist(mn).proc_time)./ba_ap_dist(mn).total_time)];%, 'Color', procColor);
sum_stat_time_ap_dist= [sum_stat_time_ap_dist;(sum(ba_ap_dist(mn).stat_time)./ba_ap_dist(mn).total_time)];%, 'Color', statColor);

mean_proc_RL_plus_ap_dist= [mean_proc_RL_plus_ap_dist; mean(ba_ap_dist(mn).proc_plus_pos)];
mean_proc_RL_minus_ap_dist= [mean_proc_RL_minus_ap_dist; mean(ba_ap_dist(mn).proc_minus_pos)];

mean_proc_vel_plus_ap_dist=[mean_proc_vel_plus_ap_dist; mean(ba_ap_dist(mn).proc_plus_vel)];
mean_proc_vel_minus_ap_dist=[mean_proc_vel_minus_ap_dist; mean(ba_ap_dist(mn).proc_minus_vel)];

N_proc_plus_tracks_ap_dist=[N_proc_plus_tracks_ap_dist';ba_ap_dist(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_ap_dist=[N_proc_minus_tracks_ap_dist';ba_ap_dist(mn).N_proc_minus_tracks']';
end

%% E14 all data per cell
sum_diff_time_e14_all= [];%, 'Color', diffColor);
sum_proc_time_e14_all= [];%, 'Color', procColor);
sum_stat_time_e14_all= [];%, 'Color', statColor);
  
mean_proc_RL_plus_e14_all= [];
mean_proc_RL_minus_e14_all= [];

mean_proc_vel_plus_e14_all=[];
mean_proc_vel_minus_e14_all=[];
N_proc_plus_tracks_e14_all=[];
N_proc_minus_tracks_e14_all=[];
mean_proc_fracTime_plus_e14_all= [];
mean_proc_fracTime_minus_e14_all= [];

mean_revRate_e14_all=[];


for mn=1:length(ba_e14_all)

sum_diff_time_e14_all= [sum_diff_time_e14_all;(sum(ba_e14_all(mn).diff_time)./ba_e14_all(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_e14_all= [sum_proc_time_e14_all;(sum(ba_e14_all(mn).proc_time)./ba_e14_all(mn).total_time)];%, 'Color', procColor);
sum_stat_time_e14_all= [sum_stat_time_e14_all;(sum(ba_e14_all(mn).stat_time)./ba_e14_all(mn).total_time)];%, 'Color', statColor);

mean_proc_fracTime_plus_e14_all= [mean_proc_fracTime_plus_e14_all; mean(ba_e14_all(mn).proc_plus_time)./((mean(ba_e14_all(mn).proc_plus_time)+(mean(ba_e14_all(mn).proc_minus_time))))];
mean_proc_fracTime_minus_e14_all= [mean_proc_fracTime_minus_e14_all; mean(ba_e14_all(mn).proc_minus_time)./((mean(ba_e14_all(mn).proc_plus_time)+(mean(ba_e14_all(mn).proc_minus_time))))];

mean_proc_RL_plus_e14_all= [mean_proc_RL_plus_e14_all; mean(ba_e14_all(mn).proc_plus_pos)];
mean_proc_RL_minus_e14_all= [mean_proc_RL_minus_e14_all; mean(ba_e14_all(mn).proc_minus_pos)];

mean_proc_vel_plus_e14_all=[mean_proc_vel_plus_e14_all; mean(ba_e14_all(mn).proc_plus_vel)];
mean_proc_vel_minus_e14_all=[mean_proc_vel_minus_e14_all; mean(ba_e14_all(mn).proc_minus_vel)];

mean_revRate_e14_all=[mean_revRate_e14_all; mean(ba_e14_all(mn).rev_rate)];

N_proc_plus_tracks_e14_all=[N_proc_plus_tracks_e14_all';ba_e14_all(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_e14_all=[N_proc_minus_tracks_e14_all';ba_e14_all(mn).N_proc_minus_tracks']';
end


%% E14 prox data per cell
sum_diff_time_e_prox= [];%, 'Color', diffColor);
sum_proc_time_e_prox= [];%, 'Color', procColor);
sum_stat_time_e_prox= [];%, 'Color', statColor);
  
mean_proc_RL_plus_e_prox= [];
mean_proc_RL_minus_e_prox= [];

mean_proc_vel_plus_e_prox=[];
mean_proc_vel_minus_e_prox=[];
N_proc_plus_tracks_e_prox=[];
N_proc_minus_tracks_e_prox=[];

for mn=1:length(ba_e14_prox)

sum_diff_time_e_prox= [sum_diff_time_e_prox;(sum(ba_e14_prox(mn).diff_time)./ba_e14_prox(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_e_prox= [sum_proc_time_e_prox;(sum(ba_e14_prox(mn).proc_time)./ba_e14_prox(mn).total_time)];%, 'Color', procColor);
sum_stat_time_e_prox= [sum_stat_time_e_prox;(sum(ba_e14_prox(mn).stat_time)./ba_e14_prox(mn).total_time)];%, 'Color', statColor);

mean_proc_RL_plus_e_prox= [mean_proc_RL_plus_e_prox; mean(ba_e14_prox(mn).proc_plus_pos)];
mean_proc_RL_minus_e_prox= [mean_proc_RL_minus_e_prox; mean(ba_e14_prox(mn).proc_minus_pos)];

mean_proc_vel_plus_e_prox=[mean_proc_vel_plus_e_prox; mean(ba_e14_prox(mn).proc_plus_vel)];
mean_proc_vel_minus_e_prox=[mean_proc_vel_minus_e_prox; mean(ba_e14_prox(mn).proc_minus_vel)];

N_proc_plus_tracks_e_prox=[N_proc_plus_tracks_e_prox';ba_e14_prox(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_e_prox=[N_proc_minus_tracks_e_prox';ba_e14_prox(mn).N_proc_minus_tracks']';
end

%% E14 mid data per cell
sum_diff_time_e_mid= [];%, 'Color', diffColor);
sum_proc_time_e_mid= [];%, 'Color', procColor);
sum_stat_time_e_mid= [];%, 'Color', statColor);
  
mean_proc_RL_plus_e_mid= [];
mean_proc_RL_minus_e_mid= [];

mean_proc_vel_plus_e_mid=[];
mean_proc_vel_minus_e_mid=[];
N_proc_plus_tracks_e_mid=[];
N_proc_minus_tracks_e_mid=[];

for mn=1:length(ba_e14_mid)

sum_diff_time_e_mid= [sum_diff_time_e_mid;(sum(ba_e14_mid(mn).diff_time)./ba_e14_mid(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_e_mid= [sum_proc_time_e_mid;(sum(ba_e14_mid(mn).proc_time)./ba_e14_mid(mn).total_time)];%, 'Color', procColor);
sum_stat_time_e_mid= [sum_stat_time_e_mid;(sum(ba_e14_mid(mn).stat_time)./ba_e14_mid(mn).total_time)];%, 'Color', statColor);

mean_proc_RL_plus_e_mid= [mean_proc_RL_plus_e_mid; mean(ba_e14_mid(mn).proc_plus_pos)];
mean_proc_RL_minus_e_mid= [mean_proc_RL_minus_e_mid; mean(ba_e14_mid(mn).proc_minus_pos)];

mean_proc_vel_plus_e_mid=[mean_proc_vel_plus_e_mid; mean(ba_e14_mid(mn).proc_plus_vel)];
mean_proc_vel_minus_e_mid=[mean_proc_vel_minus_e_mid; mean(ba_e14_mid(mn).proc_minus_vel)];

N_proc_plus_tracks_e_mid=[N_proc_plus_tracks_e_mid';ba_e14_mid(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_e_mid=[N_proc_minus_tracks_e_mid';ba_e14_mid(mn).N_proc_minus_tracks']';
end

%% E14 dist data per cell
sum_diff_time_e_dist= [];%, 'Color', diffColor);
sum_proc_time_e_dist= [];%, 'Color', procColor);
sum_stat_time_e_dist= [];%, 'Color', statColor);
  
mean_proc_RL_plus_e_dist= [];
mean_proc_RL_minus_e_dist= [];

mean_proc_vel_plus_e_dist=[];
mean_proc_vel_minus_e_dist=[];
N_proc_plus_tracks_e_dist=[];
N_proc_minus_tracks_e_dist=[];

for mn=1:length(ba_e14_dist)

sum_diff_time_e_dist= [sum_diff_time_e_dist;(sum(ba_e14_dist(mn).diff_time)./ba_e14_dist(mn).total_time)];%, 'Color', diffColor);
sum_proc_time_e_dist= [sum_proc_time_e_dist;(sum(ba_e14_dist(mn).proc_time)./ba_e14_dist(mn).total_time)];%, 'Color', procColor);
sum_stat_time_e_dist= [sum_stat_time_e_dist;(sum(ba_e14_dist(mn).stat_time)./ba_e14_dist(mn).total_time)];%, 'Color', statColor);

mean_proc_RL_plus_e_dist= [mean_proc_RL_plus_e_dist; mean(ba_e14_dist(mn).proc_plus_pos)];
mean_proc_RL_minus_e_dist= [mean_proc_RL_minus_e_dist; mean(ba_e14_dist(mn).proc_minus_pos)];

mean_proc_vel_plus_e_dist=[mean_proc_vel_plus_e_dist; mean(ba_e14_dist(mn).proc_plus_vel)];
mean_proc_vel_minus_e_dist=[mean_proc_vel_minus_e_dist; mean(ba_e14_dist(mn).proc_minus_vel)];

N_proc_plus_tracks_e_dist=[N_proc_plus_tracks_e_dist';ba_e14_dist(mn).N_proc_plus_tracks']';
N_proc_minus_tracks_e_dist=[N_proc_minus_tracks_e_dist';ba_e14_dist(mn).N_proc_minus_tracks']';
end

nboot=10000;
%% CTL mean rev rate
[bci_revRate_ctl_all,bsums_revRate_ctl_all]=bootci(nboot,{@nanmean, mean_revRate_ctl_all},'alpha',.05,'type','per');
    bci_revRate_ctl_all=bci_revRate_ctl_all';
    bmu_revRate_ctl_all = mean(bsums_revRate_ctl_all);
    
%% KO mean rev rate
[bci_revRate_ko_all,bsums_revRate_ko_all]=bootci(nboot,{@nanmean, mean_revRate_ko_all},'alpha',.05,'type','per');
    bci_revRate_ko_all=bci_revRate_ko_all';
    bmu_revRate_ko_all = mean(bsums_revRate_ko_all);    
    
    %% WT mean rev rate
[bci_revRate_wt_all,bsums_revRate_wt_all]=bootci(nboot,{@nanmean, mean_revRate_wt_all},'alpha',.05,'type','per');
    bci_revRate_wt_all=bci_revRate_wt_all';
    bmu_revRate_wt_all = mean(bsums_revRate_wt_all);
    
    %% AP mean rev rate
[bci_revRate_ap_all,bsums_revRate_ap_all]=bootci(nboot,{@nanmean, mean_revRate_ap_all},'alpha',.05,'type','per');
    bci_revRate_ap_all=bci_revRate_ap_all';
    bmu_revRate_ap_all = mean(bsums_revRate_ap_all);
    
    %% E14 mean rev rate
[bci_revRate_e14_all,bsums_revRate_e14_all]=bootci(nboot,{@nanmean, mean_revRate_e14_all},'alpha',.05,'type','per');
    bci_revRate_e14_all=bci_revRate_e14_all';
    bmu_revRate_e14_all = mean(bsums_revRate_e14_all);
    
   %% Mean rev Rate runs
figure('Name',strcat(' Mean reversal rate v2 all'),'NumberTitle','off'),

subplot(1,3,1), hold on,
b1=bar(1, bmu_revRate_ctl_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(1,bmu_revRate_ctl_all,bci_revRate_ctl_all(1)-bmu_revRate_ctl_all,bci_revRate_ctl_all(2)-bmu_revRate_ctl_all,'k','linestyle','none')';

hold on,
for hn=1:length(ba_ctl_all)
hold on,
scPlot_plusRL=scatter(1,mean_revRate_ctl_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end
   
b1=bar(2, bmu_revRate_ko_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(2,bmu_revRate_ko_all,bci_revRate_ko_all(1)-bmu_revRate_ko_all,bci_revRate_ko_all(2)-bmu_revRate_ko_all,'k','linestyle','none')';

hold on,
for hn=1:length(ba_ko_all)
hold on,
scPlot_plusRL=scatter(2,mean_revRate_ko_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end

b1=bar(3, bmu_revRate_wt_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(3,bmu_revRate_wt_all,bci_revRate_wt_all(1)-bmu_revRate_wt_all,bci_revRate_wt_all(2)-bmu_revRate_wt_all,'k','linestyle','none')';

hold on,
for hn=1:length(ba_wt_all)
hold on,
scPlot_plusRL=scatter(3,mean_revRate_wt_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end

b1=bar(4, bmu_revRate_ap_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(4,bmu_revRate_ap_all,bci_revRate_ap_all(1)-bmu_revRate_ap_all,bci_revRate_ap_all(2)-bmu_revRate_ap_all,'k','linestyle','none')';

hold on,
for hn=1:length(ba_ap_all)
hold on,
scPlot_plusRL=scatter(4,mean_revRate_ap_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end

b1=bar(5, bmu_revRate_e14_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(5,bmu_revRate_e14_all,bci_revRate_e14_all(1)-bmu_revRate_e14_all,bci_revRate_e14_all(2)-bmu_revRate_e14_all,'k','linestyle','none')';

hold on,
for hn=1:length(ba_e14_all)
hold on,
scPlot_plusRL=scatter(5,mean_revRate_e14_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end

ylim([0 1.5]);
 ylabel('mean reversal rate (s^1)'); xlabel('all regions');
xticks([1,2,3,4,5]); set(gca,'xticklabel',{'CTL','KO','WT','AP','E14'});


%% CTL mean RL
[bci_plus_proc_RL_ctl_all,bsums_plus_proc_RL_ctl_all]=bootci(nboot,{@nanmean, mean_proc_RL_plus_ctl_all},'alpha',.05,'type','per');
    bci_plus_proc_RL_ctl_all=bci_plus_proc_RL_ctl_all';
    bmu_plus_proc_RL_ctl_all = mean(bsums_plus_proc_RL_ctl_all);
    
[bci_minus_proc_RL_ctl_all,bsums_minus_proc_RL_ctl_all]=bootci(nboot,{@nanmean, mean_proc_RL_minus_ctl_all},'alpha',.05,'type','per');
    bci_minus_proc_RL_ctl_all=bci_minus_proc_RL_ctl_all';
    bmu_minus_proc_RL_ctl_all = mean(bsums_minus_proc_RL_ctl_all);

  %% KO mean RL
[bci_plus_proc_RL_ko_all,bsums_plus_proc_RL_ko_all]=bootci(nboot,{@nanmean, mean_proc_RL_plus_ko_all},'alpha',.05,'type','per');
    bci_plus_proc_RL_ko_all=bci_plus_proc_RL_ko_all';
    bmu_plus_proc_RL_ko_all = mean(bsums_plus_proc_RL_ko_all);
    
[bci_minus_proc_RL_ko_all,bsums_minus_proc_RL_ko_all]=bootci(nboot,{@nanmean, mean_proc_RL_minus_ko_all},'alpha',.05,'type','per');
    bci_minus_proc_RL_ko_all=bci_minus_proc_RL_ko_all';
    bmu_minus_proc_RL_ko_all = mean(bsums_minus_proc_RL_ko_all);

    %% WT mean RL
[bci_plus_proc_RL_wt_all,bsums_plus_proc_RL_wt_all]=bootci(nboot,{@nanmean, mean_proc_RL_plus_wt_all},'alpha',.05,'type','per');
    bci_plus_proc_RL_wt_all=bci_plus_proc_RL_wt_all';
    bmu_plus_proc_RL_wt_all = mean(bsums_plus_proc_RL_wt_all);
    
[bci_minus_proc_RL_wt_all,bsums_minus_proc_RL_wt_all]=bootci(nboot,{@nanmean, mean_proc_RL_minus_wt_all},'alpha',.05,'type','per');
    bci_minus_proc_RL_wt_all=bci_minus_proc_RL_wt_all';
    bmu_minus_proc_RL_wt_all = mean(bsums_minus_proc_RL_wt_all);
    
    %% AP mean RL
[bci_plus_proc_RL_ap_all,bsums_plus_proc_RL_ap_all]=bootci(nboot,{@nanmean, mean_proc_RL_plus_ap_all},'alpha',.05,'type','per');
    bci_plus_proc_RL_ap_all=bci_plus_proc_RL_ap_all';
    bmu_plus_proc_RL_ap_all = mean(bsums_plus_proc_RL_ap_all);
    
[bci_minus_proc_RL_ap_all,bsums_minus_proc_RL_ap_all]=bootci(nboot,{@nanmean, mean_proc_RL_minus_ap_all},'alpha',.05,'type','per');
    bci_minus_proc_RL_ap_all=bci_minus_proc_RL_ap_all';
    bmu_minus_proc_RL_ap_all = mean(bsums_minus_proc_RL_ap_all);
    
    %% E14 mean RL
[bci_plus_proc_RL_e14_all,bsums_plus_proc_RL_e14_all]=bootci(nboot,{@nanmean, mean_proc_RL_plus_e14_all},'alpha',.05,'type','per');
    bci_plus_proc_RL_e14_all=bci_plus_proc_RL_e14_all';
    bmu_plus_proc_RL_e14_all = mean(bsums_plus_proc_RL_e14_all);
    
[bci_minus_proc_RL_e14_all,bsums_minus_proc_RL_e14_all]=bootci(nboot,{@nanmean, mean_proc_RL_minus_e14_all},'alpha',.05,'type','per');
    bci_minus_proc_RL_e14_all=bci_minus_proc_RL_e14_all';
    bmu_minus_proc_RL_e14_all = mean(bsums_minus_proc_RL_e14_all);

 
      
%% Mean RL processive runs
figure('Name',strcat(' Mean Run Lengths v2 all'),'NumberTitle','off'),

subplot(1,3,1), hold on,
b1=bar(1, bmu_plus_proc_RL_ctl_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(1,bmu_plus_proc_RL_ctl_all,bci_plus_proc_RL_ctl_all(1)-bmu_plus_proc_RL_ctl_all,bci_plus_proc_RL_ctl_all(2)-bmu_plus_proc_RL_ctl_all,'k','linestyle','none')';
b2=bar(1, bmu_minus_proc_RL_ctl_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(1,bmu_minus_proc_RL_ctl_all,bci_minus_proc_RL_ctl_all(1)-bmu_minus_proc_RL_ctl_all,bci_minus_proc_RL_ctl_all(2)-bmu_minus_proc_RL_ctl_all,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ctl_all)
hold on,

scPlot_plusRL=scatter(1,mean_proc_RL_plus_ctl_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(1,mean_proc_RL_minus_ctl_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end


b1=bar(2, bmu_plus_proc_RL_ko_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(2,bmu_plus_proc_RL_ko_all,bci_plus_proc_RL_ko_all(1)-bmu_plus_proc_RL_ko_all,bci_plus_proc_RL_ko_all(2)-bmu_plus_proc_RL_ko_all,'k','linestyle','none')';
b2=bar(2, bmu_minus_proc_RL_ko_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(2,bmu_minus_proc_RL_ko_all,bci_minus_proc_RL_ko_all(1)-bmu_minus_proc_RL_ko_all,bci_minus_proc_RL_ko_all(2)-bmu_minus_proc_RL_ko_all,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ko_all)
hold on,

scPlot_plusRL=scatter(2,mean_proc_RL_plus_ko_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(2,mean_proc_RL_minus_ko_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end


b1=bar(3, bmu_plus_proc_RL_wt_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(3,bmu_plus_proc_RL_wt_all,bci_plus_proc_RL_wt_all(1)-bmu_plus_proc_RL_wt_all,bci_plus_proc_RL_wt_all(2)-bmu_plus_proc_RL_wt_all,'k','linestyle','none')';
b2=bar(3, bmu_minus_proc_RL_wt_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(3,bmu_minus_proc_RL_wt_all,bci_minus_proc_RL_wt_all(1)-bmu_minus_proc_RL_wt_all,bci_minus_proc_RL_wt_all(2)-bmu_minus_proc_RL_wt_all,'k','linestyle','none')';
hold on,
for hn=1:length(ba_wt_all)
hold on,

scPlot_plusRL=scatter(3,mean_proc_RL_plus_wt_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(3,mean_proc_RL_minus_wt_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end


b1=bar(4, bmu_plus_proc_RL_ap_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(4,bmu_plus_proc_RL_ap_all,bci_plus_proc_RL_ap_all(1)-bmu_plus_proc_RL_ap_all,bci_plus_proc_RL_ap_all(2)-bmu_plus_proc_RL_ap_all,'k','linestyle','none')';
b2=bar(4, bmu_minus_proc_RL_ap_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(4,bmu_minus_proc_RL_ap_all,bci_minus_proc_RL_ap_all(1)-bmu_minus_proc_RL_ap_all,bci_minus_proc_RL_ap_all(2)-bmu_minus_proc_RL_ap_all,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ap_all)
hold on,

scPlot_plusRL=scatter(4,mean_proc_RL_plus_ap_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(4,mean_proc_RL_minus_ap_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end


b1=bar(5, bmu_plus_proc_RL_e14_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(5,bmu_plus_proc_RL_e14_all,bci_plus_proc_RL_e14_all(1)-bmu_plus_proc_RL_e14_all,bci_plus_proc_RL_e14_all(2)-bmu_plus_proc_RL_e14_all,'k','linestyle','none')';
b2=bar(5, bmu_minus_proc_RL_e14_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(5,bmu_minus_proc_RL_e14_all,bci_minus_proc_RL_e14_all(1)-bmu_minus_proc_RL_e14_all,bci_minus_proc_RL_e14_all(2)-bmu_minus_proc_RL_e14_all,'k','linestyle','none')';
hold on,
for hn=1:length(ba_e14_all)
hold on,

scPlot_plusRL=scatter(5,mean_proc_RL_plus_e14_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(5,mean_proc_RL_minus_e14_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end
ylim([-10 10]);
 ylabel('mean run length (um)'); xlabel('all regions');
xticks([1,2,3,4,5]); set(gca,'xticklabel',{'CTL','KO','WT','AP','E14'});





%% CTL mean vel
[bci_plus_proc_vel_ctl_all,bsums_plus_proc_vel_ctl_all]=bootci(nboot,{@nanmean, mean_proc_vel_plus_ctl_all},'alpha',.05,'type','per');
    bci_plus_proc_vel_ctl_all=bci_plus_proc_vel_ctl_all';
    bmu_plus_proc_vel_ctl_all = mean(bsums_plus_proc_vel_ctl_all);
    
[bci_minus_proc_vel_ctl_all,bsums_minus_proc_vel_ctl_all]=bootci(nboot,{@nanmean, mean_proc_vel_minus_ctl_all},'alpha',.05,'type','per');
    bci_minus_proc_vel_ctl_all=bci_minus_proc_vel_ctl_all';
    bmu_minus_proc_vel_ctl_all = mean(bsums_minus_proc_vel_ctl_all);

  %% KO mean vel
[bci_plus_proc_vel_ko_all,bsums_plus_proc_vel_ko_all]=bootci(nboot,{@nanmean, mean_proc_vel_plus_ko_all},'alpha',.05,'type','per');
    bci_plus_proc_vel_ko_all=bci_plus_proc_vel_ko_all';
    bmu_plus_proc_vel_ko_all = mean(bsums_plus_proc_vel_ko_all);
    
[bci_minus_proc_vel_ko_all,bsums_minus_proc_vel_ko_all]=bootci(nboot,{@nanmean, mean_proc_vel_minus_ko_all},'alpha',.05,'type','per');
    bci_minus_proc_vel_ko_all=bci_minus_proc_vel_ko_all';
    bmu_minus_proc_vel_ko_all = mean(bsums_minus_proc_vel_ko_all);

    %% WT mean vel
[bci_plus_proc_vel_wt_all,bsums_plus_proc_vel_wt_all]=bootci(nboot,{@nanmean, mean_proc_vel_plus_wt_all},'alpha',.05,'type','per');
    bci_plus_proc_vel_wt_all=bci_plus_proc_vel_wt_all';
    bmu_plus_proc_vel_wt_all = mean(bsums_plus_proc_vel_wt_all);
    
[bci_minus_proc_vel_wt_all,bsums_minus_proc_vel_wt_all]=bootci(nboot,{@nanmean, mean_proc_vel_minus_wt_all},'alpha',.05,'type','per');
    bci_minus_proc_vel_wt_all=bci_minus_proc_vel_wt_all';
    bmu_minus_proc_vel_wt_all = mean(bsums_minus_proc_vel_wt_all);
    
    %% AP mean vel
[bci_plus_proc_vel_ap_all,bsums_plus_proc_vel_ap_all]=bootci(nboot,{@nanmean, mean_proc_vel_plus_ap_all},'alpha',.05,'type','per');
    bci_plus_proc_vel_ap_all=bci_plus_proc_vel_ap_all';
    bmu_plus_proc_vel_ap_all = mean(bsums_plus_proc_vel_ap_all);
    
[bci_minus_proc_vel_ap_all,bsums_minus_proc_vel_ap_all]=bootci(nboot,{@nanmean, mean_proc_vel_minus_ap_all},'alpha',.05,'type','per');
    bci_minus_proc_vel_ap_all=bci_minus_proc_vel_ap_all';
    bmu_minus_proc_vel_ap_all = mean(bsums_minus_proc_vel_ap_all);
    
    %% E14 mean vel
[bci_plus_proc_vel_e14_all,bsums_plus_proc_vel_e14_all]=bootci(nboot,{@nanmean, mean_proc_vel_plus_e14_all},'alpha',.05,'type','per');
    bci_plus_proc_vel_e14_all=bci_plus_proc_vel_e14_all';
    bmu_plus_proc_vel_e14_all = mean(bsums_plus_proc_vel_e14_all);
    
[bci_minus_proc_vel_e14_all,bsums_minus_proc_vel_e14_all]=bootci(nboot,{@nanmean, mean_proc_vel_minus_e14_all},'alpha',.05,'type','per');
    bci_minus_proc_vel_e14_all=bci_minus_proc_vel_e14_all';
    bmu_minus_proc_vel_e14_all = mean(bsums_minus_proc_vel_e14_all);
     
  
   %% Mean vel processive runs
figure('Name',strcat(' Mean velocities v2 all'),'NumberTitle','off'),

subplot(1,3,1), hold on,
b1=bar(1, bmu_plus_proc_vel_ctl_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(1,bmu_plus_proc_vel_ctl_all,bci_plus_proc_vel_ctl_all(1)-bmu_plus_proc_vel_ctl_all,bci_plus_proc_vel_ctl_all(2)-bmu_plus_proc_vel_ctl_all,'k','linestyle','none')';
b2=bar(1, bmu_minus_proc_vel_ctl_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(1,bmu_minus_proc_vel_ctl_all,bci_minus_proc_vel_ctl_all(1)-bmu_minus_proc_vel_ctl_all,bci_minus_proc_vel_ctl_all(2)-bmu_minus_proc_vel_ctl_all,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ctl_all)
hold on,

scPlot_plusRL=scatter(1,mean_proc_vel_plus_ctl_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(1,mean_proc_vel_minus_ctl_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end


b1=bar(2, bmu_plus_proc_vel_ko_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(2,bmu_plus_proc_vel_ko_all,bci_plus_proc_vel_ko_all(1)-bmu_plus_proc_vel_ko_all,bci_plus_proc_vel_ko_all(2)-bmu_plus_proc_vel_ko_all,'k','linestyle','none')';
b2=bar(2, bmu_minus_proc_vel_ko_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(2,bmu_minus_proc_vel_ko_all,bci_minus_proc_vel_ko_all(1)-bmu_minus_proc_vel_ko_all,bci_minus_proc_vel_ko_all(2)-bmu_minus_proc_vel_ko_all,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ko_all)
hold on,

scPlot_plusRL=scatter(2,mean_proc_vel_plus_ko_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(2,mean_proc_vel_minus_ko_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end


b1=bar(3, bmu_plus_proc_vel_wt_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(3,bmu_plus_proc_vel_wt_all,bci_plus_proc_vel_wt_all(1)-bmu_plus_proc_vel_wt_all,bci_plus_proc_vel_wt_all(2)-bmu_plus_proc_vel_wt_all,'k','linestyle','none')';
b2=bar(3, bmu_minus_proc_vel_wt_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(3,bmu_minus_proc_vel_wt_all,bci_minus_proc_vel_wt_all(1)-bmu_minus_proc_vel_wt_all,bci_minus_proc_vel_wt_all(2)-bmu_minus_proc_vel_wt_all,'k','linestyle','none')';
hold on,
for hn=1:length(ba_wt_all)
hold on,

scPlot_plusRL=scatter(3,mean_proc_vel_plus_wt_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(3,mean_proc_vel_minus_wt_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end


b1=bar(4, bmu_plus_proc_vel_ap_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(4,bmu_plus_proc_vel_ap_all,bci_plus_proc_vel_ap_all(1)-bmu_plus_proc_vel_ap_all,bci_plus_proc_vel_ap_all(2)-bmu_plus_proc_vel_ap_all,'k','linestyle','none')';
b2=bar(4, bmu_minus_proc_vel_ap_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(4,bmu_minus_proc_vel_ap_all,bci_minus_proc_vel_ap_all(1)-bmu_minus_proc_vel_ap_all,bci_minus_proc_vel_ap_all(2)-bmu_minus_proc_vel_ap_all,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ap_all)
hold on,

scPlot_plusRL=scatter(4,mean_proc_vel_plus_ap_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(4,mean_proc_vel_minus_ap_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end


b1=bar(5, bmu_plus_proc_vel_e14_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(5,bmu_plus_proc_vel_e14_all,bci_plus_proc_vel_e14_all(1)-bmu_plus_proc_vel_e14_all,bci_plus_proc_vel_e14_all(2)-bmu_plus_proc_vel_e14_all,'k','linestyle','none')';
b2=bar(5, bmu_minus_proc_vel_e14_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(5,bmu_minus_proc_vel_e14_all,bci_minus_proc_vel_e14_all(1)-bmu_minus_proc_vel_e14_all,bci_minus_proc_vel_e14_all(2)-bmu_minus_proc_vel_e14_all,'k','linestyle','none')';
hold on,
for hn=1:length(ba_e14_all)
hold on,

scPlot_plusRL=scatter(5,mean_proc_vel_plus_e14_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(5,mean_proc_vel_minus_e14_all(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end
ylim([-3 3]);
 ylabel('mean velocities (um/s)'); xlabel('all regions');
xticks([1,2,3,4,5]); set(gca,'xticklabel',{'CTL','KO','WT','AP','E14'});

 
    

%% Mean RL diffusive, processive, and stationary runs
figure('Name',strcat(' Mean Run Lengths v2'),'NumberTitle','off'),

subplot(1,3,1), hold on,
b1=bar(1, bmu_procR_plus_prox_ctl,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(1,bmu_procR_plus_prox_ctl,bci_procR_plus_prox_ctl(1)-bmu_procR_plus_prox_ctl,bci_procR_plus_prox_ctl(2)-bmu_procR_plus_prox_ctl,'k','linestyle','none')';
b2=bar(1, bmu_procR_minus_prox_ctl,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(1,bmu_procR_minus_prox_ctl,bci_procR_minus_prox_ctl(1)-bmu_procR_minus_prox_ctl,bci_procR_minus_prox_ctl(2)-bmu_procR_minus_prox_ctl,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ctl_prox)
hold on,


scPlot_plusRL=scatter(1,mean_proc_RL_plus_ctl_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(1,mean_proc_RL_minus_ctl_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end

b1=bar(2, bmu_procR_plus_prox_ko,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(2,bmu_procR_plus_prox_ko,bci_procR_plus_prox_ko(1)-bmu_procR_plus_prox_ko,bci_procR_plus_prox_ko(2)-bmu_procR_plus_prox_ko,'k','linestyle','none')';
b2=bar(2, bmu_procR_minus_prox_ko,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(2,bmu_procR_minus_prox_ko,bci_procR_minus_prox_ko(1)-bmu_procR_minus_prox_ko,bci_procR_minus_prox_ko(2)-bmu_procR_minus_prox_ko,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ko_prox)
hold on,
scPlot_plusRL=scatter(2,mean_proc_RL_plus_ko_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ko_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ko_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(2,mean_proc_RL_minus_ko_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ko_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ko_prox(hn).dotColor);
hold on,
end


b1=bar(3, bmu_procR_plus_prox_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(3,bmu_procR_plus_prox_wt,bci_procR_plus_prox_wt(1)-bmu_procR_plus_prox_wt,bci_procR_plus_prox_wt(2)-bmu_procR_plus_prox_wt,'k','linestyle','none')';
b2=bar(3, bmu_procR_minus_prox_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(3,bmu_procR_minus_prox_wt,bci_procR_minus_prox_wt(1)-bmu_procR_minus_prox_wt,bci_procR_minus_prox_wt(2)-bmu_procR_minus_prox_wt,'k','linestyle','none')';
hold on,
for hn=1:length(ba_wt_prox)
hold on,
scPlot_plusRL=scatter(3,mean_proc_RL_plus_wt_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_wt_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_wt_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(3,mean_proc_RL_minus_wt_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_wt_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_wt_prox(hn).dotColor);
hold on,
end

b1=bar(4, bmu_procR_plus_prox_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(4,bmu_procR_plus_prox_ap,bci_procR_plus_prox_ap(1)-bmu_procR_plus_prox_ap,bci_procR_plus_prox_ap(2)-bmu_procR_plus_prox_ap,'k','linestyle','none')';
b2=bar(4, bmu_procR_minus_prox_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(4,bmu_procR_minus_prox_ap,bci_procR_minus_prox_ap(1)-bmu_procR_minus_prox_ap,bci_procR_minus_prox_ap(2)-bmu_procR_minus_prox_ap,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ap_prox)
hold on,
scPlot_plusRL=scatter(4,mean_proc_RL_plus_ap_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ap_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(4,mean_proc_RL_minus_ap_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ap_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_prox(hn).dotColor);
hold on,
end

b1=bar(5, bmu_procR_plus_prox_e14,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(5,bmu_procR_plus_prox_e14,bci_procR_plus_prox_e14(1)-bmu_procR_plus_prox_e14,bci_procR_plus_prox_e14(2)-bmu_procR_plus_prox_e14,'k','linestyle','none')';
b2=bar(5, bmu_procR_minus_prox_e14,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(5,bmu_procR_minus_prox_e14,bci_procR_minus_prox_e14(1)-bmu_procR_minus_prox_e14,bci_procR_minus_prox_e14(2)-bmu_procR_minus_prox_e14,'k','linestyle','none')';
hold on,
for hn=1:length(ba_e14_prox)
hold on,
scPlot_plusRL=scatter(5,mean_proc_RL_plus_e_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_e_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_e14_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(5,mean_proc_RL_minus_e_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_e_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_e14_prox(hn).dotColor);
hold on,
end

ylim([-10 10]);
 ylabel('mean run length (um)'); xlabel('proximal');
xticks([1,2,3,4,5]); set(gca,'xticklabel',{'CTL','KO','WT','AP','E14'});


subplot(1,3,2), hold on,
b1=bar(1, bmu_procR_plus_mid_ctl,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e1=errorbar(1,bmu_procR_plus_mid_ctl,bci_procR_plus_mid_ctl(1)-bmu_procR_plus_mid_ctl,bci_procR_plus_mid_ctl(2)-bmu_procR_plus_mid_ctl,'k','linestyle','none')';
b2=bar(1, bmu_procR_minus_mid_ctl,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e2=errorbar(1,bmu_procR_minus_mid_ctl,bci_procR_minus_mid_ctl(1)-bmu_procR_minus_mid_ctl,bci_procR_minus_mid_ctl(2)-bmu_procR_minus_mid_ctl,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ctl_mid)
hold on,
scPlot_plusRL=scatter(1,mean_proc_RL_plus_ctl_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_mid(hn).dotColor);
hold on,
scPlot_minusRL=scatter(1,mean_proc_RL_minus_ctl_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_mid(hn).dotColor);
hold on,
end

b1=bar(2, bmu_procR_plus_mid_ko,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e1=errorbar(2,bmu_procR_plus_mid_ko,bci_procR_plus_mid_ko(1)-bmu_procR_plus_mid_ko,bci_procR_plus_mid_ko(2)-bmu_procR_plus_mid_ko,'k','linestyle','none')';
b2=bar(2, bmu_procR_minus_mid_ko,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e2=errorbar(2,bmu_procR_minus_mid_ko,bci_procR_minus_mid_ko(1)-bmu_procR_minus_mid_ko,bci_procR_minus_mid_ko(2)-bmu_procR_minus_mid_ko,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ko_mid)
hold on,
scPlot_plusRL=scatter(2,mean_proc_RL_plus_ko_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ko_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ko_mid(hn).dotColor);
hold on,
scPlot_minusRL=scatter(2,mean_proc_RL_minus_ko_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ko_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ko_mid(hn).dotColor);
hold on,
end


b1=bar(3, bmu_procR_plus_mid_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e1=errorbar(3,bmu_procR_plus_mid_wt,bci_procR_plus_mid_wt(1)-bmu_procR_plus_mid_wt,bci_procR_plus_mid_wt(2)-bmu_procR_plus_mid_wt,'k','linestyle','none')';
b2=bar(3, bmu_procR_minus_mid_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e2=errorbar(3,bmu_procR_minus_mid_wt,bci_procR_minus_mid_wt(1)-bmu_procR_minus_mid_wt,bci_procR_minus_mid_wt(2)-bmu_procR_minus_mid_wt,'k','linestyle','none')';
hold on,
for hn=1:length(ba_wt_mid)
hold on,
scPlot_plusRL=scatter(3,mean_proc_RL_plus_wt_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_wt_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_wt_mid(hn).dotColor);
hold on,
scPlot_minusRL=scatter(3,mean_proc_RL_minus_wt_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_wt_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_wt_mid(hn).dotColor);
hold on,
end

b1=bar(4, bmu_procR_plus_mid_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e1=errorbar(4,bmu_procR_plus_mid_ap,bci_procR_plus_mid_ap(1)-bmu_procR_plus_mid_ap,bci_procR_plus_mid_ap(2)-bmu_procR_plus_mid_ap,'k','linestyle','none')';
b2=bar(4, bmu_procR_minus_mid_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e2=errorbar(4,bmu_procR_minus_mid_ap,bci_procR_minus_mid_ap(1)-bmu_procR_minus_mid_ap,bci_procR_minus_mid_ap(2)-bmu_procR_minus_mid_ap,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ap_mid)
hold on,
scPlot_plusRL=scatter(4,mean_proc_RL_plus_ap_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ap_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_mid(hn).dotColor);
hold on,
scPlot_minusRL=scatter(4,mean_proc_RL_minus_ap_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ap_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_mid(hn).dotColor);
hold on,
end

b1=bar(5, bmu_procR_plus_mid_e14,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e1=errorbar(5,bmu_procR_plus_mid_e14,bci_procR_plus_mid_e14(1)-bmu_procR_plus_mid_e14,bci_procR_plus_mid_e14(2)-bmu_procR_plus_mid_e14,'k','linestyle','none')';
b2=bar(5, bmu_procR_minus_mid_e14,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e2=errorbar(5,bmu_procR_minus_mid_e14,bci_procR_minus_mid_e14(1)-bmu_procR_minus_mid_e14,bci_procR_minus_mid_e14(2)-bmu_procR_minus_mid_e14,'k','linestyle','none')';
hold on,
for hn=1:length(ba_e14_mid)
hold on,
scPlot_plusRL=scatter(5,mean_proc_RL_plus_e_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_e_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_e14_mid(hn).dotColor);
hold on,
scPlot_minusRL=scatter(5,mean_proc_RL_minus_e_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_e_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_e14_mid(hn).dotColor);
hold on,
end

ylim([-10 10]);
  ylabel('mean run length (um)'); xlabel('mid');
xticks([1,2,3,4,5]); set(gca,'xticklabel',{'CTL','KO','WT','AP','E14'});


subplot(1,3,3), hold on,
b1=bar(1, bmu_procR_plus_dist_ctl,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e1=errorbar(1,bmu_procR_plus_dist_ctl,bci_procR_plus_dist_ctl(1)-bmu_procR_plus_dist_ctl,bci_procR_plus_dist_ctl(2)-bmu_procR_plus_dist_ctl,'k','linestyle','none')';
b2=bar(1, bmu_procR_minus_dist_ctl,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e2=errorbar(1,bmu_procR_minus_dist_ctl,bci_procR_minus_dist_ctl(1)-bmu_procR_minus_dist_ctl,bci_procR_minus_dist_ctl(2)-bmu_procR_minus_dist_ctl,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ctl_dist)
hold on,
scPlot_plusRL=scatter(1,mean_proc_RL_plus_ctl_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_dist(hn).dotColor);
hold on,
scPlot_minusRL=scatter(1,mean_proc_RL_minus_ctl_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_dist(hn).dotColor);
hold on,
end

b1=bar(2, bmu_procR_plus_dist_ko,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e1=errorbar(2,bmu_procR_plus_dist_ko,bci_procR_plus_dist_ko(1)-bmu_procR_plus_dist_ko,bci_procR_plus_dist_ko(2)-bmu_procR_plus_dist_ko,'k','linestyle','none')';
b2=bar(2, bmu_procR_minus_dist_ko,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e2=errorbar(2,bmu_procR_minus_dist_ko,bci_procR_minus_dist_ko(1)-bmu_procR_minus_dist_ko,bci_procR_minus_dist_ko(2)-bmu_procR_minus_dist_ko,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ko_dist)
hold on,
scPlot_plusRL=scatter(2,mean_proc_RL_plus_ko_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ko_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ko_dist(hn).dotColor);
hold on,
scPlot_minusRL=scatter(2,mean_proc_RL_minus_ko_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ko_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ko_dist(hn).dotColor);
hold on,
end

b1=bar(3, bmu_procR_plus_dist_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e1=errorbar(3,bmu_procR_plus_dist_wt,bci_procR_plus_dist_wt(1)-bmu_procR_plus_dist_wt,bci_procR_plus_dist_wt(2)-bmu_procR_plus_dist_wt,'k','linestyle','none')';
b2=bar(3, bmu_procR_minus_dist_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e2=errorbar(3,bmu_procR_minus_dist_wt,bci_procR_minus_dist_wt(1)-bmu_procR_minus_dist_wt,bci_procR_minus_dist_wt(2)-bmu_procR_minus_dist_wt,'k','linestyle','none')';
hold on,
for hn=1:length(ba_wt_dist)
hold on,
scPlot_plusRL=scatter(3,mean_proc_RL_plus_wt_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_wt_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_wt_dist(hn).dotColor);
hold on,
scPlot_minusRL=scatter(3,mean_proc_RL_minus_wt_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_wt_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_wt_dist(hn).dotColor);
hold on,
end

b1=bar(4, bmu_procR_plus_dist_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e1=errorbar(4,bmu_procR_plus_dist_ap,bci_procR_plus_dist_ap(1)-bmu_procR_plus_dist_ap,bci_procR_plus_dist_ap(2)-bmu_procR_plus_dist_ap,'k','linestyle','none')';
b2=bar(4, bmu_procR_minus_dist_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e2=errorbar(4,bmu_procR_minus_dist_ap,bci_procR_minus_dist_ap(1)-bmu_procR_minus_dist_ap,bci_procR_minus_dist_ap(2)-bmu_procR_minus_dist_ap,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ap_dist)
hold on,
scPlot_plusRL=scatter(4,mean_proc_RL_plus_ap_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ap_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_dist(hn).dotColor);
hold on,
scPlot_minusRL=scatter(4,mean_proc_RL_minus_ap_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ap_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_dist(hn).dotColor);
hold on,
end

b1=bar(5, bmu_procR_plus_dist_e14,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e1=errorbar(5,bmu_procR_plus_dist_e14,bci_procR_plus_dist_e14(1)-bmu_procR_plus_dist_e14,bci_procR_plus_dist_e14(2)-bmu_procR_plus_dist_e14,'k','linestyle','none')';
b2=bar(5, bmu_procR_minus_dist_e14,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e2=errorbar(5,bmu_procR_minus_dist_e14,bci_procR_minus_dist_e14(1)-bmu_procR_minus_dist_e14,bci_procR_minus_dist_e14(2)-bmu_procR_minus_dist_e14,'k','linestyle','none')';
hold on,
for hn=1:length(ba_e14_dist)
hold on,
scPlot_plusRL=scatter(5,mean_proc_RL_plus_e_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_e_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_e14_dist(hn).dotColor);
hold on,
scPlot_minusRL=scatter(5,mean_proc_RL_minus_e_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_e_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_e14_dist(hn).dotColor);
hold on,
end

hold on,
    ylim([-10 10]);
 ylabel('mean run length (um)'); xlabel('distal');
xticks([1,2,3,4,5]); set(gca,'xticklabel',{'CTL','KO','WT','AP','E14'});




%% Mean  processive runs velocities
figure('Name',strcat(' Mean Velocities v2'),'NumberTitle','off'),

subplot(1,3,1), hold on,
b1=bar(1, bmu_vel_plus_prox_ctl,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(1,bmu_vel_plus_prox_ctl,bci_vel_plus_prox_ctl(1)-bmu_vel_plus_prox_ctl,bci_vel_plus_prox_ctl(2)-bmu_vel_plus_prox_ctl,'k','linestyle','none')';
b2=bar(1, bmu_vel_minus_prox_ctl,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(1,bmu_vel_minus_prox_ctl,bci_vel_minus_prox_ctl(1)-bmu_vel_minus_prox_ctl,bci_vel_minus_prox_ctl(2)-bmu_vel_minus_prox_ctl,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ctl_prox)
hold on,
scPlot_plusRL=scatter(1,mean_proc_vel_plus_ctl_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(1,mean_proc_vel_minus_ctl_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end


b1=bar(2, bmu_vel_plus_prox_ko,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(2,bmu_vel_plus_prox_ko,bci_vel_plus_prox_ko(1)-bmu_vel_plus_prox_ko,bci_vel_plus_prox_ko(2)-bmu_vel_plus_prox_ko,'k','linestyle','none')';
b2=bar(2, bmu_vel_minus_prox_ko,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(2,bmu_vel_minus_prox_ko,bci_vel_minus_prox_ko(1)-bmu_vel_minus_prox_ko,bci_vel_minus_prox_ko(2)-bmu_vel_minus_prox_ko,'k','linestyle','none')';
for hn=1:length(ba_ko_prox)
hold on,
scPlot_plusRL=scatter(2,mean_proc_vel_plus_ko_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ko_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ko_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(2,mean_proc_vel_minus_ko_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ko_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ko_prox(hn).dotColor);
hold on,
end

b1=bar(3, bmu_vel_plus_prox_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(3,bmu_vel_plus_prox_wt,bci_vel_plus_prox_wt(1)-bmu_vel_plus_prox_wt,bci_vel_plus_prox_wt(2)-bmu_vel_plus_prox_wt,'k','linestyle','none')';
b2=bar(3, bmu_vel_minus_prox_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(3,bmu_vel_minus_prox_wt,bci_vel_minus_prox_wt(1)-bmu_vel_minus_prox_wt,bci_vel_minus_prox_wt(2)-bmu_vel_minus_prox_wt,'k','linestyle','none')';
for hn=1:length(ba_wt_prox)
hold on,
scPlot_plusRL=scatter(3,mean_proc_vel_plus_wt_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_wt_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_wt_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(3,mean_proc_vel_minus_wt_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_wt_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_wt_prox(hn).dotColor);
hold on,
end

b1=bar(4, bmu_vel_plus_prox_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(4,bmu_vel_plus_prox_ap,bci_vel_plus_prox_ap(1)-bmu_vel_plus_prox_ap,bci_vel_plus_prox_ap(2)-bmu_vel_plus_prox_ap,'k','linestyle','none')';
b2=bar(4, bmu_vel_minus_prox_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(4,bmu_vel_minus_prox_ap,bci_vel_minus_prox_ap(1)-bmu_vel_minus_prox_ap,bci_vel_minus_prox_ap(2)-bmu_vel_minus_prox_ap,'k','linestyle','none')';
for hn=1:length(ba_ap_prox)
hold on,
scPlot_plusRL=scatter(4,mean_proc_vel_plus_ap_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ap_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(4,mean_proc_vel_minus_ap_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ap_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_prox(hn).dotColor);
hold on,
end

b1=bar(5, bmu_vel_plus_prox_e14,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(5,bmu_vel_plus_prox_e14,bci_vel_plus_prox_e14(1)-bmu_vel_plus_prox_e14,bci_vel_plus_prox_e14(2)-bmu_vel_plus_prox_e14,'k','linestyle','none')';
b2=bar(5, bmu_vel_minus_prox_e14,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(5,bmu_vel_minus_prox_e14,bci_vel_minus_prox_e14(1)-bmu_vel_minus_prox_e14,bci_vel_minus_prox_e14(2)-bmu_vel_minus_prox_e14,'k','linestyle','none')';
for hn=1:length(ba_e14_prox)
hold on,
scPlot_plusRL=scatter(5,mean_proc_vel_plus_e_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_e_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_e14_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(5,mean_proc_vel_minus_e_prox(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_e_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_e14_prox(hn).dotColor);
hold on,
end

ylim([-3.0 3]);
 ylabel('mean velocity (um/s)'); xlabel('proximal');
xticks([1,2,3,4,5]); set(gca,'xticklabel',{'CTL','KO','WT','AP','E14'});


subplot(1,3,2), hold on,
b1=bar(1, bmu_vel_plus_mid_ctl,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e1=errorbar(1,bmu_vel_plus_mid_ctl,bci_vel_plus_mid_ctl(1)-bmu_vel_plus_mid_ctl,bci_vel_plus_mid_ctl(2)-bmu_vel_plus_mid_ctl,'k','linestyle','none')';
b2=bar(1, bmu_vel_minus_mid_ctl,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e2=errorbar(1,bmu_vel_minus_mid_ctl,bci_vel_minus_mid_ctl(1)-bmu_vel_minus_mid_ctl,bci_vel_minus_mid_ctl(2)-bmu_vel_minus_mid_ctl,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ctl_mid)
hold on,
scPlot_plusRL=scatter(1,mean_proc_vel_plus_ctl_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_mid(hn).dotColor);
hold on,
scPlot_minusRL=scatter(1,mean_proc_vel_minus_ctl_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_mid(hn).dotColor);
hold on,
end

b1=bar(2, bmu_vel_plus_mid_ko,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e1=errorbar(2,bmu_vel_plus_mid_ko,bci_vel_plus_mid_ko(1)-bmu_vel_plus_mid_ko,bci_vel_plus_mid_ko(2)-bmu_vel_plus_mid_ko,'k','linestyle','none')';
b2=bar(2, bmu_vel_minus_mid_ko,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e2=errorbar(2,bmu_vel_minus_mid_ko,bci_vel_minus_mid_ko(1)-bmu_vel_minus_mid_ko,bci_vel_minus_mid_ko(2)-bmu_vel_minus_mid_ko,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ko_mid)
hold on,
scPlot_plusRL=scatter(2,mean_proc_vel_plus_ko_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ko_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ko_mid(hn).dotColor);
hold on,
scPlot_minusRL=scatter(2,mean_proc_vel_minus_ko_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ko_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ko_mid(hn).dotColor);
hold on,
end


b1=bar(3, bmu_vel_plus_mid_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e1=errorbar(3,bmu_vel_plus_mid_wt,bci_vel_plus_mid_wt(1)-bmu_vel_plus_mid_wt,bci_vel_plus_mid_wt(2)-bmu_vel_plus_mid_wt,'k','linestyle','none')';
b2=bar(3, bmu_vel_minus_mid_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e2=errorbar(3,bmu_vel_minus_mid_wt,bci_vel_minus_mid_wt(1)-bmu_vel_minus_mid_wt,bci_vel_minus_mid_wt(2)-bmu_vel_minus_mid_wt,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ap_mid)
hold on,
scPlot_plusRL=scatter(3,mean_proc_vel_plus_ap_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ap_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_mid(hn).dotColor);
hold on,
scPlot_minusRL=scatter(3,mean_proc_vel_minus_ap_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ap_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_mid(hn).dotColor);
hold on,
end

b1=bar(4, bmu_vel_plus_mid_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e1=errorbar(4,bmu_vel_plus_mid_ap,bci_vel_plus_mid_ap(1)-bmu_vel_plus_mid_ap,bci_vel_plus_mid_ap(2)-bmu_vel_plus_mid_ap,'k','linestyle','none')';
b2=bar(4, bmu_vel_minus_mid_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e2=errorbar(4,bmu_vel_minus_mid_ap,bci_vel_minus_mid_ap(1)-bmu_vel_minus_mid_ap,bci_vel_minus_mid_ap(2)-bmu_vel_minus_mid_ap,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ap_mid)
hold on,
scPlot_plusRL=scatter(4,mean_proc_vel_plus_ap_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ap_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_mid(hn).dotColor);
hold on,
scPlot_minusRL=scatter(4,mean_proc_vel_minus_ap_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ap_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_mid(hn).dotColor);
hold on,
end

b1=bar(5, bmu_vel_plus_mid_e14,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e1=errorbar(5,bmu_vel_plus_mid_e14,bci_vel_plus_mid_e14(1)-bmu_vel_plus_mid_e14,bci_vel_plus_mid_e14(2)-bmu_vel_plus_mid_e14,'k','linestyle','none')';
b2=bar(5, bmu_vel_minus_mid_e14,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e2=errorbar(5,bmu_vel_minus_mid_e14,bci_vel_minus_mid_e14(1)-bmu_vel_minus_mid_e14,bci_vel_minus_mid_e14(2)-bmu_vel_minus_mid_e14,'k','linestyle','none')';
hold on,
for hn=1:length(ba_e14_mid)
hold on,
scPlot_plusRL=scatter(5,mean_proc_vel_plus_e_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_e_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_e14_mid(hn).dotColor);
hold on,
scPlot_minusRL=scatter(5,mean_proc_vel_minus_e_mid(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_e_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_e14_mid(hn).dotColor);
hold on,
end

ylim([-3.0 3]);
 ylabel('mean velocity (um/s)'); xlabel('mid');
xticks([1,2,3,4,5]); set(gca,'xticklabel',{'CTL','KO','WT','AP','E14'});



subplot(1,3,3), hold on,
b1=bar(1, bmu_vel_plus_dist_ctl,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e1=errorbar(1,bmu_vel_plus_dist_ctl,bci_vel_plus_dist_ctl(1)-bmu_vel_plus_dist_ctl,bci_vel_plus_dist_ctl(2)-bmu_vel_plus_dist_ctl,'k','linestyle','none')';
b2=bar(1, bmu_vel_minus_dist_ctl,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e2=errorbar(1,bmu_vel_minus_dist_ctl,bci_vel_minus_dist_ctl(1)-bmu_vel_minus_dist_ctl,bci_vel_minus_dist_ctl(2)-bmu_vel_minus_dist_ctl,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ctl_dist)
hold on,
scPlot_plusRL=scatter(1,mean_proc_vel_plus_ctl_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_dist(hn).dotColor);
hold on,
scPlot_minusRL=scatter(1,mean_proc_vel_minus_ctl_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_dist(hn).dotColor);
hold on,
end


b1=bar(2, bmu_vel_plus_dist_ko,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e1=errorbar(2,bmu_vel_plus_dist_ko,bci_vel_plus_dist_ko(1)-bmu_vel_plus_dist_ko,bci_vel_plus_dist_ko(2)-bmu_vel_plus_dist_ko,'k','linestyle','none')';
b2=bar(2, bmu_vel_minus_dist_ko,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e2=errorbar(2,bmu_vel_minus_dist_ko,bci_vel_minus_dist_ko(1)-bmu_vel_minus_dist_ko,bci_vel_minus_dist_ko(2)-bmu_vel_minus_dist_ko,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ko_dist)
hold on,
scPlot_plusRL=scatter(2,mean_proc_vel_plus_ko_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ko_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ko_dist(hn).dotColor);
hold on,
scPlot_minusRL=scatter(2,mean_proc_vel_minus_ko_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ko_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ko_dist(hn).dotColor);
hold on,
end

b1=bar(3, bmu_vel_plus_dist_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e1=errorbar(3,bmu_vel_plus_dist_wt,bci_vel_plus_dist_wt(1)-bmu_vel_plus_dist_wt,bci_vel_plus_dist_wt(2)-bmu_vel_plus_dist_wt,'k','linestyle','none')';
b2=bar(3, bmu_vel_minus_dist_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e2=errorbar(3,bmu_vel_minus_dist_wt,bci_vel_minus_dist_wt(1)-bmu_vel_minus_dist_wt,bci_vel_minus_dist_wt(2)-bmu_vel_minus_dist_wt,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ap_dist)
hold on,
scPlot_plusRL=scatter(3,mean_proc_vel_plus_ap_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ap_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_dist(hn).dotColor);
hold on,
scPlot_minusRL=scatter(3,mean_proc_vel_minus_ap_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ap_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_dist(hn).dotColor);
hold on,
end

b1=bar(4, bmu_vel_plus_dist_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e1=errorbar(4,bmu_vel_plus_dist_ap,bci_vel_plus_dist_ap(1)-bmu_vel_plus_dist_ap,bci_vel_plus_dist_ap(2)-bmu_vel_plus_dist_ap,'k','linestyle','none')';
b2=bar(4, bmu_vel_minus_dist_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e2=errorbar(4,bmu_vel_minus_dist_ap,bci_vel_minus_dist_ap(1)-bmu_vel_minus_dist_ap,bci_vel_minus_dist_ap(2)-bmu_vel_minus_dist_ap,'k','linestyle','none')';
hold on,
for hn=1:length(ba_ap_dist)
hold on,
scPlot_plusRL=scatter(4,mean_proc_vel_plus_ap_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ap_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_dist(hn).dotColor);
hold on,
scPlot_minusRL=scatter(4,mean_proc_vel_minus_ap_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%,1+2*N_proc_minus_tracks_ap_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_dist(hn).dotColor);
hold on,
end

b1=bar(5, bmu_vel_plus_dist_e14,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e1=errorbar(5,bmu_vel_plus_dist_e14,bci_vel_plus_dist_e14(1)-bmu_vel_plus_dist_e14,bci_vel_plus_dist_e14(2)-bmu_vel_plus_dist_e14,'k','linestyle','none')';
b2=bar(5, bmu_vel_minus_dist_e14,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e2=errorbar(5,bmu_vel_minus_dist_e14,bci_vel_minus_dist_e14(1)-bmu_vel_minus_dist_e14,bci_vel_minus_dist_e14(2)-bmu_vel_minus_dist_e14,'k','linestyle','none')';
 hold on,
for hn=1:length(ba_e14_dist)
hold on,
scPlot_plusRL=scatter(5,mean_proc_vel_plus_e_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_e_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_e14_dist(hn).dotColor);
hold on,
scPlot_minusRL=scatter(5,mean_proc_vel_minus_e_dist(hn),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_e_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_e14_dist(hn).dotColor);
hold on,
end

  ylim([-3.0 3]);
 ylabel('mean velocity (um/s)'); xlabel('distal');
xticks([1,2,3,4,5]); set(gca,'xticklabel',{'CTL','KO','WT','AP','E14'});

 
 %% fraction of processive, stationary, and diffusive over total time, 

  
 
 x=[1 2 3 4 5];
 
 y_prox=[mean(sum_proc_time_ctl_prox) mean(sum_diff_time_ctl_prox) mean(sum_stat_time_ctl_prox);...
         mean(sum_proc_time_ko_prox)  mean(sum_diff_time_ko_prox)  mean(sum_stat_time_ko_prox);...
         nanmean(sum_proc_time_wt_prox)  nanmean(sum_diff_time_wt_prox)  nanmean(sum_stat_time_wt_prox);...
         nanmean(sum_proc_time_ap_prox)  nanmean(sum_diff_time_ap_prox)  nanmean(sum_stat_time_ap_prox);...
         nanmean(sum_proc_time_e_prox)   nanmean(sum_diff_time_e_prox)   nanmean(sum_stat_time_e_prox)];

y_prox_all=[mean(sum_proc_time_ctl_all) mean(sum_diff_time_ctl_all) mean(sum_stat_time_ctl_all);...
         mean(sum_proc_time_ko_all)  mean(sum_diff_time_ko_all)  mean(sum_stat_time_ko_all);...
         nanmean(sum_proc_time_wt_all)  nanmean(sum_diff_time_wt_all)  nanmean(sum_stat_time_wt_all);...
         nanmean(sum_proc_time_ap_all)  nanmean(sum_diff_time_ap_all)  nanmean(sum_stat_time_ap_all);...
         nanmean(sum_proc_time_e14_all)   nanmean(sum_diff_time_e14_all)   nanmean(sum_stat_time_e14_all)];


     %SEM = std(x)/sqrt(length(x));
     %nonan_len = length(x(~isnan(x)));
  SEM_Ebars_all=[std(sum_proc_time_ctl_all)/sqrt(length(sum_proc_time_ctl_all(~isnan(sum_proc_time_ctl_all)))) std(sum_diff_time_ctl_all)/sqrt(length(sum_diff_time_ctl_all(~isnan(sum_diff_time_ctl_all)))) std(sum_stat_time_ctl_all)/sqrt(length(sum_stat_time_ctl_all(~isnan(sum_stat_time_ctl_all))));...
                  std(sum_proc_time_ko_all)/sqrt(length(sum_proc_time_ko_all(~isnan(sum_proc_time_ko_all))))    std(sum_diff_time_ko_all)/sqrt(length(sum_diff_time_ko_all(~isnan(sum_diff_time_ko_all))))    std(sum_stat_time_ko_all)/sqrt(length(sum_stat_time_ko_all(~isnan(sum_stat_time_ko_all))));...
               nanstd(sum_proc_time_wt_all)/sqrt(length(sum_proc_time_wt_all(~isnan(sum_proc_time_wt_all))))   nanstd(sum_diff_time_wt_all)/sqrt(length(sum_diff_time_wt_all(~isnan(sum_diff_time_wt_all))))  nanstd(sum_stat_time_wt_all)/sqrt(length(sum_stat_time_wt_all(~isnan(sum_stat_time_wt_all))));...
               nanstd(sum_proc_time_ap_all)/sqrt(length(sum_proc_time_ap_all(~isnan(sum_proc_time_ap_all))))   nanstd(sum_diff_time_ap_all)/sqrt(length(sum_diff_time_ap_all(~isnan(sum_diff_time_ap_all))))  nanstd(sum_stat_time_ap_all)/sqrt(length(sum_stat_time_ap_all(~isnan(sum_stat_time_ap_all))));...
               nanstd(sum_proc_time_e14_all)/sqrt(length(sum_proc_time_e14_all(~isnan(sum_proc_time_e14_all))))      nanstd(sum_diff_time_e14_all)/sqrt(length(sum_diff_time_e14_all(~isnan(sum_diff_time_e14_all))))     nanstd(sum_stat_time_e14_all)/sqrt(length(sum_stat_time_e14_all(~isnan(sum_stat_time_e14_all))))];  
 
           
           
  SEM_Ebars_prox=[std(sum_proc_time_ctl_prox)/sqrt(length(sum_proc_time_ctl_prox(~isnan(sum_proc_time_ctl_prox)))) std(sum_diff_time_ctl_prox)/sqrt(length(sum_diff_time_ctl_prox(~isnan(sum_diff_time_ctl_prox)))) std(sum_stat_time_ctl_prox)/sqrt(length(sum_stat_time_ctl_prox(~isnan(sum_stat_time_ctl_prox))));...
                  std(sum_proc_time_ko_prox)/sqrt(length(sum_proc_time_ko_prox(~isnan(sum_proc_time_ko_prox))))    std(sum_diff_time_ko_prox)/sqrt(length(sum_diff_time_ko_prox(~isnan(sum_diff_time_ko_prox))))    std(sum_stat_time_ko_prox)/sqrt(length(sum_stat_time_ko_prox(~isnan(sum_stat_time_ko_prox))));...
               nanstd(sum_proc_time_wt_prox)/sqrt(length(sum_proc_time_wt_prox(~isnan(sum_proc_time_wt_prox))))   nanstd(sum_diff_time_wt_prox)/sqrt(length(sum_diff_time_wt_prox(~isnan(sum_diff_time_wt_prox))))  nanstd(sum_stat_time_wt_prox)/sqrt(length(sum_stat_time_wt_prox(~isnan(sum_stat_time_wt_prox))));...
               nanstd(sum_proc_time_ap_prox)/sqrt(length(sum_proc_time_ap_prox(~isnan(sum_proc_time_ap_prox))))   nanstd(sum_diff_time_ap_prox)/sqrt(length(sum_diff_time_ap_prox(~isnan(sum_diff_time_ap_prox))))  nanstd(sum_stat_time_ap_prox)/sqrt(length(sum_stat_time_ap_prox(~isnan(sum_stat_time_ap_prox))));...
               nanstd(sum_proc_time_e_prox)/sqrt(length(sum_proc_time_e_prox(~isnan(sum_proc_time_e_prox))))      nanstd(sum_diff_time_e_prox)/sqrt(length(sum_diff_time_e_prox(~isnan(sum_diff_time_e_prox))))     nanstd(sum_stat_time_e_prox)/sqrt(length(sum_stat_time_e_prox(~isnan(sum_stat_time_e_prox))))];  
     
y_mid=[mean(sum_proc_time_ctl_mid) mean(sum_diff_time_ctl_mid) mean(sum_stat_time_ctl_mid);...
       mean(sum_proc_time_ko_mid)  mean(sum_diff_time_ko_mid)  mean(sum_stat_time_ko_mid);...
       nanmean(sum_proc_time_wt_mid)  nanmean(sum_diff_time_wt_mid)  nanmean(sum_stat_time_wt_mid);...
       nanmean(sum_proc_time_ap_mid)  nanmean(sum_diff_time_ap_mid)  nanmean(sum_stat_time_ap_mid);...
       nanmean(sum_proc_time_e_mid)   nanmean(sum_diff_time_e_mid)   nanmean(sum_stat_time_e_mid)];

   SEM_Ebars_mid=[std(sum_proc_time_ctl_mid)/sqrt(length(sum_proc_time_ctl_mid(~isnan(sum_proc_time_ctl_mid)))) std(sum_diff_time_ctl_mid)/sqrt(length(sum_diff_time_ctl_mid(~isnan(sum_diff_time_ctl_mid)))) std(sum_stat_time_ctl_mid)/sqrt(length(sum_stat_time_ctl_mid(~isnan(sum_stat_time_ctl_mid))));...
                  std(sum_proc_time_ko_mid)/sqrt(length(sum_proc_time_ko_mid(~isnan(sum_proc_time_ko_mid))))    std(sum_diff_time_ko_mid)/sqrt(length(sum_diff_time_ko_mid(~isnan(sum_diff_time_ko_mid))))    std(sum_stat_time_ko_mid)/sqrt(length(sum_stat_time_ko_mid(~isnan(sum_stat_time_ko_mid))));...
               nanstd(sum_proc_time_wt_mid)/sqrt(length(sum_proc_time_wt_mid(~isnan(sum_proc_time_wt_mid))))   nanstd(sum_diff_time_wt_mid)/sqrt(length(sum_diff_time_wt_mid(~isnan(sum_diff_time_wt_mid))))  nanstd(sum_stat_time_wt_mid)/sqrt(length(sum_stat_time_wt_mid(~isnan(sum_stat_time_wt_mid))));...
               nanstd(sum_proc_time_ap_mid)/sqrt(length(sum_proc_time_ap_mid(~isnan(sum_proc_time_ap_mid))))   nanstd(sum_diff_time_ap_mid)/sqrt(length(sum_diff_time_ap_mid(~isnan(sum_diff_time_ap_mid))))  nanstd(sum_stat_time_ap_mid)/sqrt(length(sum_stat_time_ap_mid(~isnan(sum_stat_time_ap_mid))));...
               nanstd(sum_proc_time_e_mid)/sqrt(length(sum_proc_time_e_mid(~isnan(sum_proc_time_e_mid))))      nanstd(sum_diff_time_e_mid)/sqrt(length(sum_diff_time_e_mid(~isnan(sum_diff_time_e_mid))))     nanstd(sum_stat_time_e_mid)/sqrt(length(sum_stat_time_e_mid(~isnan(sum_stat_time_e_mid))))];  
     
y_dist=[mean(sum_proc_time_ctl_dist) mean(sum_diff_time_ctl_dist) mean(sum_stat_time_ctl_dist);...
       mean(sum_proc_time_ko_dist)  mean(sum_diff_time_ko_dist)  mean(sum_stat_time_ko_dist);...
       nanmean(sum_proc_time_wt_dist)  nanmean(sum_diff_time_wt_dist)  nanmean(sum_stat_time_wt_dist);...
       nanmean(sum_proc_time_ap_dist)  nanmean(sum_diff_time_ap_dist)  nanmean(sum_stat_time_ap_dist);...
       nanmean(sum_proc_time_e_dist)   nanmean(sum_diff_time_e_dist)   nanmean(sum_stat_time_e_dist)];
     
   SEM_Ebars_dist=[std(sum_proc_time_ctl_dist)/sqrt(length(sum_proc_time_ctl_dist(~isnan(sum_proc_time_ctl_dist)))) std(sum_diff_time_ctl_dist)/sqrt(length(sum_diff_time_ctl_dist(~isnan(sum_diff_time_ctl_dist)))) std(sum_stat_time_ctl_dist)/sqrt(length(sum_stat_time_ctl_dist(~isnan(sum_stat_time_ctl_dist))));...
                  std(sum_proc_time_ko_dist)/sqrt(length(sum_proc_time_ko_dist(~isnan(sum_proc_time_ko_dist))))    std(sum_diff_time_ko_dist)/sqrt(length(sum_diff_time_ko_dist(~isnan(sum_diff_time_ko_dist))))    std(sum_stat_time_ko_dist)/sqrt(length(sum_stat_time_ko_dist(~isnan(sum_stat_time_ko_dist))));...
               nanstd(sum_proc_time_wt_dist)/sqrt(length(sum_proc_time_wt_dist(~isnan(sum_proc_time_wt_dist))))   nanstd(sum_diff_time_wt_dist)/sqrt(length(sum_diff_time_wt_dist(~isnan(sum_diff_time_wt_dist))))  nanstd(sum_stat_time_wt_dist)/sqrt(length(sum_stat_time_wt_dist(~isnan(sum_stat_time_wt_dist))));...
               nanstd(sum_proc_time_ap_dist)/sqrt(length(sum_proc_time_ap_dist(~isnan(sum_proc_time_ap_dist))))   nanstd(sum_diff_time_ap_dist)/sqrt(length(sum_diff_time_ap_dist(~isnan(sum_diff_time_ap_dist))))  nanstd(sum_stat_time_ap_dist)/sqrt(length(sum_stat_time_ap_dist(~isnan(sum_stat_time_ap_dist))));...
               nanstd(sum_proc_time_e_dist)/sqrt(length(sum_proc_time_e_dist(~isnan(sum_proc_time_e_dist))))      nanstd(sum_diff_time_e_dist)/sqrt(length(sum_diff_time_e_dist(~isnan(sum_diff_time_e_dist))))     nanstd(sum_stat_time_e_dist)/sqrt(length(sum_stat_time_e_dist(~isnan(sum_stat_time_e_dist))))];  
          

figure('Name','Fraction of total time stacked V3_all regions ','NumberTitle','off'), 
subplot(2,3,4), % all conditions proximal
b=bar(x,y_prox_all,"stacked"); hold on, 
 errorbar(cumsum(y_prox_all')', SEM_Ebars_all,'.k');
 hold on,

ylim([0.0 0.15]); xlim([0 7]);
           
subplot(2,3,1), % all conditions proximal
b=bar(x,y_prox_all,"stacked"); hold on, 
 errorbar(cumsum(y_prox_all')',SEM_Ebars_all,'.k');
 hold on,

ylim([0.65 1.05]); xlim([0 7]);
        
           
           
           
figure('Name','Fraction of total time stacked V3 ','NumberTitle','off'), 
subplot(2,3,4), % all conditions proximal
b=bar(x,y_prox,"stacked"); hold on, 
 errorbar(cumsum(y_prox')', SEM_Ebars_prox,'.k');
 hold on,

ylim([0.0 0.4]); xlim([0 7]);

subplot(2,3,5), % all conditions proximal
b2=bar(x,y_mid,"stacked"); hold on,
 errorbar(cumsum(y_mid')',SEM_Ebars_mid,'.k');
 hold on,

ylim([0.0 0.4]); xlim([0 7]);

subplot(2,3,6), % all conditions proximal
b3=bar(x,y_dist,"stacked"); hold on,
 errorbar(cumsum(y_dist')',SEM_Ebars_dist,'.k');
 hold on,

ylim([0.0 0.4]); xlim([0 7]);
xticks([1 2 3 4 5]);
xticklabels({'CTL','KO','WT', 'AP', 'E14'});

subplot(2,3,1), % all conditions proximal
b=bar(x,y_prox,"stacked"); hold on, 
 errorbar(cumsum(y_prox')',SEM_Ebars_prox,'.k');
 hold on,

ylim([0.65 1.05]); xlim([0 7]);

subplot(2,3,2), % all conditions proximal
b2=bar(x,y_mid,"stacked"); hold on,
 errorbar(cumsum(y_mid')',SEM_Ebars_mid,'.k');
 hold on,

ylim([0.65 1.05]); xlim([0 7]);

subplot(2,3,3), % all conditions proximal
b3=bar(x,y_dist,"stacked"); hold on,
 errorbar(cumsum(y_dist')',SEM_Ebars_dist,'.k');
 hold on,

ylim([0.65 1.05]); xlim([0 7]);

     n_resamples=1000;
     
     sum_proc_time_ctl_prox= sum_proc_time_ctl_prox(~isnan(sum_proc_time_ctl_prox));
     sum_proc_time_ctl_mid= sum_proc_time_ctl_mid(~isnan(sum_proc_time_ctl_mid));
     sum_proc_time_ctl_dist= sum_proc_time_ctl_dist(~isnan(sum_proc_time_ctl_dist));
     
     sum_proc_time_ctl_prox= sum_proc_time_ctl_prox(sum_proc_time_ctl_prox~=0);
     sum_proc_time_ctl_mid= sum_proc_time_ctl_mid(sum_proc_time_ctl_mid~=0);
     sum_proc_time_ctl_dist= sum_proc_time_ctl_dist(sum_proc_time_ctl_dist~=0);

     sum_proc_time_ko_prox= sum_proc_time_ko_prox(~isnan(sum_proc_time_ko_prox));
     sum_proc_time_ko_mid= sum_proc_time_ko_mid(~isnan(sum_proc_time_ko_mid));
     sum_proc_time_ko_dist= sum_proc_time_ko_dist(~isnan(sum_proc_time_ko_dist));
     
     sum_proc_time_ko_prox= sum_proc_time_ko_prox(sum_proc_time_ko_prox~=0);
     sum_proc_time_ko_mid= sum_proc_time_ko_mid(sum_proc_time_ko_mid~=0);
     sum_proc_time_ko_dist= sum_proc_time_ko_dist(sum_proc_time_ko_dist~=0);

     sum_proc_time_wt_prox= sum_proc_time_wt_prox(~isnan(sum_proc_time_wt_prox));
     sum_proc_time_wt_mid= sum_proc_time_wt_mid(~isnan(sum_proc_time_wt_mid));
     sum_proc_time_wt_dist= sum_proc_time_wt_dist(~isnan(sum_proc_time_wt_dist));
     
     sum_proc_time_wt_prox= sum_proc_time_wt_prox(sum_proc_time_wt_prox~=0);
     sum_proc_time_wt_mid= sum_proc_time_wt_mid(sum_proc_time_wt_mid~=0);
     sum_proc_time_wt_dist= sum_proc_time_wt_dist(sum_proc_time_wt_dist~=0);

     sum_proc_time_ap_prox= sum_proc_time_ap_prox(~isnan(sum_proc_time_ap_prox));
     sum_proc_time_ap_mid= sum_proc_time_ap_mid(~isnan(sum_proc_time_ap_mid));
     sum_proc_time_ap_dist= sum_proc_time_ap_dist(~isnan(sum_proc_time_ap_dist));
     
     sum_proc_time_ap_prox= sum_proc_time_ap_prox(sum_proc_time_ap_prox~=0);
     sum_proc_time_ap_mid= sum_proc_time_ap_mid(sum_proc_time_ap_mid~=0);
     sum_proc_time_ap_dist= sum_proc_time_ap_dist(sum_proc_time_ap_dist~=0);

     sum_proc_time_e_prox= sum_proc_time_e_prox(~isnan(sum_proc_time_e_prox));
     sum_proc_time_e_mid= sum_proc_time_e_mid(~isnan(sum_proc_time_e_mid));
     sum_proc_time_e_dist= sum_proc_time_e_dist(~isnan(sum_proc_time_e_dist));
     
     sum_proc_time_e_prox= sum_proc_time_e_prox(sum_proc_time_e_prox~=0);
     sum_proc_time_e_mid= sum_proc_time_e_mid(sum_proc_time_e_mid~=0);
     sum_proc_time_e_dist= sum_proc_time_e_dist(sum_proc_time_e_dist~=0);

     %stat
     sum_stat_time_ctl_prox= sum_stat_time_ctl_prox(~isnan(sum_stat_time_ctl_prox));
     sum_stat_time_ctl_mid= sum_stat_time_ctl_mid(~isnan(sum_stat_time_ctl_mid));
     sum_stat_time_ctl_dist= sum_stat_time_ctl_dist(~isnan(sum_stat_time_ctl_dist));
     
     sum_stat_time_ko_prox= sum_stat_time_ko_prox(~isnan(sum_stat_time_ko_prox));
     sum_stat_time_ko_mid= sum_stat_time_ko_mid(~isnan(sum_stat_time_ko_mid));
     sum_stat_time_ko_dist= sum_stat_time_ko_dist(~isnan(sum_stat_time_ko_dist));
    
     sum_stat_time_wt_prox= sum_stat_time_wt_prox(~isnan(sum_stat_time_wt_prox));
     sum_stat_time_wt_mid= sum_stat_time_wt_mid(~isnan(sum_stat_time_wt_mid));
     sum_stat_time_wt_dist= sum_stat_time_wt_dist(~isnan(sum_stat_time_wt_dist));
     
     sum_stat_time_ap_prox= sum_stat_time_ap_prox(~isnan(sum_stat_time_ap_prox));
     sum_stat_time_ap_mid= sum_stat_time_ap_mid(~isnan(sum_stat_time_ap_mid));
     sum_stat_time_ap_dist= sum_stat_time_ap_dist(~isnan(sum_stat_time_ap_dist));
  
     sum_stat_time_e_prox= sum_stat_time_e_prox(~isnan(sum_stat_time_e_prox));
     sum_stat_time_e_mid= sum_stat_time_e_mid(~isnan(sum_stat_time_e_mid));
     sum_stat_time_e_dist= sum_stat_time_e_dist(~isnan(sum_stat_time_e_dist));
     
     %diff
     sum_diff_time_ctl_prox= sum_diff_time_ctl_prox(~isnan(sum_diff_time_ctl_prox));
     sum_diff_time_ctl_mid= sum_diff_time_ctl_mid(~isnan(sum_diff_time_ctl_mid));
     sum_diff_time_ctl_dist= sum_diff_time_ctl_dist(~isnan(sum_diff_time_ctl_dist));
     
     sum_diff_time_ko_prox= sum_diff_time_ko_prox(~isnan(sum_diff_time_ko_prox));
     sum_diff_time_ko_mid= sum_diff_time_ko_mid(~isnan(sum_diff_time_ko_mid));
     sum_diff_time_ko_dist= sum_diff_time_ko_dist(~isnan(sum_diff_time_ko_dist));
    
     sum_diff_time_wt_prox= sum_diff_time_wt_prox(~isnan(sum_diff_time_wt_prox));
     sum_diff_time_wt_mid= sum_diff_time_wt_mid(~isnan(sum_diff_time_wt_mid));
     sum_diff_time_wt_dist= sum_diff_time_wt_dist(~isnan(sum_diff_time_wt_dist));
     
     sum_diff_time_ap_prox= sum_diff_time_ap_prox(~isnan(sum_diff_time_ap_prox));
     sum_diff_time_ap_mid= sum_diff_time_ap_mid(~isnan(sum_diff_time_ap_mid));
     sum_diff_time_ap_dist= sum_diff_time_ap_dist(~isnan(sum_diff_time_ap_dist));
  
     sum_diff_time_e_prox= sum_diff_time_e_prox(~isnan(sum_diff_time_e_prox));
     sum_diff_time_e_mid= sum_diff_time_e_mid(~isnan(sum_diff_time_e_mid));
     sum_diff_time_e_dist= sum_diff_time_e_dist(~isnan(sum_diff_time_e_dist));
     
     
    
     %% Fraction of proc time all

     %% CTL mean FT
[bci_plus_proc_ft_ctl_all,bsums_plus_proc_ft_ctl_all]=bootci(nboot,{@nanmean, mean_proc_fracTime_plus_ctl_all},'alpha',.05,'type','per');
    bci_plus_proc_ft_ctl_all=bci_plus_proc_ft_ctl_all';
    bmu_plus_proc_ft_ctl_all = mean(bsums_plus_proc_ft_ctl_all);
    
[bci_minus_proc_ft_ctl_all,bsums_minus_proc_ft_ctl_all]=bootci(nboot,{@nanmean, mean_proc_fracTime_minus_ctl_all},'alpha',.05,'type','per');
    bci_minus_proc_ft_ctl_all=bci_minus_proc_ft_ctl_all';
    bmu_minus_proc_ft_ctl_all = mean(bsums_minus_proc_ft_ctl_all);

     %% KO mean FT
[bci_plus_proc_ft_ko_all,bsums_plus_proc_ft_ko_all]=bootci(nboot,{@nanmean, mean_proc_fracTime_plus_ko_all},'alpha',.05,'type','per');
    bci_plus_proc_ft_ko_all=bci_plus_proc_ft_ko_all';
    bmu_plus_proc_ft_ko_all = mean(bsums_plus_proc_ft_ko_all);
    
[bci_minus_proc_ft_ko_all,bsums_minus_proc_ft_ko_all]=bootci(nboot,{@nanmean, mean_proc_fracTime_minus_ko_all},'alpha',.05,'type','per');
    bci_minus_proc_ft_ko_all=bci_minus_proc_ft_ko_all';
    bmu_minus_proc_ft_ko_all = mean(bsums_minus_proc_ft_ko_all);

    %% WT mean FT
[bci_plus_proc_ft_wt_all,bsums_plus_proc_ft_wt_all]=bootci(nboot,{@nanmean, mean_proc_fracTime_plus_wt_all},'alpha',.05,'type','per');
    bci_plus_proc_ft_wt_all=bci_plus_proc_ft_wt_all';
    bmu_plus_proc_ft_wt_all = mean(bsums_plus_proc_ft_wt_all);
    
[bci_minus_proc_ft_wt_all,bsums_minus_proc_ft_wt_all]=bootci(nboot,{@nanmean, mean_proc_fracTime_minus_wt_all},'alpha',.05,'type','per');
    bci_minus_proc_ft_wt_all=bci_minus_proc_ft_wt_all';
    bmu_minus_proc_ft_wt_all = mean(bsums_minus_proc_ft_wt_all);

    %% AP mean FT
[bci_plus_proc_ft_ap_all,bsums_plus_proc_ft_ap_all]=bootci(nboot,{@nanmean, mean_proc_fracTime_plus_ap_all},'alpha',.05,'type','per');
    bci_plus_proc_ft_ap_all=bci_plus_proc_ft_ap_all';
    bmu_plus_proc_ft_ap_all = mean(bsums_plus_proc_ft_ap_all);
    
[bci_minus_proc_ft_ap_all,bsums_minus_proc_ft_ap_all]=bootci(nboot,{@nanmean, mean_proc_fracTime_minus_ap_all},'alpha',.05,'type','per');
    bci_minus_proc_ft_ap_all=bci_minus_proc_ft_ap_all';
    bmu_minus_proc_ft_ap_all = mean(bsums_minus_proc_ft_ap_all);

    %% E14 mean FT
[bci_plus_proc_ft_e14_all,bsums_plus_proc_ft_e14_all]=bootci(nboot,{@nanmean, mean_proc_fracTime_plus_e14_all},'alpha',.05,'type','per');
    bci_plus_proc_ft_e14_all=bci_plus_proc_ft_e14_all';
    bmu_plus_proc_ft_e14_all = mean(bsums_plus_proc_ft_e14_all);
    
[bci_minus_proc_ft_e14_all,bsums_minus_proc_ft_e14_all]=bootci(nboot,{@nanmean, mean_proc_fracTime_minus_e14_all},'alpha',.05,'type','per');
    bci_minus_proc_ft_e14_all=bci_minus_proc_ft_e14_all';
    bmu_minus_proc_ft_e14_all = mean(bsums_minus_proc_ft_e14_all);

  
       
figure('Name',strcat(' Fraction of time proc runs ALL regions v2'),'NumberTitle','off'),

subplot(1,3,1), hold on,
b1=bar(1, bmu_plus_proc_ft_ctl_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(1,bmu_plus_proc_ft_ctl_all,bci_plus_proc_ft_ctl_all(1)-bmu_plus_proc_ft_ctl_all,bci_plus_proc_ft_ctl_all(2)-bmu_plus_proc_ft_ctl_all,'k','linestyle','none')';
b2=bar(1, -bmu_minus_proc_ft_ctl_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(1,-bmu_minus_proc_ft_ctl_all,-(bci_minus_proc_ft_ctl_all(1)-bmu_minus_proc_ft_ctl_all),-(bci_minus_proc_ft_ctl_all(2)-bmu_minus_proc_ft_ctl_all),'k','linestyle','none')';
hold on,
for hn=1:length(ba_ctl_all)
hold on,
scPlot_plusRL=scatter(1,sum(ba_ctl_all(hn).proc_plus_time)./(sum(ba_ctl_all(hn).proc_plus_time)+sum(ba_ctl_all(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(1,-sum(ba_ctl_all(hn).proc_minus_time)./(sum(ba_ctl_all(hn).proc_plus_time)+sum(ba_ctl_all(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end

b1=bar(2, bmu_plus_proc_ft_ko_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(2,bmu_plus_proc_ft_ko_all,bci_plus_proc_ft_ko_all(1)-bmu_plus_proc_ft_ko_all,bci_plus_proc_ft_ko_all(2)-bmu_plus_proc_ft_ko_all,'k','linestyle','none')';
b2=bar(2, -bmu_minus_proc_ft_ko_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(2,-bmu_minus_proc_ft_ko_all,-(bci_minus_proc_ft_ko_all(1)-bmu_minus_proc_ft_ko_all),-(bci_minus_proc_ft_ko_all(2)-bmu_minus_proc_ft_ko_all),'k','linestyle','none')';
hold on,
for hn=1:length(ba_ko_all)
hold on,
scPlot_plusRL=scatter(2,sum(ba_ko_all(hn).proc_plus_time)./(sum(ba_ko_all(hn).proc_plus_time)+sum(ba_ko_all(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(2,-sum(ba_ko_all(hn).proc_minus_time)./(sum(ba_ko_all(hn).proc_plus_time)+sum(ba_ko_all(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end

b1=bar(3, bmu_plus_proc_ft_wt_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(3,bmu_plus_proc_ft_wt_all,bci_plus_proc_ft_wt_all(1)-bmu_plus_proc_ft_wt_all,bci_plus_proc_ft_wt_all(2)-bmu_plus_proc_ft_wt_all,'k','linestyle','none')';
b2=bar(3, -bmu_minus_proc_ft_wt_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(3,-bmu_minus_proc_ft_wt_all,-(bci_minus_proc_ft_wt_all(1)-bmu_minus_proc_ft_wt_all),-(bci_minus_proc_ft_wt_all(2)-bmu_minus_proc_ft_wt_all),'k','linestyle','none')';
hold on,
for hn=1:length(ba_wt_all)
hold on,
scPlot_plusRL=scatter(3,sum(ba_wt_all(hn).proc_plus_time)./(sum(ba_wt_all(hn).proc_plus_time)+sum(ba_wt_all(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(3,-sum(ba_wt_all(hn).proc_minus_time)./(sum(ba_wt_all(hn).proc_plus_time)+sum(ba_wt_all(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end

b1=bar(4, bmu_plus_proc_ft_ap_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(4,bmu_plus_proc_ft_ap_all,bci_plus_proc_ft_ap_all(1)-bmu_plus_proc_ft_ap_all,bci_plus_proc_ft_ap_all(2)-bmu_plus_proc_ft_ap_all,'k','linestyle','none')';
b2=bar(4, -bmu_minus_proc_ft_ap_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(4,-bmu_minus_proc_ft_ap_all,-(bci_minus_proc_ft_ap_all(1)-bmu_minus_proc_ft_ap_all),-(bci_minus_proc_ft_ap_all(2)-bmu_minus_proc_ft_ap_all),'k','linestyle','none')';
hold on,
for hn=1:length(ba_ap_all)
hold on,
scPlot_plusRL=scatter(4,sum(ba_ap_all(hn).proc_plus_time)./(sum(ba_ap_all(hn).proc_plus_time)+sum(ba_ap_all(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(4,-sum(ba_ap_all(hn).proc_minus_time)./(sum(ba_ap_all(hn).proc_plus_time)+sum(ba_ap_all(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end

b1=bar(5, bmu_plus_proc_ft_e14_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(5,bmu_plus_proc_ft_e14_all,bci_plus_proc_ft_e14_all(1)-bmu_plus_proc_ft_e14_all,bci_plus_proc_ft_e14_all(2)-bmu_plus_proc_ft_e14_all,'k','linestyle','none')';
b2=bar(5, -bmu_minus_proc_ft_e14_all,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(5,-bmu_minus_proc_ft_e14_all,-(bci_minus_proc_ft_e14_all(1)-bmu_minus_proc_ft_e14_all),-(bci_minus_proc_ft_e14_all(2)-bmu_minus_proc_ft_e14_all),'k','linestyle','none')';
hold on,
for hn=1:length(ba_e14_all)
hold on,
scPlot_plusRL=scatter(5,sum(ba_e14_all(hn).proc_plus_time)./(sum(ba_e14_all(hn).proc_plus_time)+sum(ba_e14_all(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(5,-sum(ba_e14_all(hn).proc_minus_time)./(sum(ba_e14_all(hn).proc_plus_time)+sum(ba_e14_all(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end


ylim([-1.0 1]);
 ylabel('fraction of time'); xlabel('all regions');
xticks([1,2,3,4,5]); set(gca,'xticklabel',{'CTL','KO','WT','AP','E14'});




%% fraction of processive time

figure('Name',strcat(' Fraction of time proc runs v2'),'NumberTitle','off'),

subplot(1,3,1), hold on,
b1=bar(1, bmu_proc_plus_prox_ctl,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(1,bmu_proc_plus_prox_ctl,bci_proc_plus_prox_ctl(1)-bmu_proc_plus_prox_ctl,bci_proc_plus_prox_ctl(2)-bmu_proc_plus_prox_ctl,'k','linestyle','none')';
b2=bar(1, -bmu_proc_minus_prox_ctl,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(1,-bmu_proc_minus_prox_ctl,-(bci_proc_minus_prox_ctl(1)-bmu_proc_minus_prox_ctl),-(bci_proc_minus_prox_ctl(2)-bmu_proc_minus_prox_ctl),'k','linestyle','none')';
hold on,
for hn=1:length(ba_ctl_prox)
hold on,
scPlot_plusRL=scatter(1,sum(ba_ctl_prox(hn).proc_plus_time)./(sum(ba_ctl_prox(hn).proc_plus_time)+sum(ba_ctl_prox(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(1,-sum(ba_ctl_prox(hn).proc_minus_time)./(sum(ba_ctl_prox(hn).proc_plus_time)+sum(ba_ctl_prox(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_prox(hn).dotColor);
hold on,
end


b1=bar(2, bmu_proc_plus_prox_ko,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(2,bmu_proc_plus_prox_ko,bci_proc_plus_prox_ko(1)-bmu_proc_plus_prox_ko,bci_proc_plus_prox_ko(2)-bmu_proc_plus_prox_ko,'k','linestyle','none')';
b2=bar(2, -bmu_proc_minus_prox_ko,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(2,-bmu_proc_minus_prox_ko,-(bci_proc_minus_prox_ko(1)-bmu_proc_minus_prox_ko),-(bci_proc_minus_prox_ko(2)-bmu_proc_minus_prox_ko),'k','linestyle','none')';
hold on,
for hn=1:length(ba_ko_prox)
hold on,
scPlot_plusRL=scatter(2,sum(ba_ko_prox(hn).proc_plus_time)./(sum(ba_ko_prox(hn).proc_plus_time)+sum(ba_ko_prox(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ko_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ko_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(2,-sum(ba_ko_prox(hn).proc_minus_time)./(sum(ba_ko_prox(hn).proc_plus_time)+sum(ba_ko_prox(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ko_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ko_prox(hn).dotColor);
hold on,
end

b1=bar(3, bmu_proc_plus_prox_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(3,bmu_proc_plus_prox_wt,bci_proc_plus_prox_wt(1)-bmu_proc_plus_prox_wt,bci_proc_plus_prox_wt(2)-bmu_proc_plus_prox_wt,'k','linestyle','none')';
b2=bar(3, -bmu_proc_minus_prox_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(3,-bmu_proc_minus_prox_wt,-(bci_proc_minus_prox_wt(1)-bmu_proc_minus_prox_wt),-(bci_proc_minus_prox_wt(2)-bmu_proc_minus_prox_wt),'k','linestyle','none')';
hold on,
for hn=1:length(ba_wt_prox)
hold on,
scPlot_plusRL=scatter(3,sum(ba_wt_prox(hn).proc_plus_time)./(sum(ba_wt_prox(hn).proc_plus_time)+sum(ba_wt_prox(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_wt_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_wt_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(3,-sum(ba_wt_prox(hn).proc_minus_time)./(sum(ba_wt_prox(hn).proc_plus_time)+sum(ba_wt_prox(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_wt_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_wt_prox(hn).dotColor);
hold on,
end

b1=bar(4, bmu_proc_plus_prox_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(4,bmu_proc_plus_prox_ap,bci_proc_plus_prox_ap(1)-bmu_proc_plus_prox_ap,bci_proc_plus_prox_ap(2)-bmu_proc_plus_prox_ap,'k','linestyle','none')';
b2=bar(4, -bmu_proc_minus_prox_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(4,-bmu_proc_minus_prox_ap,-(bci_proc_minus_prox_ap(1)-bmu_proc_minus_prox_ap),-(bci_proc_minus_prox_ap(2)-bmu_proc_minus_prox_ap),'k','linestyle','none')';
hold on,
for hn=1:length(ba_ap_prox)
hold on,
scPlot_plusRL=scatter(4,sum(ba_ap_prox(hn).proc_plus_time)./(sum(ba_ap_prox(hn).proc_plus_time)+sum(ba_ap_prox(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ap_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(4,-sum(ba_ap_prox(hn).proc_minus_time)./(sum(ba_ap_prox(hn).proc_plus_time)+sum(ba_ap_prox(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ap_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_prox(hn).dotColor);
hold on,
end

b1=bar(5, bmu_proc_plus_prox_e14,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(5,bmu_proc_plus_prox_e14,bci_proc_plus_prox_e14(1)-bmu_proc_plus_prox_e14,bci_proc_plus_prox_e14(2)-bmu_proc_plus_prox_e14,'k','linestyle','none')';
b2=bar(5, -bmu_proc_minus_prox_e14,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e2=errorbar(5,-bmu_proc_minus_prox_e14,-(bci_proc_minus_prox_e14(1)-bmu_proc_minus_prox_e14),-(bci_proc_minus_prox_e14(2)-bmu_proc_minus_prox_e14),'k','linestyle','none')';
hold on,
for hn=1:length(ba_e14_prox)
hold on,
scPlot_plusRL=scatter(5,sum(ba_e14_prox(hn).proc_plus_time)./(sum(ba_e14_prox(hn).proc_plus_time)+sum(ba_e14_prox(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_e_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_e14_prox(hn).dotColor);
hold on,
scPlot_minusRL=scatter(5,-sum(ba_e14_prox(hn).proc_minus_time)./(sum(ba_e14_prox(hn).proc_plus_time)+sum(ba_e14_prox(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_e_prox((hn)), 'Jitter','on', 'MarkerFaceColor',ba_e14_prox(hn).dotColor);
hold on,
end
ylim([-1.0 1]);
 ylabel('fraction of time'); xlabel('proximal');
xticks([1,2,3,4,5]); set(gca,'xticklabel',{'CTL','KO','WT','AP','E14'});


subplot(1,3,2), hold on,
b1=bar(1, bmu_proc_plus_mid_ctl,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e1=errorbar(1,bmu_proc_plus_mid_ctl,bci_proc_plus_mid_ctl(1)-bmu_proc_plus_mid_ctl,bci_proc_plus_mid_ctl(2)-bmu_proc_plus_mid_ctl,'k','linestyle','none')';
b2=bar(1, -bmu_proc_minus_mid_ctl,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e2=errorbar(1,-bmu_proc_minus_mid_ctl,-(bci_proc_minus_mid_ctl(1)-bmu_proc_minus_mid_ctl),-(bci_proc_minus_mid_ctl(2)-bmu_proc_minus_mid_ctl),'k','linestyle','none')';
hold on,
for hn=1:length(ba_ctl_mid)
hold on,
scPlot_plusRL=scatter(1,sum(ba_ctl_mid(hn).proc_plus_time)./(sum(ba_ctl_mid(hn).proc_plus_time)+sum(ba_ctl_mid(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_mid(hn).dotColor);
hold on,
scPlot_minusRL=scatter(1,-sum(ba_ctl_mid(hn).proc_minus_time)./(sum(ba_ctl_mid(hn).proc_plus_time)+sum(ba_ctl_mid(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_mid(hn).dotColor);
hold on,
end


b1=bar(2, bmu_proc_plus_mid_ko,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e1=errorbar(2,bmu_proc_plus_mid_ko,bci_proc_plus_mid_ko(1)-bmu_proc_plus_mid_ko,bci_proc_plus_mid_ko(2)-bmu_proc_plus_mid_ko,'k','linestyle','none')';
b2=bar(2, -bmu_proc_minus_mid_ko,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e2=errorbar(2,-bmu_proc_minus_mid_ko,-(bci_proc_minus_mid_ko(1)-bmu_proc_minus_mid_ko),-(bci_proc_minus_mid_ko(2)-bmu_proc_minus_mid_ko),'k','linestyle','none')';
hold on,
for hn=1:length(ba_ko_mid)
hold on,
scPlot_plusRL=scatter(2,sum(ba_ko_mid(hn).proc_plus_time)./(sum(ba_ko_mid(hn).proc_plus_time)+sum(ba_ko_mid(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ko_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ko_mid(hn).dotColor);
hold on,
scPlot_minusRL=scatter(2,-sum(ba_ko_mid(hn).proc_minus_time)./(sum(ba_ko_mid(hn).proc_plus_time)+sum(ba_ko_mid(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ko_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ko_mid(hn).dotColor);
hold on,
end

b1=bar(3, bmu_proc_plus_mid_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e1=errorbar(3,bmu_proc_plus_mid_wt,bci_proc_plus_mid_wt(1)-bmu_proc_plus_mid_wt,bci_proc_plus_mid_wt(2)-bmu_proc_plus_mid_wt,'k','linestyle','none')';
b2=bar(3, -bmu_proc_minus_mid_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e2=errorbar(3,-bmu_proc_minus_mid_wt,-(bci_proc_minus_mid_wt(1)-bmu_proc_minus_mid_wt),-(bci_proc_minus_mid_wt(2)-bmu_proc_minus_mid_wt),'k','linestyle','none')';
hold on,
for hn=1:length(ba_wt_mid)
hold on,
scPlot_plusRL=scatter(3,sum(ba_wt_mid(hn).proc_plus_time)./(sum(ba_wt_mid(hn).proc_plus_time)+sum(ba_wt_mid(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_wt_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_wt_mid(hn).dotColor);
hold on,
scPlot_minusRL=scatter(3,-sum(ba_wt_mid(hn).proc_minus_time)./(sum(ba_wt_mid(hn).proc_plus_time)+sum(ba_wt_mid(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_wt_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_wt_mid(hn).dotColor);
hold on,
end

b1=bar(4, bmu_proc_plus_mid_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e1=errorbar(4,bmu_proc_plus_mid_ap,bci_proc_plus_mid_ap(1)-bmu_proc_plus_mid_ap,bci_proc_plus_mid_ap(2)-bmu_proc_plus_mid_ap,'k','linestyle','none')';
b2=bar(4, -bmu_proc_minus_mid_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e2=errorbar(4,-bmu_proc_minus_mid_ap,-(bci_proc_minus_mid_ap(1)-bmu_proc_minus_mid_ap),-(bci_proc_minus_mid_ap(2)-bmu_proc_minus_mid_ap),'k','linestyle','none')';
hold on,
for hn=1:length(ba_ap_mid)
hold on,
scPlot_plusRL=scatter(4,sum(ba_ap_mid(hn).proc_plus_time)./(sum(ba_ap_mid(hn).proc_plus_time)+sum(ba_ap_mid(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ap_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_mid(hn).dotColor);
hold on,
scPlot_minusRL=scatter(4,-sum(ba_ap_mid(hn).proc_minus_time)./(sum(ba_ap_mid(hn).proc_plus_time)+sum(ba_ap_mid(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ap_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_mid(hn).dotColor);
hold on,
end

b1=bar(5, bmu_proc_plus_mid_e14,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e1=errorbar(5,bmu_proc_plus_mid_e14,bci_proc_plus_mid_e14(1)-bmu_proc_plus_mid_e14,bci_proc_plus_mid_e14(2)-bmu_proc_plus_mid_e14,'k','linestyle','none')';
b2=bar(5, -bmu_proc_minus_mid_e14,'BarWidth',0.9,'Facealpha',1, 'FaceColor', midColor);
e2=errorbar(5,-bmu_proc_minus_mid_e14,-(bci_proc_minus_mid_e14(1)-bmu_proc_minus_mid_e14),-(bci_proc_minus_mid_e14(2)-bmu_proc_minus_mid_e14),'k','linestyle','none')';
hold on,
for hn=1:length(ba_e14_mid)
hold on,
scPlot_plusRL=scatter(5,sum(ba_e14_mid(hn).proc_plus_time)./(sum(ba_e14_mid(hn).proc_plus_time)+sum(ba_e14_mid(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_e_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_e14_mid(hn).dotColor);
hold on,
scPlot_minusRL=scatter(5,-sum(ba_e14_mid(hn).proc_minus_time)./(sum(ba_e14_mid(hn).proc_plus_time)+sum(ba_e14_mid(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_e_mid((hn)), 'Jitter','on', 'MarkerFaceColor',ba_e14_mid(hn).dotColor);
hold on,
end


ylim([-1 1]);
 ylabel('fraction of time'); xlabel('mid');
xticks([1,2,3,4,5]); set(gca,'xticklabel',{'CTL','KO','WT','AP','E14'});


subplot(1,3,3), hold on,
b1=bar(1, bmu_proc_plus_dist_ctl,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e1=errorbar(1,bmu_proc_plus_dist_ctl,bci_proc_plus_dist_ctl(1)-bmu_proc_plus_dist_ctl,bci_proc_plus_dist_ctl(2)-bmu_proc_plus_dist_ctl,'k','linestyle','none')';
b2=bar(1, -bmu_proc_minus_dist_ctl,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e2=errorbar(1,-bmu_proc_minus_dist_ctl,-(bci_proc_minus_dist_ctl(1)-bmu_proc_minus_dist_ctl),-(bci_proc_minus_dist_ctl(2)-bmu_proc_minus_dist_ctl),'k','linestyle','none')';
hold on,
for hn=1:length(ba_ctl_dist)
hold on,
scPlot_plusRL=scatter(1,sum(ba_ctl_dist(hn).proc_plus_time)./(sum(ba_ctl_dist(hn).proc_plus_time)+sum(ba_ctl_dist(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ctl_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_dist(hn).dotColor);
hold on,
scPlot_minusRL=scatter(1,-sum(ba_ctl_dist(hn).proc_minus_time)./(sum(ba_ctl_dist(hn).proc_plus_time)+sum(ba_ctl_dist(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ctl_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ctl_dist(hn).dotColor);
hold on,
end

b1=bar(2, bmu_proc_plus_dist_ko,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e1=errorbar(2,bmu_proc_plus_dist_ko,bci_proc_plus_dist_ko(1)-bmu_proc_plus_dist_ko,bci_proc_plus_dist_ko(2)-bmu_proc_plus_dist_ko,'k','linestyle','none')';
b2=bar(2, -bmu_proc_minus_dist_ko,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e2=errorbar(2,-bmu_proc_minus_dist_ko,-(bci_proc_minus_dist_ko(1)-bmu_proc_minus_dist_ko),-(bci_proc_minus_dist_ko(2)-bmu_proc_minus_dist_ko),'k','linestyle','none')';
hold on,
for hn=1:length(ba_ko_dist)
hold on,
scPlot_plusRL=scatter(2,sum(ba_ko_dist(hn).proc_plus_time)./(sum(ba_ko_dist(hn).proc_plus_time)+sum(ba_ko_dist(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ko_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ko_dist(hn).dotColor);
hold on,
scPlot_minusRL=scatter(2,-sum(ba_ko_dist(hn).proc_minus_time)./(sum(ba_ko_dist(hn).proc_plus_time)+sum(ba_ko_dist(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ko_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ko_dist(hn).dotColor);
hold on,
end

b1=bar(3, bmu_proc_plus_dist_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e1=errorbar(3,bmu_proc_plus_dist_wt,bci_proc_plus_dist_wt(1)-bmu_proc_plus_dist_wt,bci_proc_plus_dist_wt(2)-bmu_proc_plus_dist_wt,'k','linestyle','none')';
b2=bar(3, -bmu_proc_minus_dist_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e2=errorbar(3,-bmu_proc_minus_dist_wt,-(bci_proc_minus_dist_wt(1)-bmu_proc_minus_dist_wt),-(bci_proc_minus_dist_wt(2)-bmu_proc_minus_dist_wt),'k','linestyle','none')';
hold on,
for hn=1:length(ba_wt_dist)
hold on,
scPlot_plusRL=scatter(3,sum(ba_wt_dist(hn).proc_plus_time)./(sum(ba_wt_dist(hn).proc_plus_time)+sum(ba_wt_dist(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_wt_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_wt_dist(hn).dotColor);
hold on,
scPlot_minusRL=scatter(3,-sum(ba_wt_dist(hn).proc_minus_time)./(sum(ba_wt_dist(hn).proc_plus_time)+sum(ba_wt_dist(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_wt_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_wt_dist(hn).dotColor);
hold on,
end

b1=bar(4, bmu_proc_plus_dist_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e1=errorbar(4,bmu_proc_plus_dist_ap,bci_proc_plus_dist_ap(1)-bmu_proc_plus_dist_ap,bci_proc_plus_dist_ap(2)-bmu_proc_plus_dist_ap,'k','linestyle','none')';
b2=bar(4, -bmu_proc_minus_dist_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e2=errorbar(4,-bmu_proc_minus_dist_ap,-(bci_proc_minus_dist_ap(1)-bmu_proc_minus_dist_ap),-(bci_proc_minus_dist_ap(2)-bmu_proc_minus_dist_ap),'k','linestyle','none')';
hold on,
for hn=1:length(ba_ap_dist)
hold on,
scPlot_plusRL=scatter(4,sum(ba_ap_dist(hn).proc_plus_time)./(sum(ba_ap_dist(hn).proc_plus_time)+sum(ba_ap_dist(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_ap_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_dist(hn).dotColor);
hold on,
scPlot_minusRL=scatter(4,-sum(ba_ap_dist(hn).proc_minus_time)./(sum(ba_ap_dist(hn).proc_plus_time)+sum(ba_ap_dist(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_ap_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_ap_dist(hn).dotColor);
hold on,
end

b1=bar(5, bmu_proc_plus_dist_e14,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e1=errorbar(5,bmu_proc_plus_dist_e14,bci_proc_plus_dist_e14(1)-bmu_proc_plus_dist_e14,bci_proc_plus_dist_e14(2)-bmu_proc_plus_dist_e14,'k','linestyle','none')';
b2=bar(5, -bmu_proc_minus_dist_e14,'BarWidth',0.9,'Facealpha',1, 'FaceColor', distColor);
e2=errorbar(5,-bmu_proc_minus_dist_e14,-(bci_proc_minus_dist_e14(1)-bmu_proc_minus_dist_e14),-(bci_proc_minus_dist_e14(2)-bmu_proc_minus_dist_e14),'k','linestyle','none')';
hold on,
for hn=1:length(ba_e14_dist)
hold on,
scPlot_plusRL=scatter(5,sum(ba_e14_dist(hn).proc_plus_time)./(sum(ba_e14_dist(hn).proc_plus_time)+sum(ba_e14_dist(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_plus_tracks_e_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_e14_dist(hn).dotColor);
hold on,
scPlot_minusRL=scatter(5,-sum(ba_e14_dist(hn).proc_minus_time)./(sum(ba_e14_dist(hn).proc_plus_time)+sum(ba_e14_dist(hn).proc_minus_time)),10, 'Jitter','on','MarkerFaceColor',mdGrey,'MarkerEdgeColor',mdGrey);%1+2*N_proc_minus_tracks_e_dist((hn)), 'Jitter','on', 'MarkerFaceColor',ba_e14_dist(hn).dotColor);
hold on,
end
hold on,
  ylim([-1 1]);
 ylabel('fraction of time'); xlabel('distal');
xticks([1,2,3,4,5]); set(gca,'xticklabel',{'CTL','KO','WT','AP','E14'});





%% input fract time into tables

%ctl
for hn=1:length(ba_ctl_prox)
sc_plus_time_ctl_prox(hn)=sum(ba_ctl_prox(hn).proc_plus_time)./(sum(ba_ctl_prox(hn).proc_plus_time)+sum(ba_ctl_prox(hn).proc_minus_time));
sc_minus_time_ctl_prox(hn)=sum(ba_ctl_prox(hn).proc_minus_time)./(sum(ba_ctl_prox(hn).proc_plus_time)+sum(ba_ctl_prox(hn).proc_minus_time));
end

for hn=1:length(ba_ctl_mid)
sc_plus_time_ctl_mid(hn)=sum(ba_ctl_mid(hn).proc_plus_time)./(sum(ba_ctl_mid(hn).proc_plus_time)+sum(ba_ctl_mid(hn).proc_minus_time));
sc_minus_time_ctl_mid(hn)=sum(ba_ctl_mid(hn).proc_minus_time)./(sum(ba_ctl_mid(hn).proc_plus_time)+sum(ba_ctl_mid(hn).proc_minus_time));
end

for hn=1:length(ba_ctl_dist)
sc_plus_time_ctl_dist(hn)=sum(ba_ctl_dist(hn).proc_plus_time)./(sum(ba_ctl_dist(hn).proc_plus_time)+sum(ba_ctl_dist(hn).proc_minus_time));
sc_minus_time_ctl_dist(hn)=sum(ba_ctl_dist(hn).proc_minus_time)./(sum(ba_ctl_dist(hn).proc_plus_time)+sum(ba_ctl_dist(hn).proc_minus_time));
end

%ko
for hn=1:length(ba_ko_prox)
sc_plus_time_ko_prox(hn)=sum(ba_ko_prox(hn).proc_plus_time)./(sum(ba_ko_prox(hn).proc_plus_time)+sum(ba_ko_prox(hn).proc_minus_time));
sc_minus_time_ko_prox(hn)=sum(ba_ko_prox(hn).proc_minus_time)./(sum(ba_ko_prox(hn).proc_plus_time)+sum(ba_ko_prox(hn).proc_minus_time));
end

for hn=1:length(ba_ko_mid)
sc_plus_time_ko_mid(hn)=sum(ba_ko_mid(hn).proc_plus_time)./(sum(ba_ko_mid(hn).proc_plus_time)+sum(ba_ko_mid(hn).proc_minus_time));
sc_minus_time_ko_mid(hn)=sum(ba_ko_mid(hn).proc_minus_time)./(sum(ba_ko_mid(hn).proc_plus_time)+sum(ba_ko_mid(hn).proc_minus_time));
end

for hn=1:length(ba_ko_dist)
sc_plus_time_ko_dist(hn)=sum(ba_ko_dist(hn).proc_plus_time)./(sum(ba_ko_dist(hn).proc_plus_time)+sum(ba_ko_dist(hn).proc_minus_time));
sc_minus_time_ko_dist(hn)=sum(ba_ko_dist(hn).proc_minus_time)./(sum(ba_ko_dist(hn).proc_plus_time)+sum(ba_ko_dist(hn).proc_minus_time));
end

%wt
for hn=1:length(ba_wt_prox)
sc_plus_time_wt_prox(hn)=sum(ba_wt_prox(hn).proc_plus_time)./(sum(ba_wt_prox(hn).proc_plus_time)+sum(ba_wt_prox(hn).proc_minus_time));
sc_minus_time_wt_prox(hn)=sum(ba_wt_prox(hn).proc_minus_time)./(sum(ba_wt_prox(hn).proc_plus_time)+sum(ba_wt_prox(hn).proc_minus_time));
end

for hn=1:length(ba_wt_mid)
sc_plus_time_wt_mid(hn)=sum(ba_wt_mid(hn).proc_plus_time)./(sum(ba_wt_mid(hn).proc_plus_time)+sum(ba_wt_mid(hn).proc_minus_time));
sc_minus_time_wt_mid(hn)=sum(ba_wt_mid(hn).proc_minus_time)./(sum(ba_wt_mid(hn).proc_plus_time)+sum(ba_wt_mid(hn).proc_minus_time));
end

for hn=1:length(ba_wt_dist)
sc_plus_time_wt_dist(hn)=sum(ba_wt_dist(hn).proc_plus_time)./(sum(ba_wt_dist(hn).proc_plus_time)+sum(ba_wt_dist(hn).proc_minus_time));
sc_minus_time_wt_dist(hn)=sum(ba_wt_dist(hn).proc_minus_time)./(sum(ba_wt_dist(hn).proc_plus_time)+sum(ba_wt_dist(hn).proc_minus_time));
end

%ap
for hn=1:length(ba_ap_prox)
sc_plus_time_ap_prox(hn)=sum(ba_ap_prox(hn).proc_plus_time)./(sum(ba_ap_prox(hn).proc_plus_time)+sum(ba_ap_prox(hn).proc_minus_time));
sc_minus_time_ap_prox(hn)=sum(ba_ap_prox(hn).proc_minus_time)./(sum(ba_ap_prox(hn).proc_plus_time)+sum(ba_ap_prox(hn).proc_minus_time));
end

for hn=1:length(ba_ap_mid)
sc_plus_time_ap_mid(hn)=sum(ba_ap_mid(hn).proc_plus_time)./(sum(ba_ap_mid(hn).proc_plus_time)+sum(ba_ap_mid(hn).proc_minus_time));
sc_minus_time_ap_mid(hn)=sum(ba_ap_mid(hn).proc_minus_time)./(sum(ba_ap_mid(hn).proc_plus_time)+sum(ba_ap_mid(hn).proc_minus_time));
end

for hn=1:length(ba_ap_dist)
sc_plus_time_ap_dist(hn)=sum(ba_ap_dist(hn).proc_plus_time)./(sum(ba_ap_dist(hn).proc_plus_time)+sum(ba_ap_dist(hn).proc_minus_time));
sc_minus_time_ap_dist(hn)=sum(ba_ap_dist(hn).proc_minus_time)./(sum(ba_ap_dist(hn).proc_plus_time)+sum(ba_ap_dist(hn).proc_minus_time));
end

%e14
for hn=1:length(ba_e14_prox)
sc_plus_time_e14_prox(hn)=sum(ba_e14_prox(hn).proc_plus_time)./(sum(ba_e14_prox(hn).proc_plus_time)+sum(ba_e14_prox(hn).proc_minus_time));
sc_minus_time_e14_prox(hn)=sum(ba_e14_prox(hn).proc_minus_time)./(sum(ba_e14_prox(hn).proc_plus_time)+sum(ba_e14_prox(hn).proc_minus_time));
end

for hn=1:length(ba_e14_mid)
sc_plus_time_e14_mid(hn)=sum(ba_e14_mid(hn).proc_plus_time)./(sum(ba_e14_mid(hn).proc_plus_time)+sum(ba_e14_mid(hn).proc_minus_time));
sc_minus_time_e14_mid(hn)=sum(ba_e14_mid(hn).proc_minus_time)./(sum(ba_e14_mid(hn).proc_plus_time)+sum(ba_e14_mid(hn).proc_minus_time));
end

for hn=1:length(ba_e14_dist)
sc_plus_time_e14_dist(hn)=sum(ba_e14_dist(hn).proc_plus_time)./(sum(ba_e14_dist(hn).proc_plus_time)+sum(ba_e14_dist(hn).proc_minus_time));
sc_minus_time_e14_dist(hn)=sum(ba_e14_dist(hn).proc_minus_time)./(sum(ba_e14_dist(hn).proc_plus_time)+sum(ba_e14_dist(hn).proc_minus_time));
end

boot_rep=10000;





%prox
for vv=1:length(ba_ctl_prox)
ctl_prox_nlpm(vv) = mean(ba_ctl_prox(vv).num_lysosomes)./(ba_ctl_prox(vv).axon_length);
end
 mean_ctl_prox_nlpm = mean(ctl_prox_nlpm);
 
 for vv=1:length(ba_ko_prox)
ko_prox_nlpm(vv) = mean(ba_ko_prox(vv).num_lysosomes)./(ba_ko_prox(vv).axon_length);
end
 mean_ko_prox_nlpm = mean(ko_prox_nlpm);
 
 %mid
for vv=1:length(ba_ctl_mid)
ctl_mid_nlpm(vv) = mean(ba_ctl_mid(vv).num_lysosomes)./(ba_ctl_mid(vv).axon_length);
end
 mean_ctl_mid_nlpm = mean(ctl_mid_nlpm);
 
for vv=1:length(ba_ko_mid)
ko_mid_nlpm(vv) = mean(ba_ko_mid(vv).num_lysosomes)./(ba_ko_mid(vv).axon_length);
end
 mean_ko_mid_nlpm = mean(ko_mid_nlpm);
 
 %dist
for vv=1:length(ba_ctl_dist)
ctl_dist_nlpm(vv) = mean(ba_ctl_dist(vv).num_lysosomes)./(ba_ctl_dist(vv).axon_length);
end
 mean_ctl_dist_nlpm = mean(ctl_dist_nlpm);
 
for vv=1:length(ba_ko_dist)
ko_dist_nlpm(vv) = mean(ba_ko_dist(vv).num_lysosomes)./(ba_ko_dist(vv).axon_length);
end
 mean_ko_dist_nlpm = mean(ko_dist_nlpm);
 
 
%ctl 
 for vi=1:length(ba_ctl_prox)
    ctl_prox_numlys(vi) = (ba_ctl_prox(vi).num_lysosomes)./(ba_ctl_prox(vi).axon_length)';
end
 
 for vi=1:length(ba_ctl_mid)
    ctl_mid_numlys(vi) = (ba_ctl_mid(vi).num_lysosomes)./(ba_ctl_mid(vi).axon_length)';
end
 
 for vi=1:length(ba_ctl_dist)
    ctl_dist_numlys(vi) = (ba_ctl_dist(vi).num_lysosomes)./(ba_ctl_dist(vi).axon_length)';
end
 
 %ko
  for vi=1:length(ba_ko_prox)
    ko_prox_numlys(vi) = (ba_ko_prox(vi).num_lysosomes)./(ba_ko_prox(vi).axon_length)';
end
 
 for vi=1:length(ba_ko_mid)
    ko_mid_numlys(vi) = (ba_ko_mid(vi).num_lysosomes)./(ba_ko_mid(vi).axon_length)';
end
 
 for vi=1:length(ba_ko_dist)
    ko_dist_numlys(vi) = (ba_ko_dist(vi).num_lysosomes)./(ba_ko_dist(vi).axon_length)';
end
 
  %wt
  for vi=1:length(ba_wt_prox)
      if isempty(ba_wt_prox(vi).axon_length)
          wt_prox_numlys(vi) = NaN;
          wt_prox_tauInt(vi) = NaN;  
      else
    wt_prox_numlys(vi) = (ba_wt_prox(vi).num_lysosomes)./(ba_wt_prox(vi).axon_length)';
    wt_prox_tauInt(vi) = (ba_wt_prox(vi).tauInt)';   
      end
end
 
 for vi=1:length(ba_wt_mid)
     if isempty(ba_wt_mid(vi).axon_length)
        wt_mid_numlys(vi) = NaN;
        wt_mid_tauInt(vi) = NaN;
     else
    wt_mid_numlys(vi) = (ba_wt_mid(vi).num_lysosomes)./(ba_wt_mid(vi).axon_length)';
    wt_mid_tauInt(vi) = (ba_wt_mid(vi).tauInt)'; 
     end
end
 
 for vi=1:length(ba_wt_dist)
      if isempty(ba_wt_dist(vi).axon_length)
        wt_dist_numlys(vi) = NaN;
        wt_dist_tauInt(vi) = NaN;
     else
    wt_dist_numlys(vi) = (ba_wt_dist(vi).num_lysosomes)./(ba_wt_dist(vi).axon_length)';
    wt_dist_tauInt(vi) = (ba_wt_dist(vi).tauInt)';  
      end
end
 
 %ap
  for vi=1:length(ba_ap_prox)
      if isempty(ba_ap_prox(vi).axon_length)
          ap_prox_numlys(vi) = NaN;
          ap_prox_tauInt(vi) = NaN;
      else
    ap_prox_numlys(vi) = (ba_ap_prox(vi).num_lysosomes)./(ba_ap_prox(vi).axon_length)';
    ap_prox_tauInt(vi) = (ba_ap_prox(vi).tauInt)';   
      end
end
 
 for vi=1:length(ba_ap_mid)
     if isempty(ba_ap_mid(vi).axon_length)
         ap_mid_numlys(vi) = NaN;
         ap_mid_tauInt(vi) = NaN;
     else
    ap_mid_numlys(vi) = (ba_ap_mid(vi).num_lysosomes)./(ba_ap_mid(vi).axon_length)';
    ap_mid_tauInt(vi) = (ba_ap_mid(vi).tauInt)'; 
     end
end
 
 for vi=1:length(ba_ap_dist)
     if isempty(ba_ap_dist(vi).axon_length)
         ap_dist_numlys(vi) = NaN;
         ap_dist_tauInt(vi) = NaN;
     else
    ap_dist_numlys(vi) = (ba_ap_dist(vi).num_lysosomes)./(ba_ap_dist(vi).axon_length)';
    ap_dist_tauInt(vi) = (ba_ap_dist(vi).tauInt)';   
     end
end
 
 %e14
  for vi=1:length(ba_e14_prox)
      if isempty(ba_e14_prox(vi).axon_length)
          e14_prox_numlys(vi) = NaN;
          e14_prox_tauInt(vi) = NaN;
      else
    e14_prox_numlys(vi) = (ba_e14_prox(vi).num_lysosomes)./(ba_e14_prox(vi).axon_length)';
    e14_prox_tauInt(vi) = (ba_e14_prox(vi).tauInt)'; 
      end
end
 
 for vi=1:length(ba_e14_mid)
     if isempty(ba_e14_mid(vi).axon_length)
         e14_mid_numlys(vi) = NaN;
         e14_mid_tauInt(vi) = NaN;
     else
    e14_mid_numlys(vi) = (ba_e14_mid(vi).num_lysosomes)./(ba_e14_mid(vi).axon_length)';
    e14_mid_tauInt(vi) = (ba_e14_mid(vi).tauInt)'; 
     end
end

 for vi=1:length(ba_e14_dist)
     if isempty(ba_e14_dist(vi).axon_length)
         e14_dist_numlys(vi) = NaN;
         e14_dist_tauInt(vi) = NaN;
     else
    e14_dist_numlys(vi) = (ba_e14_dist(vi).num_lysosomes)./(ba_e14_dist(vi).axon_length)';
    e14_dist_tauInt(vi) = (ba_e14_dist(vi).tauInt)'; 
     end
 end
 
%% sumPos vs tau Int

%CTL
for bi=1:length(ba_ctl_prox)
ctl_prox_sumPos(bi) = ba_ctl_prox(bi).sumPos; 
end

for bi=1:length(ba_ctl_mid)
ctl_mid_sumPos(bi) = ba_ctl_mid(bi).sumPos; 
end

for bi=1:length(ba_ctl_dist)
ctl_dist_sumPos(bi) = ba_ctl_dist(bi).sumPos; 
end

%ko
for bi=1:length(ba_ko_prox)
ko_prox_sumPos(bi) = ba_ko_prox(bi).sumPos; 
end

for bi=1:length(ba_ko_mid)
ko_mid_sumPos(bi) = ba_ko_mid(bi).sumPos; 
end

for bi=1:length(ba_ko_dist)
ko_dist_sumPos(bi) = ba_ko_dist(bi).sumPos; 
end

tau_Thresh=1.09;

%wt
for bi=1:length(ba_wt_prox)
wt_prox_sumPos(bi) = ba_wt_prox(bi).sumPos;    
end

for bi=1:length(ba_wt_mid)
wt_mid_sumPos(bi) = ba_wt_mid(bi).sumPos; 
end

for bi=1:length(ba_wt_dist)
wt_dist_sumPos(bi) = ba_wt_dist(bi).sumPos; 
end

%ap
for bi=1:length(ba_ap_prox)
ap_prox_sumPos(bi) = ba_ap_prox(bi).sumPos; 
end

for bi=1:length(ba_ap_mid)
ap_mid_sumPos(bi) = ba_ap_mid(bi).sumPos; 
end

for bi=1:length(ba_ap_dist)
ap_dist_sumPos(bi) = ba_ap_dist(bi).sumPos; 
end

%e14
for bi=1:length(ba_e14_prox)
e14_prox_sumPos(bi) = ba_e14_prox(bi).sumPos; 
end

for bi=1:length(ba_e14_mid)
e14_mid_sumPos(bi) = ba_e14_mid(bi).sumPos; 
end

for bi=1:length(ba_e14_dist)
e14_dist_sumPos(bi) = ba_e14_dist(bi).sumPos; 
end


%Remove cells below threshold
 wt_prox_sumPos(wt_prox_tauInt < tau_Thresh)=[];
 wt_prox_numlys(wt_prox_tauInt < tau_Thresh)=[];
 wt_prox_tauInt(wt_prox_tauInt < tau_Thresh)=[];

 wt_mid_sumPos(wt_mid_tauInt < tau_Thresh)=[];
 wt_mid_numlys(wt_mid_tauInt < tau_Thresh)=[];
 wt_mid_tauInt(wt_mid_tauInt < tau_Thresh)=[];

 wt_dist_sumPos(wt_dist_tauInt < tau_Thresh)=[];
 wt_dist_numlys(wt_dist_tauInt < tau_Thresh)=[];
 wt_dist_tauInt(wt_dist_tauInt < tau_Thresh)=[];

 ap_prox_sumPos(ap_prox_tauInt < tau_Thresh)=[];
 ap_prox_numlys(ap_prox_tauInt < tau_Thresh)=[];
 ap_prox_tauInt(ap_prox_tauInt < tau_Thresh)=[];

 ap_mid_sumPos(ap_mid_tauInt < tau_Thresh)=[];
 ap_mid_numlys(ap_mid_tauInt < tau_Thresh)=[];
 ap_mid_tauInt(ap_mid_tauInt < tau_Thresh)=[];

 ap_dist_sumPos(ap_dist_tauInt < tau_Thresh)=[];
 ap_dist_numlys(ap_dist_tauInt < tau_Thresh)=[];
 ap_dist_tauInt(ap_dist_tauInt < tau_Thresh)=[];

 e14_prox_sumPos(e14_prox_tauInt < tau_Thresh)=[];
 e14_prox_numlys(e14_prox_tauInt < tau_Thresh)=[];
 e14_prox_tauInt(e14_prox_tauInt < tau_Thresh)=[];

 e14_mid_sumPos(e14_mid_tauInt < tau_Thresh)=[];
 e14_mid_numlys(e14_mid_tauInt < tau_Thresh)=[];
 e14_mid_tauInt(e14_mid_tauInt < tau_Thresh)=[];

 e14_dist_sumPos(e14_dist_tauInt < tau_Thresh)=[];
 e14_dist_numlys(e14_dist_tauInt < tau_Thresh)=[];
 e14_dist_tauInt(e14_dist_tauInt < tau_Thresh)=[];
 
 
 %%%%%%%% bin cell based on tau intensity%%%%%%%%%%%%
 
 % wt prox
 wt_prox_sumPos_low= wt_prox_sumPos(wt_prox_tauInt > tau_Thresh & wt_prox_tauInt< 2);
 wt_prox_numlys_low= wt_prox_numlys(wt_prox_tauInt > tau_Thresh & wt_prox_tauInt< 2);
 
 wt_prox_sumPos_med= wt_prox_sumPos(wt_prox_tauInt >= 2 & wt_prox_tauInt< 5);
 wt_prox_numlys_med= wt_prox_numlys(wt_prox_tauInt >= 2 & wt_prox_tauInt< 5);

 wt_prox_sumPos_hi= wt_prox_sumPos(wt_prox_tauInt >= 5 );
 wt_prox_numlys_hi= wt_prox_numlys(wt_prox_tauInt >= 5);
  
 % wt mid
 wt_mid_sumPos_low= wt_mid_sumPos(wt_mid_tauInt > tau_Thresh & wt_mid_tauInt< 2);
 wt_mid_numlys_low= wt_mid_numlys(wt_mid_tauInt > tau_Thresh & wt_mid_tauInt< 2);
 
 wt_mid_sumPos_med= wt_mid_sumPos(wt_mid_tauInt >= 2 & wt_mid_tauInt< 5);
 wt_mid_numlys_med= wt_mid_numlys(wt_mid_tauInt >= 2 & wt_mid_tauInt< 5);

 wt_mid_sumPos_hi= wt_mid_sumPos(wt_mid_tauInt >= 5 );
 wt_mid_numlys_hi= wt_mid_numlys(wt_mid_tauInt >= 5);

  % wt dist
 wt_dist_sumPos_low= wt_dist_sumPos(wt_dist_tauInt > tau_Thresh & wt_dist_tauInt< 2);
 wt_dist_numlys_low= wt_dist_numlys(wt_dist_tauInt > tau_Thresh & wt_dist_tauInt< 2);
 
 wt_dist_sumPos_med= wt_dist_sumPos(wt_dist_tauInt >= 2 & wt_dist_tauInt< 5);
 wt_dist_numlys_med= wt_dist_numlys(wt_dist_tauInt >= 2 & wt_dist_tauInt< 5);

 wt_dist_sumPos_hi= wt_dist_sumPos(wt_dist_tauInt >= 5 );
 wt_dist_numlys_hi= wt_dist_numlys(wt_dist_tauInt >= 5);


 % ap prox
 ap_prox_sumPos_low= wt_prox_sumPos(wt_prox_tauInt > tau_Thresh & wt_prox_tauInt< 2);
 ap_prox_numlys_low= wt_prox_numlys(wt_prox_tauInt > tau_Thresh & wt_prox_tauInt< 2);
 
 ap_prox_sumPos_med= wt_prox_sumPos(wt_prox_tauInt >= 2 & wt_prox_tauInt< 5);
 ap_prox_numlys_med= wt_prox_numlys(wt_prox_tauInt >= 2 & wt_prox_tauInt< 5);

 ap_prox_sumPos_hi= wt_prox_sumPos(wt_prox_tauInt >= 5 );
 ap_prox_numlys_hi= wt_prox_numlys(wt_prox_tauInt >= 5);

 % ap mid
 ap_mid_sumPos_low= ap_mid_sumPos(ap_mid_tauInt > tau_Thresh & ap_mid_tauInt< 2);
 ap_mid_numlys_low= ap_mid_numlys(ap_mid_tauInt > tau_Thresh & ap_mid_tauInt< 2);
 
 ap_mid_sumPos_med= ap_mid_sumPos(ap_mid_tauInt >= 2 & ap_mid_tauInt< 5);
 ap_mid_numlys_med= ap_mid_numlys(ap_mid_tauInt >= 2 & ap_mid_tauInt< 5);

 ap_mid_sumPos_hi= ap_mid_sumPos(ap_mid_tauInt >= 5 );
 ap_mid_numlys_hi= ap_mid_numlys(ap_mid_tauInt >= 5);

  % ap dist
 ap_dist_sumPos_low= ap_dist_sumPos(ap_dist_tauInt > tau_Thresh & ap_dist_tauInt< 2);
 ap_dist_numlys_low= ap_dist_numlys(ap_dist_tauInt > tau_Thresh & ap_dist_tauInt< 2);
 
 ap_dist_sumPos_med= ap_dist_sumPos(ap_dist_tauInt >= 2 & ap_dist_tauInt< 5);
 ap_dist_numlys_med= ap_dist_numlys(ap_dist_tauInt >= 2 & ap_dist_tauInt< 5);

 ap_dist_sumPos_hi= ap_dist_sumPos(ap_dist_tauInt >= 5 );
 ap_dist_numlys_hi= ap_dist_numlys(ap_dist_tauInt >= 5);


 % e14 prox
 e14_prox_sumPos_low= e14_prox_sumPos(e14_prox_tauInt > tau_Thresh & e14_prox_tauInt< 2);
 e14_prox_numlys_low= e14_prox_numlys(e14_prox_tauInt > tau_Thresh & e14_prox_tauInt< 2);
 
 e14_prox_sumPos_med= e14_prox_sumPos(e14_prox_tauInt >= 2 & e14_prox_tauInt< 5);
 e14_prox_numlys_med= e14_prox_numlys(e14_prox_tauInt >= 2 & e14_prox_tauInt< 5);

 e14_prox_sumPos_hi= e14_prox_sumPos(e14_prox_tauInt >= 5 );
 e14_prox_numlys_hi= e14_prox_numlys(e14_prox_tauInt >= 5);

 % e14 mid
 e14_mid_sumPos_low= e14_mid_sumPos(e14_mid_tauInt > tau_Thresh & e14_mid_tauInt< 2);
 e14_mid_numlys_low= e14_mid_numlys(e14_mid_tauInt > tau_Thresh & e14_mid_tauInt< 2);
 
 e14_mid_sumPos_med= e14_mid_sumPos(e14_mid_tauInt >= 2 & e14_mid_tauInt< 5);
 e14_mid_numlys_med= e14_mid_numlys(e14_mid_tauInt >= 2 & e14_mid_tauInt< 5);

 e14_mid_sumPos_hi= e14_mid_sumPos(e14_mid_tauInt >= 5 );
 e14_mid_numlys_hi= e14_mid_numlys(e14_mid_tauInt >= 5);

  % e14 dist
 e14_dist_sumPos_low= e14_dist_sumPos(e14_dist_tauInt > tau_Thresh & e14_dist_tauInt< 2);
 e14_dist_numlys_low= e14_dist_numlys(e14_dist_tauInt > tau_Thresh & e14_dist_tauInt< 2);
 
 e14_dist_sumPos_med= e14_dist_sumPos(e14_dist_tauInt >= 2 & e14_dist_tauInt< 5);
 e14_dist_numlys_med= e14_dist_numlys(e14_dist_tauInt >= 2 & e14_dist_tauInt< 5);

 e14_dist_sumPos_hi= e14_dist_sumPos(e14_dist_tauInt >= 5 );
 e14_dist_numlys_hi= e14_dist_numlys(e14_dist_tauInt >= 5);
 
 
 
 
   for qi=1:length(wt_prox_sumPos_low)
    table_prox_sumPos_bin(qi,1)= wt_prox_sumPos_low(qi); 
    table_prox_numlys_bin(qi,1)= wt_prox_numlys_low(qi);
   end
 
   for qi=1:length(wt_prox_sumPos_med)
    table_prox_sumPos_bin(qi,2)= wt_prox_sumPos_med(qi); 
    table_prox_numlys_bin(qi,2)= wt_prox_numlys_med(qi);
   end
   
   for qi=1:length(wt_prox_sumPos_hi)
    table_prox_sumPos_bin(qi,3)= wt_prox_sumPos_hi(qi); 
    table_prox_numlys_bin(qi,3)= wt_prox_numlys_hi(qi);
   end
   
   
    for qi=1:length(ap_prox_sumPos_low)
    table_prox_sumPos_bin(qi,5)= ap_prox_sumPos_low(qi); 
    table_prox_numlys_bin(qi,5)= ap_prox_numlys_low(qi);
   end
 
   for qi=1:length(ap_prox_sumPos_med)
    table_prox_sumPos_bin(qi,6)= ap_prox_sumPos_med(qi); 
    table_prox_numlys_bin(qi,6)= ap_prox_numlys_med(qi);
   end
   
   for qi=1:length(ap_prox_sumPos_hi)
    table_prox_sumPos_bin(qi,7)= ap_prox_sumPos_hi(qi); 
    table_prox_numlys_bin(qi,7)= ap_prox_numlys_hi(qi);
   end
 
   
   for qi=1:length(e14_prox_sumPos_low)
    table_prox_sumPos_bin(qi,9)= e14_prox_sumPos_low(qi); 
    table_prox_numlys_bin(qi,9)= e14_prox_numlys_low(qi);
   end
 
   for qi=1:length(e14_prox_sumPos_med)
    table_prox_sumPos_bin(qi,10)= e14_prox_sumPos_med(qi); 
    table_prox_numlys_bin(qi,10)= e14_prox_numlys_med(qi);
   end
   
   for qi=1:length(e14_prox_sumPos_hi)
    table_prox_sumPos_bin(qi,11)= e14_prox_sumPos_hi(qi); 
    table_prox_numlys_bin(qi,11)= e14_prox_numlys_hi(qi);
   end
   
   
   
   
   
   
   for qi=1:length(wt_mid_sumPos_low)
    table_mid_sumPos_bin(qi,1)= wt_mid_sumPos_low(qi); 
    table_mid_numlys_bin(qi,1)= wt_mid_numlys_low(qi);
   end
 
   for qi=1:length(wt_mid_sumPos_med)
    table_mid_sumPos_bin(qi,2)= wt_mid_sumPos_med(qi); 
    table_mid_numlys_bin(qi,2)= wt_mid_numlys_med(qi);
   end
   
   for qi=1:length(wt_mid_sumPos_hi)
    table_mid_sumPos_bin(qi,3)= wt_mid_sumPos_hi(qi); 
    table_mid_numlys_bin(qi,3)= wt_mid_numlys_hi(qi);
   end
   
   
    for qi=1:length(ap_mid_sumPos_low)
    table_mid_sumPos_bin(qi,5)= ap_mid_sumPos_low(qi); 
    table_mid_numlys_bin(qi,5)= ap_mid_numlys_low(qi);
   end
 
   for qi=1:length(ap_mid_sumPos_med)
    table_mid_sumPos_bin(qi,6)= ap_mid_sumPos_med(qi); 
    table_mid_numlys_bin(qi,6)= ap_mid_numlys_med(qi);
   end
   
   for qi=1:length(ap_mid_sumPos_hi)
    table_mid_sumPos_bin(qi,7)= ap_mid_sumPos_hi(qi); 
    table_mid_numlys_bin(qi,7)= ap_mid_numlys_hi(qi);
   end
 
   
   for qi=1:length(e14_mid_sumPos_low)
    table_mid_sumPos_bin(qi,9)= e14_mid_sumPos_low(qi); 
    table_mid_numlys_bin(qi,9)= e14_mid_numlys_low(qi);
   end
 
   for qi=1:length(e14_mid_sumPos_med)
    table_mid_sumPos_bin(qi,10)= e14_mid_sumPos_med(qi); 
    table_mid_numlys_bin(qi,10)= e14_mid_numlys_med(qi);
   end
   
   for qi=1:length(e14_mid_sumPos_hi)
    table_mid_sumPos_bin(qi,11)= e14_mid_sumPos_hi(qi); 
    table_mid_numlys_bin(qi,11)= e14_mid_numlys_hi(qi);
   end

   
   
   
   
   
      
   for qi=1:length(wt_dist_sumPos_low)
    table_dist_sumPos_bin(qi,1)= wt_dist_sumPos_low(qi); 
    table_dist_numlys_bin(qi,1)= wt_dist_numlys_low(qi);
   end
 
   for qi=1:length(wt_dist_sumPos_med)
    table_dist_sumPos_bin(qi,2)= wt_dist_sumPos_med(qi); 
    table_dist_numlys_bin(qi,2)= wt_dist_numlys_med(qi);
   end
   
   for qi=1:length(wt_dist_sumPos_hi)
    table_dist_sumPos_bin(qi,3)= wt_dist_sumPos_hi(qi); 
    table_dist_numlys_bin(qi,3)= wt_dist_numlys_hi(qi);
   end
   
   
    for qi=1:length(ap_dist_sumPos_low)
    table_dist_sumPos_bin(qi,5)= ap_dist_sumPos_low(qi); 
    table_dist_numlys_bin(qi,5)= ap_dist_numlys_low(qi);
   end
 
   for qi=1:length(ap_dist_sumPos_med)
    table_dist_sumPos_bin(qi,6)= ap_dist_sumPos_med(qi); 
    table_dist_numlys_bin(qi,6)= ap_dist_numlys_med(qi);
   end
   
   for qi=1:length(ap_dist_sumPos_hi)
    table_dist_sumPos_bin(qi,7)= ap_dist_sumPos_hi(qi); 
    table_dist_numlys_bin(qi,7)= ap_dist_numlys_hi(qi);
   end
 
   
   for qi=1:length(e14_dist_sumPos_low)
    table_dist_sumPos_bin(qi,9)= e14_dist_sumPos_low(qi); 
    table_dist_numlys_bin(qi,9)= e14_dist_numlys_low(qi);
   end
 
   for qi=1:length(e14_dist_sumPos_med)
    table_dist_sumPos_bin(qi,10)= e14_dist_sumPos_med(qi); 
    table_dist_numlys_bin(qi,10)= e14_dist_numlys_med(qi);
   end
   
   for qi=1:length(e14_dist_sumPos_hi)
    table_dist_sumPos_bin(qi,11)= e14_dist_sumPos_hi(qi); 
    table_dist_numlys_bin(qi,11)= e14_dist_numlys_hi(qi);
   end
   

% find variance of each SumPos to perform weighted linear regression

ctl_prox_sumPos_var= var(ctl_prox_sumPos);
ko_prox_sumPos_var=var(ko_prox_sumPos);
wt_prox_sumPos_var=var(wt_prox_sumPos);
ap_prox_sumPos_var=var(ap_prox_sumPos);
e14_prox_sumPos_var=var(e14_prox_sumPos);


% gets rid of nans
ind_WT = isnan(wt_prox_tauInt) | isnan(wt_prox_sumPos);
wt_prox_tauInt(ind_WT) = [];
wt_prox_sumPos(ind_WT) = [];

ind_AP = isnan(ap_prox_tauInt) | isnan(ap_prox_sumPos);
ap_prox_tauInt(ind_AP) = [];
ap_prox_sumPos(ind_AP) = [];

ind_E14 = isnan(e14_prox_tauInt) | isnan(e14_prox_sumPos);
e14_prox_tauInt(ind_E14) = [];
e14_prox_sumPos(ind_E14) = [];



%%%%%%%


%prox
for qi=1:length(ba_ctl_prox)
    table_lys_num_prox(qi,1)= ba_ctl_prox(qi).num_lysosomes./ba_ctl_prox(qi).axon_length; 
    table_sum_disp_prox(qi,1)= ba_ctl_prox(qi).sumPos;
end
for qi=1:length(ba_ko_prox)
    table_lys_num_prox(qi,2)= ba_ko_prox(qi).num_lysosomes./ba_ko_prox(qi).axon_length; 
    table_sum_disp_prox(qi,2)= ba_ko_prox(qi).sumPos;
end
for qi=1:length(ba_wt_prox)
    if isempty(ba_wt_prox(qi).axon_length)
     table_lys_num_prox(qi,3)=NaN;
     table_sum_disp_prox(qi,3)=NaN;
    else
    table_lys_num_prox(qi,3)= ba_wt_prox(qi).num_lysosomes./ba_wt_prox(qi).axon_length; 
    table_sum_disp_prox(qi,3)= ba_wt_prox(qi).sumPos;
    end
end
for qi=1:length(ba_ap_prox)
     if isempty(ba_ap_prox(qi).axon_length)
     table_lys_num_prox(qi,4)=NaN;
     table_sum_disp_prox(qi,4)=NaN;
    else
    table_lys_num_prox(qi,4)= ba_ap_prox(qi).num_lysosomes./ba_ap_prox(qi).axon_length; 
    table_sum_disp_prox(qi,4)= ba_ap_prox(qi).sumPos;
     end
end

for qi=1:length(ba_e14_prox)
     if isempty(ba_e14_prox(qi).axon_length)
     table_lys_num_prox(qi,5)=NaN;
     table_sum_disp_prox(qi,5)=NaN;
    else
    table_lys_num_prox(qi,5)= ba_e14_prox(qi).num_lysosomes./ba_e14_prox(qi).axon_length; 
    table_sum_disp_prox(qi,5)= ba_e14_prox(qi).sumPos;
     end
end

%mid
for qi=1:length(ba_ctl_mid)
    table_lys_num_mid(qi,1)= ba_ctl_mid(qi).num_lysosomes./ba_ctl_mid(qi).axon_length; 
    table_sum_disp_mid(qi,1)= ba_ctl_mid(qi).sumPos;
end
for qi=1:length(ba_ko_mid)
    table_lys_num_mid(qi,2)= ba_ko_mid(qi).num_lysosomes./ba_ko_mid(qi).axon_length; 
    table_sum_disp_mid(qi,2)= ba_ko_mid(qi).sumPos;
end
for qi=1:length(ba_wt_mid)
    if isempty(ba_wt_mid(qi).axon_length)
     table_lys_num_mid(qi,3)= NaN; 
     table_sum_disp_mid(qi,3)= NaN;
    else
    table_lys_num_mid(qi,3)= ba_wt_mid(qi).num_lysosomes./ba_wt_mid(qi).axon_length; 
    table_sum_disp_mid(qi,3)= ba_wt_mid(qi).sumPos;
    end
end
for qi=1:length(ba_ap_mid)
        if isempty(ba_ap_mid(qi).axon_length)
     table_lys_num_mid(qi,4)= NaN; 
     table_sum_disp_mid(qi,4)= NaN;
    else
    table_lys_num_mid(qi,4)= ba_ap_mid(qi).num_lysosomes./ba_ap_mid(qi).axon_length; 
    table_sum_disp_mid(qi,4)= ba_ap_mid(qi).sumPos;
        end
end

for qi=1:length(ba_e14_mid)
        if isempty(ba_e14_mid(qi).axon_length)
     table_lys_num_mid(qi,5)= NaN; 
     table_sum_disp_mid(qi,5)= NaN;
    else
    table_lys_num_mid(qi,5)= ba_e14_mid(qi).num_lysosomes./ba_e14_mid(qi).axon_length; 
    table_sum_disp_mid(qi,5)= ba_e14_mid(qi).sumPos;
        end
end

%dist
for qi=1:length(ba_ctl_dist)
    table_lys_num_dist(qi,1)= ba_ctl_dist(qi).num_lysosomes./ba_ctl_dist(qi).axon_length; 
    table_sum_disp_dist(qi,1)= ba_ctl_dist(qi).sumPos;
end

for qi=1:length(ba_ko_dist)
    table_lys_num_dist(qi,2)= ba_ko_dist(qi).num_lysosomes./ba_ko_dist(qi).axon_length; 
    table_sum_disp_dist(qi,2)= ba_ko_dist(qi).sumPos;
end

for qi=1:length(ba_wt_dist)
        if isempty(ba_wt_dist(qi).axon_length)
     table_lys_num_dist(qi,3)= NaN; 
     table_sum_disp_dist(qi,3)= NaN;
    else
    table_lys_num_dist(qi,3)= ba_wt_dist(qi).num_lysosomes./ba_wt_dist(qi).axon_length; 
    table_sum_disp_dist(qi,3)= ba_wt_dist(qi).sumPos;
        end
end

for qi=1:length(ba_ap_dist)
        if isempty(ba_ap_dist(qi).axon_length)
     table_lys_num_dist(qi,4)= NaN; 
     table_sum_disp_dist(qi,4)= NaN;
    else
    table_lys_num_dist(qi,4)= ba_ap_dist(qi).num_lysosomes./ba_ap_dist(qi).axon_length; 
    table_sum_disp_dist(qi,4)= ba_ap_dist(qi).sumPos;
        end
end

for qi=1:length(ba_e14_dist)
        if isempty(ba_e14_dist(qi).axon_length)
     table_lys_num_dist(qi,5)= NaN; 
     table_sum_disp_dist(qi,5)= NaN;
    else
    table_lys_num_dist(qi,5)= ba_e14_dist(qi).num_lysosomes./ba_e14_dist(qi).axon_length; 
    table_sum_disp_dist(qi,5)= ba_e14_dist(qi).sumPos;
        end
end

table_lys_num_prox(table_lys_num_prox==0)=nan;
table_sum_disp_prox(table_sum_disp_prox==0)=nan;

table_lys_num_mid(table_lys_num_mid==0)=nan;
table_sum_disp_mid(table_sum_disp_mid==0)=nan;

table_lys_num_dist(table_lys_num_dist==0)=nan;
table_sum_disp_dist(table_sum_disp_dist==0)=nan;

%%%% Plot box plots for the lysosome counts and sum displacements:
kcol= [0.5 0.5 0.5];


 
  
table_prox_numlys_bin(table_prox_numlys_bin==0)=nan;
table_prox_sumPos_bin(table_prox_sumPos_bin==0)=nan;

table_mid_numlys_bin(table_mid_numlys_bin==0)=nan;
table_mid_sumPos_bin(table_mid_sumPos_bin==0)=nan;

table_dist_numlys_bin(table_dist_numlys_bin==0)=nan;
table_dist_sumPos_bin(table_dist_sumPos_bin==0)=nan;


 
 [~,bsums_lysNum_prox_ctl]=bootci(nboot,{@nanmean, table_lys_num_prox(:,1)},'alpha',.05,'type','per');
 [~,bsums_lysNum_mid_ctl]=bootci(nboot,{@nanmean, table_lys_num_mid(:,1)},'alpha',.05,'type','per');
 [~,bsums_lysNum_dist_ctl]=bootci(nboot,{@nanmean, table_lys_num_dist(:,1)},'alpha',.05,'type','per');

 [~,bsums_lysNum_prox_ko]=bootci(nboot,{@nanmean, table_lys_num_prox(:,2)},'alpha',.05,'type','per');
 [~,bsums_lysNum_mid_ko]=bootci(nboot,{@nanmean, table_lys_num_mid(:,2)},'alpha',.05,'type','per');
 [~,bsums_lysNum_dist_ko]=bootci(nboot,{@nanmean, table_lys_num_dist(:,2)},'alpha',.05,'type','per');

 [~,bsums_lysNum_prox_wt]=bootci(nboot,{@nanmean, table_lys_num_prox(:,3)},'alpha',.05,'type','per');
 [~,bsums_lysNum_mid_wt]=bootci(nboot,{@nanmean, table_lys_num_mid(:,3)},'alpha',.05,'type','per');
 [~,bsums_lysNum_dist_wt]=bootci(nboot,{@nanmean, table_lys_num_dist(:,3)},'alpha',.05,'type','per');
 
 [~,bsums_lysNum_prox_ap]=bootci(nboot,{@nanmean, table_lys_num_prox(:,4)},'alpha',.05,'type','per');
 [~,bsums_lysNum_mid_ap]=bootci(nboot,{@nanmean, table_lys_num_mid(:,4)},'alpha',.05,'type','per');
 [~,bsums_lysNum_dist_ap]=bootci(nboot,{@nanmean, table_lys_num_dist(:,4)},'alpha',.05,'type','per');
 
 [~,bsums_lysNum_prox_e14]=bootci(nboot,{@nanmean, table_lys_num_prox(:,5)},'alpha',.05,'type','per');
 [~,bsums_lysNum_mid_e14]=bootci(nboot,{@nanmean, table_lys_num_mid(:,5)},'alpha',.05,'type','per');
 [~,bsums_lysNum_dist_e14]=bootci(nboot,{@nanmean, table_lys_num_dist(:,5)},'alpha',.05,'type','per');

 
 
 
 
  all_table_sumPos_bin= [table_sum_disp_prox;table_sum_disp_mid;table_sum_disp_dist];
  all_table_numlys_bin= [table_lys_num_prox;table_lys_num_mid;table_lys_num_dist];
  
  
  figure('Name',' notboxplot SumPos all_binned','NumberTitle','off'), hold on,
h1=notBoxPlot(all_table_sumPos_bin);%,'style','patch','jitter',0.5);
 box on;
  xlim([0 6]);ylim([0 9]);
    ylabel('Mean abs disp um^1 '); xlabel('all regions');

  
      figure('Name',' notboxplot numlys all_binned','NumberTitle','off'), hold on,
h1=notBoxPlot(all_table_numlys_bin);%,'style','patch','jitter',0.5);
 box on;
  xlim([0 6]);ylim([0 3]);
  ylabel('lysosomes um^1 min^-1'); xlabel('all regions');



[bci_sumPos_ctl_all,bsums_sumPos_ctl_all]=bootci(nboot,{@nanmean, all_table_sumPos_bin(:,1)},'alpha',.05,'type','per');
     
    
    [bci_sumPos_ko_all,bsums_sumPos_ko_all]=bootci(nboot,{@nanmean, all_table_sumPos_bin(:,2)},'alpha',.05,'type','per');
     
    


[bci_numlys_ctl_all,bsums_numlys_ctl_all]=bootci(nboot,{@nanmean, all_table_numlys_bin(:,1)},'alpha',.05,'type','per');
     
    
    [bci_numlys_ko_all,bsums_numlys_ko_all]=bootci(nboot,{@nanmean, all_table_numlys_bin(:,2)},'alpha',.05,'type','per');
     
  