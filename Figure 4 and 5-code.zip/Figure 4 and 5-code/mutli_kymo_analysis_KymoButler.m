%% Analysis of all tracks for multiple conditions for output data from KymoButler
clear all; close all; clc; 
set(0,'DefaultFigureWindowStyle','docked');

set(0,'DefaultFigureWindowStyle','docked');
addpath('/Users/danielbeaudet/Desktop/Neuron_codes/');
addpath('/Volumes/ROG/Neurons_KymoButler_data/');
tic

plot_traj= 0; % plot figures of trajectories 1 yes; 0 no%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nboot=1000;
%% Savitsky Golay smoothing parameters
span=10;    % 10 is good, 25 is good as well; old data3
pwr=1;      % 1 is good, 2 is good;old data 0

save_file = 0;
     
      
save_dir= '/Volumes/ROG/Neurons_KymoButler_data/';
saveName= 'kymoSumData';
% window_size=5;

min_lr=1.2;
tau_thresh=1.09;
chos= [1,2,3,4,5];%,4,5]; %CTL, MAPTKO, WT, AP, E14, WT3RS
x=1:1:100; y=0.0:0.01:0.99;
 %Th_Bins=[1.09, 1.2, 1.75, 5];
 Th_Bins=[1.09, 2, 5, 10];


procColor="#d95f02";
diffColor="#1b9e77";
statColor="#7570b3";

proxColor="#e0f3db";
midColor ="#a8ddb5";
distColor="#43a2ca";

mdGrey=[0.5 0.5 0.5];

dkBlue=[0 0.2470 0.4410];
lhtBlue=[0.3010 0.7450 0.9330];
Orng=[0.9290 0.6940 0.1250];
dkRed=[0.6350 0.0780 0.1840];

for k_choose = chos

if k_choose==1 % CTL  
    nam= 'CTL';
load('control_proximal_734.mat', 'ab');
for jh=1:numel(ab)
    ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
end
ab_prox= ab;
clear ab;

    load('control_mid_734.mat', 'ab');
    for jh=1:numel(ab)
    ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
    end
    ab_mid= ab;
    clear ab;
    
        load('control_distal_734.mat', 'ab');
        for jh=1:numel(ab)
        ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);

        end
        ab_dist= ab;
        clear ab;
        
  
load('control_proximal_986.mat', 'ab');
for jh=1:numel(ab)
    ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
end
ab_prox=horzcat(ab_prox,ab);
clear ab;

    load('control_mid_986.mat', 'ab');
    for jh=1:numel(ab)
    ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
    end
    ab_mid=horzcat(ab_mid,ab);
    clear ab;
    
        load('control_distal_986.mat', 'ab');
        for jh=1:numel(ab)
        ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
        end
        ab_dist=horzcat(ab_dist,ab);
        clear ab;
  
elseif k_choose==2 % MAPTKO tau 
    nam= 'MAPT-KO';
load('MAPTKO_734proximal_v2.mat', 'ab');
for jh=1:numel(ab)
    ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
    end
ab_prox=ab;
clear ab;

    load('MAPTKO_734mid_v2.mat', 'ab');
    for jh=1:numel(ab)
    ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
    end
    ab_mid=ab;
    clear ab;
    
        load('MAPTKO_734distal_v2.mat', 'ab');
        for jh=1:numel(ab)
        ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
        end
        ab_dist=ab;
        clear ab;
        
        load('MAPTKO_986proximal_v2.mat', 'ab');
for jh=1:numel(ab)
    ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
end
ab_prox=horzcat(ab_prox,ab);
clear ab;

    load('MAPTKO_986mid_v2.mat', 'ab');
    for jh=1:numel(ab)
    ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
    end
    ab_mid=horzcat(ab_mid,ab);
    clear ab;
    
        load('MAPTKO_986distal_v2.mat', 'ab');
        for jh=1:numel(ab)
        ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
        end
        ab_dist=horzcat(ab_dist,ab);
        clear ab;
        
        
        
elseif k_choose==3 % WT tau
    nam= 'MAPT-KO + WT tau';
load('MAPTKO_WTtau_proximal_v2.mat', 'ab');
for jh=1:numel(ab)
    ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
    end
ab_prox=ab;
clear ab;

    load('MAPTKO_WTtau_mid_v22.mat', 'ab');
    for jh=1:numel(ab)
    ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
    end
    ab_mid=ab;
    clear ab;
    
        load('MAPTKO_WTtau_distal_v2.mat', 'ab');
        for jh=1:numel(ab)
        ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
        end
        ab_dist=ab;
        clear ab;
        

elseif k_choose==4 % AP tau
    nam= 'MAPT-KO + AP tau';
load('MAPTKO_APtau_proximal_v2.mat', 'ab');
for jh=1:numel(ab)
    ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
    end
ab_prox=ab;
clear ab;

    load('MAPTKO_APtau_mid_v22.mat', 'ab');
    for jh=1:numel(ab)
    ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
    end
    ab_mid=ab;
    clear ab;
    
        load('MAPTKO_APtau_distal_v2.mat', 'ab');
        for jh=1:numel(ab)
        ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
        end
        ab_dist=ab;
        clear ab;
        
        
        elseif k_choose==5 % E14 tau
    nam= 'MAPT-KO + E14 tau';
load('MAPTKO_E14tau_proximal_v2.mat', 'ab');
for jh=1:numel(ab)
    ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
    end
ab_prox=ab;
clear ab;

    load('MAPTKO_E14tau_mid_v2.mat', 'ab');
    for jh=1:numel(ab)
    ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
    end
    ab_mid=ab;
    clear ab;
    
        load('MAPTKO_E14tau_distal_v2.mat', 'ab');
        for jh=1:numel(ab)
        ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
        end
        ab_dist=ab;
        clear ab;
        
        

end 


 if k_choose==1 || k_choose==2
 rev_rate_prox=[];
    proc_run_prox=[];
    proc_time_prox=[];
    diff_run_prox=[];
    diff_time_prox=[];
    stat_run_prox=[];
    stat_time_prox=[];
    np_trajPos_prox=[]; sumPosMat_prox=[];
    hist_xkrev_prox=[]; rev_rate_prox=[];
    
    
    for kd=1:length(ab_prox)
    ab_prox(kd).trkColorInt=[0 0.2470 0.4410];
    end
    
    for kd=1:length(ab_mid)
    ab_mid(kd).trkColorInt=[0 0.2470 0.4410];
    end
    
    for kd=1:length(ab_dist)
    ab_dist(kd).trkColorInt=[0 0.2470 0.4410];
    end
    
    VelInst=[];
    for i=1:length(ab_prox)
         posA{i}=ab_prox(i).pos;
         timA{i}=ab_prox(i).time;
         sumPosMat_prox(i)=(ab_prox(i).sumPos);
         
         
         pos= posA{i};
         time=timA{i};
        
                pos=smooth(pos,span,'sgolay',pwr);

         
         res=analyze_run_length_reversals_v2(time,pos,min_lr,0, k_choose);
         
             rev_rate_prox=[rev_rate_prox,res.reversal_rate];
             proc_run_prox=[proc_run_prox;res.proc_run];
             proc_time_prox=[proc_time_prox;res.proc_time];
             diff_run_prox=[diff_run_prox;res.diff_run];
             diff_time_prox=[diff_time_prox;res.diff_time];
             stat_run_prox= [stat_run_prox;res.stat_run];
             stat_time_prox=[stat_time_prox;res.stat_time];
               
    end
    
    rev_rate_mid=[];
    proc_run_mid=[];
    proc_time_mid=[];
    diff_run_mid=[];
    diff_time_mid=[];
    stat_run_mid=[];
    stat_time_mid=[];
    np_trajPos_mid=[]; sumPosMat_mid=[];
    hist_xkrev_mid=[]; rev_rate_mid=[];
    
    
    
    for i=1:length(ab_mid)
         posA{i}=ab_mid(i).pos;
         timA{i}=ab_mid(i).time;
          sumPosMat_mid(i)=(ab_mid(i).sumPos);
         
         pos= posA{i};
         time=timA{i};
         
                  pos=smooth(pos,span,'sgolay',pwr);

         res=analyze_run_length_reversals_v2(time,pos,min_lr,0, k_choose);
         
             rev_rate_mid=[rev_rate_mid,res.reversal_rate];
             proc_run_mid=[proc_run_mid;res.proc_run];
             proc_time_mid=[proc_time_mid;res.proc_time];
             diff_run_mid=[diff_run_mid;res.diff_run];
             diff_time_mid=[diff_time_mid;res.diff_time];
             stat_run_mid= [stat_run_mid;res.stat_run];
             stat_time_mid=[stat_time_mid;res.stat_time];
      
    end
    
    rev_rate_dist=[];
    proc_run_dist=[];
    proc_time_dist=[];
    diff_run_dist=[];
    diff_time_dist=[];
    stat_run_dist=[];
    stat_time_dist=[];
    np_trajPos_dist=[]; sumPosMat_dist=[];
    hist_xkrev_dist=[]; rev_rate_dist=[];

  
    
    for i=1:length(ab_dist)
         posA{i}=ab_dist(i).pos;
         timA{i}=ab_dist(i).time;
          sumPosMat_dist(i)=(ab_dist(i).sumPos);
         
         pos= posA{i};
         time=timA{i};
         
                   pos=smooth(pos,span,'sgolay',pwr);

         
         res=analyze_run_length_reversals_v2(time,pos,min_lr,0, k_choose);
         
             rev_rate_dist=[rev_rate_dist,res.reversal_rate];
             proc_run_dist=[proc_run_dist;res.proc_run];
             proc_time_dist=[proc_time_dist;res.proc_time];
             diff_run_dist=[diff_run_dist;res.diff_run];
             diff_time_dist=[diff_time_dist;res.diff_time];
             stat_run_dist= [stat_run_dist;res.stat_run];
             stat_time_dist=[stat_time_dist;res.stat_time];
    end
    
 
    
 else 
        
    rev_rate_prox1=[];
    proc_run_prox1=[];
    proc_time_prox1=[];
    diff_run_prox1=[];
    diff_time_prox1=[];
    stat_run_prox1=[];
    stat_time_prox1=[];
    np_trajPos_prox1=[]; sumPosMat_prox1=[];
    hist_xkrev_prox1=[]; 
    
    rev_rate_prox2=[];
    proc_run_prox2=[];
    proc_time_prox2=[];
    diff_run_prox2=[];
    diff_time_prox2=[];
    stat_run_prox2=[];
    stat_time_prox2=[];
    np_trajPos_prox2=[]; sumPosMat_prox2=[];
    hist_xkrev_prox2=[]; 
    

    rev_rate_prox3=[];
    proc_run_prox3=[];
    proc_time_prox3=[];
    diff_run_prox3=[];
    diff_time_prox3=[];
    stat_run_prox3=[];
    stat_time_prox3=[];
    np_trajPos_prox3=[]; sumPosMat_prox3=[];
    hist_xkrev_prox3=[]; 
    
    rev_rate_prox4=[];
    proc_run_prox4=[];
    proc_time_prox4=[];
    diff_run_prox4=[];
    diff_time_prox4=[];
    stat_run_prox4=[];
    stat_time_prox4=[];
    np_trajPos_prox4=[]; sumPosMat_prox4=[];
    hist_xkrev_prox4=[];
    
    
    
    % Re-color tracks
    
    for vi=1:length(ab_prox)
        if ab_prox(vi).tauInt<Th_Bins(1)  
            ab_prox(vi).trkColorInt='k';   
        elseif ab_prox(vi).tauInt>=Th_Bins(1) && ab_prox(vi).tauInt<Th_Bins(2) 
            ab_prox(vi).trkColorInt=lhtBlue;           
        elseif ab_prox(vi).tauInt>=Th_Bins(2) && ab_prox(vi).tauInt<Th_Bins(3) 
            ab_prox(vi).trkColorInt=Orng;        
        elseif ab_prox(vi).tauInt>=Th_Bins(3)  
            ab_prox(vi).trkColorInt=dkRed;    
        else
        end
    end
    
    for vi=1:length(ab_mid)
        if ab_mid(vi).tauInt<Th_Bins(1) 
            ab_mid(vi).trkColorInt='k';
        elseif ab_mid(vi).tauInt>=Th_Bins(1) && ab_mid(vi).tauInt<Th_Bins(2) 
            ab_mid(vi).trkColorInt=lhtBlue;
        elseif ab_mid(vi).tauInt>=Th_Bins(2) && ab_mid(vi).tauInt<Th_Bins(3) 
            ab_mid(vi).trkColorInt=Orng;
        elseif ab_mid(vi).tauInt>=Th_Bins(3)  
            ab_mid(vi).trkColorInt=dkRed;
        else
        end
    end
    
    for vi=1:length(ab_dist)
        if ab_dist(vi).tauInt<Th_Bins(1) 
            ab_dist(vi).trkColorInt='k';
        elseif ab_dist(vi).tauInt>=Th_Bins(1) && ab_dist(vi).tauInt<Th_Bins(2) 
            ab_dist(vi).trkColorInt=lhtBlue;       
        elseif ab_dist(vi).tauInt>=Th_Bins(2) && ab_dist(vi).tauInt<Th_Bins(3) 
            ab_dist(vi).trkColorInt=Orng;        
        elseif ab_dist(vi).tauInt>=Th_Bins(3)  
            ab_dist(vi).trkColorInt=dkRed;
        else
        end
    end
    
    
    
    
    for i=1:length(ab_prox)
        
        if ab_prox(i).tauInt >= Th_Bins(1) && ab_prox(i).tauInt < Th_Bins(2)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Tau intensity Threshold
         posA1{i}=ab_prox(i).pos;
         timA1{i}=ab_prox(i).time;
         sumPosMat_prox1(i)=(ab_prox(i).sumPos);
         pos1= posA1{i};
         time1=timA1{i};
         %% Savitsky Golay smoothing

 pos1=smooth(pos1,span,'sgolay',pwr);

         res1=analyze_run_length_reversals_v2(time1,pos1,min_lr,0, k_choose); 
             rev_rate_prox1=[rev_rate_prox1,res1.reversal_rate];
             proc_run_prox1=[proc_run_prox1;res1.proc_run];
             proc_time_prox1=[proc_time_prox1;res1.proc_time];
             diff_run_prox1=[diff_run_prox1;res1.diff_run];
             diff_time_prox1=[diff_time_prox1;res1.diff_time];
             stat_run_prox1= [stat_run_prox1;res1.stat_run];
             stat_time_prox1=[stat_time_prox1;res1.stat_time];
             
        elseif ab_prox(i).tauInt >= Th_Bins(2) && ab_prox(i).tauInt < Th_Bins(3)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Tau intensity Threshold
         posA2{i}=ab_prox(i).pos;
         timA2{i}=ab_prox(i).time;
         sumPosMat_prox2(i)=(ab_prox(i).sumPos);
         pos2= posA2{i};
         time2=timA2{i};
          pos2=smooth(pos2,span,'sgolay',pwr);

         res2=analyze_run_length_reversals_v2(time2,pos2,min_lr,0, k_choose); 
             rev_rate_prox2=[rev_rate_prox2,res2.reversal_rate];
             proc_run_prox2=[proc_run_prox2;res2.proc_run];
             proc_time_prox2=[proc_time_prox2;res2.proc_time];
             diff_run_prox2=[diff_run_prox2;res2.diff_run];
             diff_time_prox2=[diff_time_prox2;res2.diff_time];
             stat_run_prox2= [stat_run_prox2;res2.stat_run];
             stat_time_prox2=[stat_time_prox2;res2.stat_time];               
        
        elseif ab_prox(i).tauInt >= Th_Bins(3) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Tau intensity Threshold
         posA3{i}=ab_prox(i).pos;
         timA3{i}=ab_prox(i).time;
         sumPosMat_prox3(i)=(ab_prox(i).sumPos); 
         pos3= posA3{i};
         time3=timA3{i};
          pos3=smooth(pos3,span,'sgolay',pwr);

         res3=analyze_run_length_reversals_v2(time3,pos3,min_lr,0, k_choose); 
             rev_rate_prox3=[rev_rate_prox3,res3.reversal_rate];
             proc_run_prox3=[proc_run_prox3;res3.proc_run];
             proc_time_prox3=[proc_time_prox3;res3.proc_time];
             diff_run_prox3=[diff_run_prox3;res3.diff_run];
             diff_time_prox3=[diff_time_prox3;res3.diff_time];
             stat_run_prox3= [stat_run_prox3;res3.stat_run];
             stat_time_prox3=[stat_time_prox3;res3.stat_time];               
                    
        elseif ab_prox(i).tauInt <0% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Tau intensity Threshold
         posA4{i}=ab_prox(i).pos;
         timA4{i}=ab_prox(i).time;
         sumPosMat_prox4(i)=(ab_prox(i).sumPos); 
         pos4= posA4{i};
         time4=timA4{i};
                   pos4=smooth(pos4,span,'sgolay',pwr);

         res4=analyze_run_length_reversals_v2(time4,pos4,min_lr,0, k_choose); 
             rev_rate_prox4=[rev_rate_prox4,res4.reversal_rate];
             proc_run_prox4=[proc_run_prox4;res4.proc_run];
             proc_time_prox4=[proc_time_prox4;res4.proc_time];
             diff_run_prox4=[diff_run_prox4;res4.diff_run];
             diff_time_prox4=[diff_time_prox4;res4.diff_time];
             stat_run_prox4= [stat_run_prox4;res4.stat_run];
             stat_time_prox4=[stat_time_prox4;res4.stat_time];         
  
        end
    end
    

   
    rev_rate_mid1=[];
    proc_run_mid1=[];
    proc_time_mid1=[];
    diff_run_mid1=[];
    diff_time_mid1=[];
    stat_run_mid1=[];
    stat_time_mid1=[];
    np_trajPos_mid1=[]; sumPosMat_mid1=[];
    hist_xkrev_mid1=[]; 
    
     rev_rate_mid2=[];
    proc_run_mid2=[];
    proc_time_mid2=[];
    diff_run_mid2=[];
    diff_time_mid2=[];
    stat_run_mid2=[];
    stat_time_mid2=[];
    np_trajPos_mid2=[]; sumPosMat_mid2=[];
    hist_xkrev_mid2=[]; 
    
     rev_rate_mid3=[];
    proc_run_mid3=[];
    proc_time_mid3=[];
    diff_run_mid3=[];
    diff_time_mid3=[];
    stat_run_mid3=[];
    stat_time_mid3=[];
    np_trajPos_mid3=[]; sumPosMat_mid3=[];
    hist_xkrev_mid3=[];
    
     rev_rate_mid4=[];
    proc_run_mid4=[];
    proc_time_mid4=[];
    diff_run_mid4=[];
    diff_time_mid4=[];
    stat_run_mid4=[];
    stat_time_mid4=[];
    np_trajPos_mid4=[]; sumPosMat_mid4=[];
    hist_xkrev_mid4=[];
    
    for i=1:length(ab_mid)
      if ab_mid(i).tauInt >= Th_Bins(1) && ab_mid(i).tauInt < Th_Bins(2)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Tau intensity Threshold
         posA1{i}=ab_mid(i).pos;
         timA1{i}=ab_mid(i).time;
         sumPosMat_mid1(i)=(ab_mid(i).sumPos);
         pos1= posA1{i};
         time1=timA1{i};
                   pos1=smooth(pos1,span,'sgolay',pwr);

         res1=analyze_run_length_reversals_v2(time1,pos1,min_lr,0, k_choose); 
             rev_rate_mid1=[rev_rate_mid1,res1.reversal_rate];
             proc_run_mid1=[proc_run_mid1;res1.proc_run];
             proc_time_mid1=[proc_time_mid1;res1.proc_time];
             diff_run_mid1=[diff_run_mid1;res1.diff_run];
             diff_time_mid1=[diff_time_mid1;res1.diff_time];
             stat_run_mid1= [stat_run_mid1;res1.stat_run];
             stat_time_mid1=[stat_time_mid1;res1.stat_time];
             
        elseif ab_mid(i).tauInt >= Th_Bins(2) && ab_mid(i).tauInt < Th_Bins(3)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Tau intensity Threshold
         posA2{i}=ab_mid(i).pos;
         timA2{i}=ab_mid(i).time;
         sumPosMat_mid2(i)=(ab_mid(i).sumPos);
         pos2= posA2{i};
         time2=timA2{i};
         
                   pos2=smooth(pos2,span,'sgolay',pwr);

         res2=analyze_run_length_reversals_v2(time2,pos2,min_lr,0, k_choose); 
             rev_rate_mid2=[rev_rate_mid2,res2.reversal_rate];
             proc_run_mid2=[proc_run_mid2;res2.proc_run];
             proc_time_mid2=[proc_time_mid2;res2.proc_time];
             diff_run_mid2=[diff_run_mid2;res2.diff_run];
             diff_time_mid2=[diff_time_mid2;res2.diff_time];
             stat_run_mid2= [stat_run_mid2;res2.stat_run];
             stat_time_mid2=[stat_time_mid2;res2.stat_time];               
        
        elseif ab_mid(i).tauInt >= Th_Bins(3) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Tau intensity Threshold
         posA3{i}=ab_mid(i).pos;
         timA3{i}=ab_mid(i).time;
         sumPosMat_mid3(i)=(ab_mid(i).sumPos); 
         pos3= posA3{i};
         time3=timA3{i};
         
                   pos3=smooth(pos3,span,'sgolay',pwr);

         
         res3=analyze_run_length_reversals_v2(time3,pos3,min_lr,0, k_choose); 
             rev_rate_mid3=[rev_rate_mid3,res3.reversal_rate];
             proc_run_mid3=[proc_run_mid3;res3.proc_run];
             proc_time_mid3=[proc_time_mid3;res3.proc_time];
             diff_run_mid3=[diff_run_mid3;res3.diff_run];
             diff_time_mid3=[diff_time_mid3;res3.diff_time];
             stat_run_mid3= [stat_run_mid3;res3.stat_run];
             stat_time_mid3=[stat_time_mid3;res3.stat_time];               
                    
        elseif ab_mid(i).tauInt <0%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Tau intensity Threshold
         posA4{i}=ab_mid(i).pos;
         timA4{i}=ab_mid(i).time;
         sumPosMat_mid4(i)=(ab_mid(i).sumPos); 
         pos4= posA4{i};
         time4=timA4{i};
         
                   pos4=smooth(pos4,span,'sgolay',pwr);

         res4=analyze_run_length_reversals_v2(time4,pos4,min_lr,0, k_choose); 
             rev_rate_mid4=[rev_rate_mid4,res4.reversal_rate];
             proc_run_mid4=[proc_run_mid4;res4.proc_run];
             proc_time_mid4=[proc_time_mid4;res4.proc_time];
             diff_run_mid4=[diff_run_mid4;res4.diff_run];
             diff_time_mid4=[diff_time_mid4;res4.diff_time];
             stat_run_mid4= [stat_run_mid4;res4.stat_run];
             stat_time_mid4=[stat_time_mid4;res4.stat_time];
      end
      
    end
    rev_rate_dist1=[];
    proc_run_dist1=[];
    proc_time_dist1=[];
    diff_run_dist1=[];
    diff_time_dist1=[];
    stat_run_dist1=[];
    stat_time_dist1=[];
    np_trajPos_dist1=[]; sumPosMat_dist1=[];
    hist_xkrev_dist1=[]; 

    rev_rate_dist2=[];
    proc_run_dist2=[];
    proc_time_dist2=[];
    diff_run_dist2=[];
    diff_time_dist2=[];
    stat_run_dist2=[];
    stat_time_dist2=[];
    np_trajPos_dist2=[]; sumPosMat_dist2=[];
    hist_xkrev_dist2=[]; 

    rev_rate_dist3=[];
    proc_run_dist3=[];
    proc_time_dist3=[];
    diff_run_dist3=[];
    diff_time_dist3=[];
    stat_run_dist3=[];
    stat_time_dist3=[];
    np_trajPos_dist3=[]; sumPosMat_dist3=[];
    hist_xkrev_dist3=[]; 

    rev_rate_dist4=[];
    proc_run_dist4=[];
    proc_time_dist4=[];
    diff_run_dist4=[];
    diff_time_dist4=[];
    stat_run_dist4=[];
    stat_time_dist4=[];
    np_trajPos_dist4=[]; sumPosMat_dist4=[];
    hist_xkrev_dist4=[]; 

    
    for i=1:length(ab_dist)
     if ab_dist(i).tauInt >= Th_Bins(1) && ab_dist(i).tauInt < Th_Bins(2)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Tau intensity Threshold
         posA1{i}=ab_dist(i).pos;
         timA1{i}=ab_dist(i).time;
         sumPosMat_dist1(i)=(ab_dist(i).sumPos);
         pos1= posA1{i};
         time1=timA1{i};
         
                   pos1=smooth(pos1,span,'sgolay',pwr);

         res1=analyze_run_length_reversals_v2(time1,pos1,min_lr,0, k_choose); 
             rev_rate_dist1=[rev_rate_dist1,res1.reversal_rate];
             proc_run_dist1=[proc_run_dist1;res1.proc_run];
             proc_time_dist1=[proc_time_dist1;res1.proc_time];
             diff_run_dist1=[diff_run_dist1;res1.diff_run];
             diff_time_dist1=[diff_time_dist1;res1.diff_time];
             stat_run_dist1= [stat_run_dist1;res1.stat_run];
             stat_time_dist1=[stat_time_dist1;res1.stat_time];
             
        elseif ab_dist(i).tauInt >= Th_Bins(2) && ab_dist(i).tauInt < Th_Bins(3)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Tau intensity Threshold
         posA2{i}=ab_dist(i).pos;
         timA2{i}=ab_dist(i).time;
         sumPosMat_dist2(i)=(ab_dist(i).sumPos);
         pos2= posA2{i};
         time2=timA2{i};
         
                   pos2=smooth(pos2,span,'sgolay',pwr);

         res2=analyze_run_length_reversals_v2(time2,pos2,min_lr,0, k_choose); 
             rev_rate_dist2=[rev_rate_dist2,res2.reversal_rate];
             proc_run_dist2=[proc_run_dist2;res2.proc_run];
             proc_time_dist2=[proc_time_dist2;res2.proc_time];
             diff_run_dist2=[diff_run_dist2;res2.diff_run];
             diff_time_dist2=[diff_time_dist2;res2.diff_time];
             stat_run_dist2= [stat_run_dist2;res2.stat_run];
             stat_time_dist2=[stat_time_dist2;res2.stat_time];               
        
        elseif ab_dist(i).tauInt >= Th_Bins(3)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Tau intensity Threshold
         posA3{i}=ab_dist(i).pos;
         timA3{i}=ab_dist(i).time;
         sumPosMat_dist3(i)=(ab_dist(i).sumPos); 
         pos3= posA3{i};
         time3=timA3{i};
         
                   pos3=smooth(pos3,span,'sgolay',pwr);

         res3=analyze_run_length_reversals_v2(time3,pos3,min_lr,0, k_choose); 
             rev_rate_dist3=[rev_rate_dist3,res3.reversal_rate];
             proc_run_dist3=[proc_run_dist3;res3.proc_run];
             proc_time_dist3=[proc_time_dist3;res3.proc_time];
             diff_run_dist3=[diff_run_dist3;res3.diff_run];
             diff_time_dist3=[diff_time_dist3;res3.diff_time];
             stat_run_dist3= [stat_run_dist3;res3.stat_run];
             stat_time_dist3=[stat_time_dist3;res3.stat_time];               
                    
        elseif ab_dist(i).tauInt <0% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Tau intensity Threshold
         posA4{i}=ab_dist(i).pos;
         timA4{i}=ab_dist(i).time;
         sumPosMat_dist4(i)=(ab_dist(i).sumPos); 
         pos4= posA4{i};
         time4=timA4{i};
         
                   pos4=smooth(pos4,span,'sgolay',pwr);

         res4=analyze_run_length_reversals_v2(time4,pos4,min_lr,0, k_choose); 
             rev_rate_dist4=[rev_rate_dist4,res4.reversal_rate];
             proc_run_dist4=[proc_run_dist4;res4.proc_run];
             proc_time_dist4=[proc_time_dist4;res4.proc_time];
             diff_run_dist4=[diff_run_dist4;res4.diff_run];
             diff_time_dist4=[diff_time_dist4;res4.diff_time];
             stat_run_dist4= [stat_run_dist4;res4.stat_run];
             stat_time_dist4=[stat_time_dist4;res4.stat_time];
    end
    end
    end

        if k_choose==1 || k_choose==2
            
             rev_rate_prox=[rev_rate_prox];
             proc_run_prox=[proc_run_prox];
             proc_time_prox=[proc_time_prox];
             diff_run_prox=[diff_run_prox];
             diff_time_prox=[diff_time_prox];
             stat_run_prox= [stat_run_prox];
             stat_time_prox=[stat_time_prox];
             
             rev_rate_mid=[rev_rate_mid];
             proc_run_mid=[proc_run_mid];
             proc_time_mid=[proc_time_mid];
             diff_run_mid=[diff_run_mid];
             diff_time_mid=[diff_time_mid];
             stat_run_mid= [stat_run_mid];
             stat_time_mid=[stat_time_mid];
    
             rev_rate_dist=[rev_rate_dist];
             proc_run_dist=[proc_run_dist];
             proc_time_dist=[proc_time_dist];
             diff_run_dist=[diff_run_dist];
             diff_time_dist=[diff_time_dist];
             stat_run_dist= [stat_run_dist];
             stat_time_dist=[stat_time_dist];
        else
             rev_rate_prox=[];
             proc_run_prox=[];
             proc_time_prox=[];
             diff_run_prox=[];
             diff_time_prox=[];
             stat_run_prox= [];
             stat_time_prox=[];
             
             rev_rate_mid=[];
             proc_run_mid=[];
             proc_time_mid=[];
             diff_run_mid=[];
             diff_time_mid=[];
             stat_run_mid= [];
             stat_time_mid=[];
    
             rev_rate_dist=[];
             proc_run_dist=[];
             proc_time_dist=[];
             diff_run_dist=[];
             diff_time_dist=[];
             stat_run_dist= [];
             stat_time_dist=[];
             
             sumPosMat_prox=[sumPosMat_prox1,sumPosMat_prox2,sumPosMat_prox3,sumPosMat_prox4];
             sumPosMat_mid= [sumPosMat_mid1, sumPosMat_mid2, sumPosMat_mid3, sumPosMat_mid4];
             sumPosMat_dist=[sumPosMat_dist1,sumPosMat_dist2,sumPosMat_dist3,sumPosMat_dist4];


             rev_rate_prox= [rev_rate_prox1,rev_rate_prox2,rev_rate_prox3,rev_rate_prox4];
             proc_run_prox= [proc_run_prox1;proc_run_prox2;proc_run_prox3;proc_run_prox4];
             proc_time_prox=[proc_time_prox1;proc_time_prox2;proc_time_prox3;proc_time_prox4];
             diff_run_prox= [diff_run_prox1;diff_run_prox2;diff_run_prox3;diff_run_prox4];
             diff_time_prox=[diff_time_prox1;diff_time_prox2;diff_time_prox3;diff_time_prox4];
             stat_run_prox= [stat_run_prox1;stat_run_prox2;stat_run_prox3;stat_run_prox4];
             stat_time_prox=[stat_time_prox1;stat_time_prox2;stat_time_prox3;stat_time_prox4];
             
             rev_rate_mid= [rev_rate_mid1,rev_rate_mid2,rev_rate_mid3,rev_rate_mid4];
             proc_run_mid= [proc_run_mid1;proc_run_mid2;proc_run_mid3;proc_run_mid4];
             proc_time_mid=[proc_time_mid1;proc_time_mid2;proc_time_mid3;proc_time_mid4];
             diff_run_mid= [diff_run_mid1;diff_run_mid2;diff_run_mid3;diff_run_mid4];
             diff_time_mid=[diff_time_mid1;diff_time_mid2;diff_time_mid3;diff_time_mid4];
             stat_run_mid= [stat_run_mid1;stat_run_mid2;stat_run_mid3;stat_run_mid4];
             stat_time_mid=[stat_time_mid1;stat_time_mid2;stat_time_mid3;stat_time_mid4];
    
             rev_rate_dist= [rev_rate_dist1,rev_rate_dist2,rev_rate_dist3,rev_rate_dist4];
             proc_run_dist= [proc_run_dist1;proc_run_dist2;proc_run_dist3;proc_run_dist4];
             proc_time_dist=[proc_time_dist1;proc_time_dist2;proc_time_dist3;proc_time_dist4];
             diff_run_dist= [diff_run_dist1;diff_run_dist2;diff_run_dist3;diff_run_dist4];
             diff_time_dist=[diff_time_dist1;diff_time_dist2;diff_time_dist3;diff_time_dist4];
             stat_run_dist= [stat_run_dist1;stat_run_dist2;stat_run_dist3;stat_run_dist4];
             stat_time_dist=[stat_time_dist1;stat_time_dist2;stat_time_dist3;stat_time_dist4];
        end
        

     

if k_choose==1
ab_all = [ab_prox(:); ab_mid(:); ab_dist(:)];


elseif k_choose==2
ab_all = [ab_prox(:); ab_mid(:); ab_dist(:)];

elseif k_choose==3
ab_alla = [ab_prox(:); ab_mid(:); ab_dist(:)];
[~, idx_a] = sort([ab_alla.tauInt]);

ab_all = ab_alla(idx_a);

elseif k_choose==4
ab_alla = [ab_prox(:); ab_mid(:); ab_dist(:)];
[~, idx_a] = sort([ab_alla.tauInt]);

ab_all = ab_alla(idx_a);

elseif k_choose==5
ab_alla = [ab_prox(:); ab_mid(:); ab_dist(:)];
[~, idx_a] = sort([ab_alla.tauInt]);

ab_all = ab_alla(idx_a);

end
clear ab_alla
  if plot_traj==1  
      
      if k_choose==1 || k_choose==2
% plot trajectories
minPlot=-40; maxPlot=40;
figure('Name',strcat(nam, ' Trajectories'),'NumberTitle','off')
for kd = 1:length(ab_all)
        fp=plot(ab_all(kd).timedisp , ab_all(kd).disp, '-','Color',ab_all(kd).trkColorInt,'linewidth',2);
        hold on,

end
 xlabel('All position (\mum)'); ylabel('Time (s)'); ylim([minPlot maxPlot]); xlim([0 120]);
  
  
  
  else
% plot trajectories
minPlot=-40; maxPlot=40;
figure('Name',strcat(nam, ' Trajectories'),'NumberTitle','off')
for kd = 1:length(ab_all)
    if ab_all(kd).tauInt>=tau_thresh
        fp=plot(ab_all(kd).timedisp , ab_all(kd).disp, '-','Color',ab_all(kd).trkColorInt,'linewidth',2);
        hold on,
    else
    end
end

 xlabel('Distal position (\mum)'); ylabel('Time (s)'); ylim([minPlot maxPlot]); xlim([0 120]);
  
  
  end
  
end
clear ab_all


%% Plot travel distance frequency


grThan=10;% use 15 for plotting example trajectories to add to a figure;


plus_pos_xp=0:1:40;
minus_pos_xp=-40:1:0;

if k_choose==1 %CTL
plus_pos_prox_c=sumPosMat_prox(find(sumPosMat_prox>0));
minus_pos_prox_c=sumPosMat_prox(find(sumPosMat_prox<0));

plus_pos_mid_c=sumPosMat_mid(find(sumPosMat_mid>0));
minus_pos_mid_c=sumPosMat_mid(find(sumPosMat_mid<0));

plus_pos_dist_c=sumPosMat_dist(find(sumPosMat_dist>0));
minus_pos_dist_c=sumPosMat_dist(find(sumPosMat_dist<0));


plus_pos_prox_c_gr=sumPosMat_prox(find(sumPosMat_prox>grThan));
minus_pos_prox_c_gr=sumPosMat_prox(find(sumPosMat_prox<-(grThan)));

plus_pos_mid_c_gr=sumPosMat_mid(find(sumPosMat_mid>grThan));
minus_pos_mid_c_gr=sumPosMat_mid(find(sumPosMat_mid<-(grThan)));

plus_pos_dist_c_gr=sumPosMat_dist(find(sumPosMat_dist>grThan));
minus_pos_dist_c_gr=sumPosMat_dist(find(sumPosMat_dist<-(grThan)));





%%%%%%%%%% CREATE histograms for the steps distributions%%%%%%%%%%%%%






hist_plus_prox_c=hist(plus_pos_prox_c,plus_pos_xp);
 hist_plus_mid_c=hist(plus_pos_mid_c,plus_pos_xp);
  hist_plus_dist_c=hist(plus_pos_dist_c,plus_pos_xp);
hist_minus_prox_c=hist(minus_pos_prox_c,minus_pos_xp);
 hist_minus_mid_c=hist(minus_pos_mid_c,minus_pos_xp);
  hist_minus_dist_c=hist(minus_pos_dist_c,minus_pos_xp);
 
  
  % travel histograms for all regions combined plus
    hist_plus_all_c=hist([plus_pos_prox_c,plus_pos_mid_c,plus_pos_dist_c],plus_pos_xp);
 
    
  % travel histograms for all regions combined minus
    hist_minus_all_c=hist([minus_pos_prox_c,minus_pos_mid_c,minus_pos_dist_c],minus_pos_xp);
 
elseif k_choose==2 %KO
plus_pos_prox_ko=sumPosMat_prox(find(sumPosMat_prox>0));
minus_pos_prox_ko=sumPosMat_prox(find(sumPosMat_prox<0));

plus_pos_mid_ko=sumPosMat_mid(find(sumPosMat_mid>0));
minus_pos_mid_ko=sumPosMat_mid(find(sumPosMat_mid<0));

plus_pos_dist_ko=sumPosMat_dist(find(sumPosMat_dist>0));
minus_pos_dist_ko=sumPosMat_dist(find(sumPosMat_dist<0));


plus_pos_prox_ko_gr=sumPosMat_prox(find(sumPosMat_prox>(grThan)));
minus_pos_prox_ko_gr=sumPosMat_prox(find(sumPosMat_prox<-(grThan)));

plus_pos_mid_ko_gr=sumPosMat_mid(find(sumPosMat_mid>(grThan)));
minus_pos_mid_ko_gr=sumPosMat_mid(find(sumPosMat_mid<-(grThan)));

plus_pos_dist_ko_gr=sumPosMat_dist(find(sumPosMat_dist>(grThan)));
minus_pos_dist_ko_gr=sumPosMat_dist(find(sumPosMat_dist<-(grThan)));


hist_plus_prox_ko=hist(plus_pos_prox_ko,plus_pos_xp);
 hist_plus_mid_ko=hist(plus_pos_mid_ko,plus_pos_xp);
  hist_plus_dist_ko=hist(plus_pos_dist_ko,plus_pos_xp);
hist_minus_prox_ko=hist(minus_pos_prox_ko,minus_pos_xp);
 hist_minus_mid_ko=hist(minus_pos_mid_ko,minus_pos_xp);
  hist_minus_dist_ko=hist(minus_pos_dist_ko,minus_pos_xp);
 
  % travel histograms for all regions combined plus
    hist_plus_all_ko=hist([plus_pos_prox_ko,plus_pos_mid_ko,plus_pos_dist_ko],plus_pos_xp);
 
    
  % travel histograms for all regions combined minus
    hist_minus_all_ko=hist([minus_pos_prox_ko,minus_pos_mid_ko,minus_pos_dist_ko],minus_pos_xp);
 
    
elseif k_choose==3 %WT
plus_pos_prox_wt=sumPosMat_prox(find(sumPosMat_prox>0));
minus_pos_prox_wt=sumPosMat_prox(find(sumPosMat_prox<0));

plus_pos_mid_wt=sumPosMat_mid(find(sumPosMat_mid>0));
minus_pos_mid_wt=sumPosMat_mid(find(sumPosMat_mid<0));

plus_pos_dist_wt=sumPosMat_dist(find(sumPosMat_dist>0));
minus_pos_dist_wt=sumPosMat_dist(find(sumPosMat_dist<0));

plus_pos_prox_wt1=sumPosMat_prox1(find(sumPosMat_prox1>0));
minus_pos_prox_wt1=sumPosMat_prox1(find(sumPosMat_prox1<0));

plus_pos_mid_wt1=sumPosMat_mid1(find(sumPosMat_mid1>0));
minus_pos_mid_wt1=sumPosMat_mid1(find(sumPosMat_mid1<0));

plus_pos_dist_wt1=sumPosMat_dist1(find(sumPosMat_dist1>0));
minus_pos_dist_wt1=sumPosMat_dist1(find(sumPosMat_dist1<0));

plus_pos_prox_wt2=sumPosMat_prox2(find(sumPosMat_prox2>0));
minus_pos_prox_wt2=sumPosMat_prox2(find(sumPosMat_prox2<0));

plus_pos_mid_wt2=sumPosMat_mid2(find(sumPosMat_mid2>0));
minus_pos_mid_wt2=sumPosMat_mid2(find(sumPosMat_mid2<0));

plus_pos_dist_wt2=sumPosMat_dist2(find(sumPosMat_dist2>0));
minus_pos_dist_wt2=sumPosMat_dist2(find(sumPosMat_dist2<0));

plus_pos_prox_wt3=sumPosMat_prox3(find(sumPosMat_prox3>0));
minus_pos_prox_wt3=sumPosMat_prox3(find(sumPosMat_prox3<0));

plus_pos_mid_wt3=sumPosMat_mid3(find(sumPosMat_mid3>0));
minus_pos_mid_wt3=sumPosMat_mid3(find(sumPosMat_mid3<0));

plus_pos_dist_wt3=sumPosMat_dist3(find(sumPosMat_dist3>0));
minus_pos_dist_wt3=sumPosMat_dist3(find(sumPosMat_dist3<0));



plus_pos_prox_wt_gr=sumPosMat_prox(find(sumPosMat_prox>grThan));
minus_pos_prox_wt_gr=sumPosMat_prox(find(sumPosMat_prox<-(grThan)));

plus_pos_mid_wt_gr=sumPosMat_mid(find(sumPosMat_mid>grThan));
minus_pos_mid_wt_gr=sumPosMat_mid(find(sumPosMat_mid<-(grThan)));

plus_pos_dist_wt_gr=sumPosMat_dist(find(sumPosMat_dist>grThan));
minus_pos_dist_wt_gr=sumPosMat_dist(find(sumPosMat_dist<-(grThan)));

plus_pos_prox_wt1_gr=sumPosMat_prox1(find(sumPosMat_prox1>grThan));
minus_pos_prox_wt1_gr=sumPosMat_prox1(find(sumPosMat_prox1<-(grThan)));

plus_pos_mid_wt1_gr=sumPosMat_mid1(find(sumPosMat_mid1>grThan));
minus_pos_mid_wt1_gr=sumPosMat_mid1(find(sumPosMat_mid1<-(grThan)));

plus_pos_dist_wt1_gr=sumPosMat_dist1(find(sumPosMat_dist1>grThan));
minus_pos_dist_wt1_gr=sumPosMat_dist1(find(sumPosMat_dist1<-(grThan)));

plus_pos_prox_wt2_gr=sumPosMat_prox2(find(sumPosMat_prox2>grThan));
minus_pos_prox_wt2_gr=sumPosMat_prox2(find(sumPosMat_prox2<-(grThan)));

plus_pos_mid_wt2_gr=sumPosMat_mid2(find(sumPosMat_mid2>grThan));
minus_pos_mid_wt2_gr=sumPosMat_mid2(find(sumPosMat_mid2<-(grThan)));

plus_pos_dist_wt2_gr=sumPosMat_dist2(find(sumPosMat_dist2>grThan));
minus_pos_dist_wt2_gr=sumPosMat_dist2(find(sumPosMat_dist2<-(grThan)));

plus_pos_prox_wt3_gr=sumPosMat_prox3(find(sumPosMat_prox3>grThan));
minus_pos_prox_wt3_gr=sumPosMat_prox3(find(sumPosMat_prox3<-(grThan)));

plus_pos_mid_wt3_gr=sumPosMat_mid3(find(sumPosMat_mid3>grThan));
minus_pos_mid_wt3_gr=sumPosMat_mid3(find(sumPosMat_mid3<-(grThan)));

plus_pos_dist_wt3_gr=sumPosMat_dist3(find(sumPosMat_dist3>grThan));
minus_pos_dist_wt3_gr=sumPosMat_dist3(find(sumPosMat_dist3<-(grThan)));


hist_plus_prox_wt=hist(plus_pos_prox_wt,plus_pos_xp);
 hist_plus_mid_wt=hist(plus_pos_mid_wt,plus_pos_xp);
  hist_plus_dist_wt=hist(plus_pos_dist_wt,plus_pos_xp);
hist_minus_prox_wt=hist(minus_pos_prox_wt,minus_pos_xp);
 hist_minus_mid_wt=hist(minus_pos_mid_wt,minus_pos_xp);
  hist_minus_dist_wt=hist(minus_pos_dist_wt,minus_pos_xp);
  
  hist_plus_prox_wt1=hist(plus_pos_prox_wt1,plus_pos_xp);
 hist_plus_mid_wt1=hist(plus_pos_mid_wt1,plus_pos_xp);
  hist_plus_dist_wt1=hist(plus_pos_dist_wt1,plus_pos_xp);
hist_minus_prox_wt1=hist(minus_pos_prox_wt1,minus_pos_xp);
 hist_minus_mid_wt1=hist(minus_pos_mid_wt1,minus_pos_xp);
  hist_minus_dist_wt1=hist(minus_pos_dist_wt1,minus_pos_xp);
  
  hist_plus_prox_wt2=hist(plus_pos_prox_wt2,plus_pos_xp);
 hist_plus_mid_wt2=hist(plus_pos_mid_wt2,plus_pos_xp);
  hist_plus_dist_wt2=hist(plus_pos_dist_wt2,plus_pos_xp);
hist_minus_prox_wt2=hist(minus_pos_prox_wt2,minus_pos_xp);
 hist_minus_mid_wt2=hist(minus_pos_mid_wt2,minus_pos_xp);
  hist_minus_dist_wt2=hist(minus_pos_dist_wt2,minus_pos_xp);
  
  hist_plus_prox_wt3=hist(plus_pos_prox_wt3,plus_pos_xp);
 hist_plus_mid_wt3=hist(plus_pos_mid_wt3,plus_pos_xp);
  hist_plus_dist_wt3=hist(plus_pos_dist_wt3,plus_pos_xp);
hist_minus_prox_wt3=hist(minus_pos_prox_wt3,minus_pos_xp);
 hist_minus_mid_wt3=hist(minus_pos_mid_wt3,minus_pos_xp);
  hist_minus_dist_wt3=hist(minus_pos_dist_wt3,minus_pos_xp);

  
  % travel histograms for all regions combined plus
    hist_plus_all_wt1=hist([plus_pos_prox_wt1,plus_pos_mid_wt1,plus_pos_dist_wt1],plus_pos_xp);
 
    hist_plus_all_wt2=hist([plus_pos_prox_wt2,plus_pos_mid_wt2,plus_pos_dist_wt2],plus_pos_xp);
    
    hist_plus_all_wt3=hist([plus_pos_prox_wt3,plus_pos_mid_wt3,plus_pos_dist_wt3],plus_pos_xp);

  % travel histograms for all regions combined minus
    hist_minus_all_wt1=hist([minus_pos_prox_wt1,minus_pos_mid_wt1,minus_pos_dist_wt1],minus_pos_xp);
 
    hist_minus_all_wt2=hist([minus_pos_prox_wt2,minus_pos_mid_wt2,minus_pos_dist_wt2],minus_pos_xp);
    
    hist_minus_all_wt3=hist([minus_pos_prox_wt3,minus_pos_mid_wt3,minus_pos_dist_wt3],minus_pos_xp);
    
    
elseif k_choose==4  %AP14
plus_pos_prox_ap=sumPosMat_prox(find(sumPosMat_prox>0));
minus_pos_prox_ap=sumPosMat_prox(find(sumPosMat_prox<0));

plus_pos_mid_ap=sumPosMat_mid(find(sumPosMat_mid>0));
minus_pos_mid_ap=sumPosMat_mid(find(sumPosMat_mid<0));

plus_pos_dist_ap=sumPosMat_dist(find(sumPosMat_dist>0));
minus_pos_dist_ap=sumPosMat_dist(find(sumPosMat_dist<0));


plus_pos_prox_ap_gr=sumPosMat_prox(find(sumPosMat_prox>grThan));
minus_pos_prox_ap_gr=sumPosMat_prox(find(sumPosMat_prox<-(grThan)));

plus_pos_mid_ap_gr=sumPosMat_mid(find(sumPosMat_mid>grThan));
minus_pos_mid_ap_gr=sumPosMat_mid(find(sumPosMat_mid<-(grThan)));

plus_pos_dist_ap_gr=sumPosMat_dist(find(sumPosMat_dist>grThan));
minus_pos_dist_ap_gr=sumPosMat_dist(find(sumPosMat_dist<-(grThan)));
 

    
    hist_plus_prox_ap=hist(plus_pos_prox_ap,plus_pos_xp);
 hist_plus_mid_ap=hist(plus_pos_mid_ap,plus_pos_xp);
  hist_plus_dist_ap=hist(plus_pos_dist_ap,plus_pos_xp);
hist_minus_prox_ap=hist(minus_pos_prox_ap,minus_pos_xp);
 hist_minus_mid_ap=hist(minus_pos_mid_ap,minus_pos_xp);
  hist_minus_dist_ap=hist(minus_pos_dist_ap,minus_pos_xp)
  
  plus_pos_prox_ap1=sumPosMat_prox1(find(sumPosMat_prox1>0));
minus_pos_prox_ap1=sumPosMat_prox1(find(sumPosMat_prox1<0));

plus_pos_mid_ap1=sumPosMat_mid1(find(sumPosMat_mid1>0));
minus_pos_mid_ap1=sumPosMat_mid1(find(sumPosMat_mid1<0));

plus_pos_dist_ap1=sumPosMat_dist1(find(sumPosMat_dist1>0));
minus_pos_dist_ap1=sumPosMat_dist1(find(sumPosMat_dist1<0));



  plus_pos_prox_ap1_gr=sumPosMat_prox1(find(sumPosMat_prox1>grThan));
minus_pos_prox_ap1_gr=sumPosMat_prox1(find(sumPosMat_prox1<-(grThan)));

plus_pos_mid_ap1_gr=sumPosMat_mid1(find(sumPosMat_mid1>grThan));
minus_pos_mid_ap1_gr=sumPosMat_mid1(find(sumPosMat_mid1<-(grThan)));

plus_pos_dist_ap1_gr=sumPosMat_dist1(find(sumPosMat_dist1>grThan));
minus_pos_dist_ap1_gr=sumPosMat_dist1(find(sumPosMat_dist1<-(grThan)));


hist_plus_prox_ap1=hist(plus_pos_prox_ap1,plus_pos_xp);
 hist_plus_mid_ap1=hist(plus_pos_mid_ap1,plus_pos_xp);
  hist_plus_dist_ap1=hist(plus_pos_dist_ap1,plus_pos_xp);
hist_minus_prox_ap1=hist(minus_pos_prox_ap1,minus_pos_xp);
 hist_minus_mid_ap1=hist(minus_pos_mid_ap1,minus_pos_xp);
  hist_minus_dist_ap1=hist(minus_pos_dist_ap1,minus_pos_xp)
  
  plus_pos_prox_ap2=sumPosMat_prox2(find(sumPosMat_prox2>0));
minus_pos_prox_ap2=sumPosMat_prox2(find(sumPosMat_prox2<0));

plus_pos_mid_ap2=sumPosMat_mid2(find(sumPosMat_mid2>0));
minus_pos_mid_ap2=sumPosMat_mid2(find(sumPosMat_mid2<0));

plus_pos_dist_ap2=sumPosMat_dist2(find(sumPosMat_dist2>0));
minus_pos_dist_ap2=sumPosMat_dist2(find(sumPosMat_dist2<0));


  plus_pos_prox_ap2_gr=sumPosMat_prox2(find(sumPosMat_prox2>grThan));
minus_pos_prox_ap2_gr=sumPosMat_prox2(find(sumPosMat_prox2<-(grThan)));

plus_pos_mid_ap2_gr=sumPosMat_mid2(find(sumPosMat_mid2>grThan));
minus_pos_mid_ap2_gr=sumPosMat_mid2(find(sumPosMat_mid2<-(grThan)));

plus_pos_dist_ap2_gr=sumPosMat_dist2(find(sumPosMat_dist2>grThan));
minus_pos_dist_ap2_gr=sumPosMat_dist2(find(sumPosMat_dist2<-(grThan)));

hist_plus_prox_ap2=hist(plus_pos_prox_ap2,plus_pos_xp);
 hist_plus_mid_ap2=hist(plus_pos_mid_ap2,plus_pos_xp);
  hist_plus_dist_ap2=hist(plus_pos_dist_ap2,plus_pos_xp);
hist_minus_prox_ap2=hist(minus_pos_prox_ap2,minus_pos_xp);
 hist_minus_mid_ap2=hist(minus_pos_mid_ap2,minus_pos_xp);
  hist_minus_dist_ap2=hist(minus_pos_dist_ap2,minus_pos_xp)
  
plus_pos_prox_ap3=sumPosMat_prox3(find(sumPosMat_prox3>0));
minus_pos_prox_ap3=sumPosMat_prox3(find(sumPosMat_prox3<0));

plus_pos_mid_ap3=sumPosMat_mid3(find(sumPosMat_mid3>0));
minus_pos_mid_ap3=sumPosMat_mid3(find(sumPosMat_mid3<0));

plus_pos_dist_ap3=sumPosMat_dist3(find(sumPosMat_dist3>0));
minus_pos_dist_ap3=sumPosMat_dist3(find(sumPosMat_dist3<0));



  plus_pos_prox_ap3_gr=sumPosMat_prox3(find(sumPosMat_prox3>grThan));
minus_pos_prox_ap3_gr=sumPosMat_prox3(find(sumPosMat_prox3<-(grThan)));

plus_pos_mid_ap3_gr=sumPosMat_mid3(find(sumPosMat_mid3>grThan));
minus_pos_mid_ap3_gr=sumPosMat_mid3(find(sumPosMat_mid3<-(grThan)));

plus_pos_dist_ap3_gr=sumPosMat_dist3(find(sumPosMat_dist3>grThan));
minus_pos_dist_ap3_gr=sumPosMat_dist3(find(sumPosMat_dist3<-(grThan)));

hist_plus_prox_ap3=hist(plus_pos_prox_ap3,plus_pos_xp);
 hist_plus_mid_ap3=hist(plus_pos_mid_ap3,plus_pos_xp);
  hist_plus_dist_ap3=hist(plus_pos_dist_ap3,plus_pos_xp);
hist_minus_prox_ap3=hist(minus_pos_prox_ap3,minus_pos_xp);
 hist_minus_mid_ap3=hist(minus_pos_mid_ap3,minus_pos_xp);
  hist_minus_dist_ap3=hist(minus_pos_dist_ap3,minus_pos_xp)
 
  % travel histograms for all regions combined plus
    hist_plus_all_ap1=hist([plus_pos_prox_ap1,plus_pos_mid_ap1,plus_pos_dist_ap1],plus_pos_xp);
 
    hist_plus_all_ap2=hist([plus_pos_prox_ap2,plus_pos_mid_ap2,plus_pos_dist_ap2],plus_pos_xp);
    
    hist_plus_all_ap3=hist([plus_pos_prox_ap3,plus_pos_mid_ap3,plus_pos_dist_ap3],plus_pos_xp);

      % travel histograms for all regions combined minus
    hist_minus_all_ap1=hist([minus_pos_prox_ap1,minus_pos_mid_ap1,minus_pos_dist_ap1],minus_pos_xp);
 
    hist_minus_all_ap2=hist([minus_pos_prox_ap2,minus_pos_mid_ap2,minus_pos_dist_ap2],minus_pos_xp);
    
    hist_minus_all_ap3=hist([minus_pos_prox_ap3,minus_pos_mid_ap3,minus_pos_dist_ap3],minus_pos_xp);
    
    
    
elseif k_choose==5  %E14
plus_pos_prox_e=sumPosMat_prox(find(sumPosMat_prox>0));
minus_pos_prox_e=sumPosMat_prox(find(sumPosMat_prox<0));

plus_pos_mid_e=sumPosMat_mid(find(sumPosMat_mid>0));
minus_pos_mid_e=sumPosMat_mid(find(sumPosMat_mid<0));

plus_pos_dist_e=sumPosMat_dist(find(sumPosMat_dist>0));
minus_pos_dist_e=sumPosMat_dist(find(sumPosMat_dist<0));



plus_pos_prox_e_gr=sumPosMat_prox(find(sumPosMat_prox>grThan));
minus_pos_prox_e_gr=sumPosMat_prox(find(sumPosMat_prox<-(grThan)));

plus_pos_mid_e_gr=sumPosMat_mid(find(sumPosMat_mid>grThan));
minus_pos_mid_e_gr=sumPosMat_mid(find(sumPosMat_mid<-(grThan)));

plus_pos_dist_e_gr=sumPosMat_dist(find(sumPosMat_dist>grThan));
minus_pos_dist_e_gr=sumPosMat_dist(find(sumPosMat_dist<-(grThan)));

hist_plus_prox_e=hist(plus_pos_prox_e,plus_pos_xp);
 hist_plus_mid_e=hist(plus_pos_mid_e,plus_pos_xp);
  hist_plus_dist_e=hist(plus_pos_dist_e,plus_pos_xp);
hist_minus_prox_e=hist(minus_pos_prox_e,minus_pos_xp);
 hist_minus_mid_e=hist(minus_pos_mid_e,minus_pos_xp);
  hist_minus_dist_e=hist(minus_pos_dist_e,minus_pos_xp)
  
plus_pos_prox_e1=sumPosMat_prox1(find(sumPosMat_prox1>0));
minus_pos_prox_e1=sumPosMat_prox1(find(sumPosMat_prox1<0));

plus_pos_mid_e1=sumPosMat_mid1(find(sumPosMat_mid1>0));
minus_pos_mid_e1=sumPosMat_mid1(find(sumPosMat_mid1<0));

plus_pos_dist_e1=sumPosMat_dist1(find(sumPosMat_dist1>0));
minus_pos_dist_e1=sumPosMat_dist1(find(sumPosMat_dist1<0));



plus_pos_prox_e1_gr=sumPosMat_prox1(find(sumPosMat_prox1>grThan));
minus_pos_prox_e1_gr=sumPosMat_prox1(find(sumPosMat_prox1<-(grThan)));

plus_pos_mid_e1_gr=sumPosMat_mid1(find(sumPosMat_mid1>grThan));
minus_pos_mid_e1_gr=sumPosMat_mid1(find(sumPosMat_mid1<-(grThan)));

plus_pos_dist_e1_gr=sumPosMat_dist1(find(sumPosMat_dist1>grThan));
minus_pos_dist_e1_gr=sumPosMat_dist1(find(sumPosMat_dist1<-(grThan)));


hist_plus_prox_e1=hist(plus_pos_prox_e1,plus_pos_xp);
 hist_plus_mid_e1=hist(plus_pos_mid_e1,plus_pos_xp);
  hist_plus_dist_e1=hist(plus_pos_dist_e1,plus_pos_xp);
hist_minus_prox_e1=hist(minus_pos_prox_e1,minus_pos_xp);
 hist_minus_mid_e1=hist(minus_pos_mid_e1,minus_pos_xp);
  hist_minus_dist_e1=hist(minus_pos_dist_e1,minus_pos_xp)
  
  
plus_pos_prox_e2=sumPosMat_prox2(find(sumPosMat_prox2>0));
minus_pos_prox_e2=sumPosMat_prox2(find(sumPosMat_prox2<0));

plus_pos_mid_e2=sumPosMat_mid2(find(sumPosMat_mid2>0));
minus_pos_mid_e2=sumPosMat_mid2(find(sumPosMat_mid2<0));

plus_pos_dist_e2=sumPosMat_dist2(find(sumPosMat_dist2>0));
minus_pos_dist_e2=sumPosMat_dist2(find(sumPosMat_dist2<0));



plus_pos_prox_e2_gr=sumPosMat_prox2(find(sumPosMat_prox2>grThan));
minus_pos_prox_e2_gr=sumPosMat_prox2(find(sumPosMat_prox2<-(grThan)));

plus_pos_mid_e2_gr=sumPosMat_mid2(find(sumPosMat_mid2>grThan));
minus_pos_mid_e2_gr=sumPosMat_mid2(find(sumPosMat_mid2<-(grThan)));

plus_pos_dist_e2_gr=sumPosMat_dist2(find(sumPosMat_dist2>grThan));
minus_pos_dist_e2_gr=sumPosMat_dist2(find(sumPosMat_dist2<-(grThan)));


hist_plus_prox_e2=hist(plus_pos_prox_e2,plus_pos_xp);
 hist_plus_mid_e2=hist(plus_pos_mid_e2,plus_pos_xp);
  hist_plus_dist_e2=hist(plus_pos_dist_e2,plus_pos_xp);
hist_minus_prox_e2=hist(minus_pos_prox_e2,minus_pos_xp);
 hist_minus_mid_e2=hist(minus_pos_mid_e2,minus_pos_xp);
  hist_minus_dist_e2=hist(minus_pos_dist_e2,minus_pos_xp)
  
plus_pos_prox_e3=sumPosMat_prox3(find(sumPosMat_prox3>0));
minus_pos_prox_e3=sumPosMat_prox3(find(sumPosMat_prox3<0));

plus_pos_mid_e3=sumPosMat_mid3(find(sumPosMat_mid3>0));
minus_pos_mid_e3=sumPosMat_mid3(find(sumPosMat_mid3<0));

plus_pos_dist_e3=sumPosMat_dist3(find(sumPosMat_dist3>0));
minus_pos_dist_e3=sumPosMat_dist3(find(sumPosMat_dist3<0));


plus_pos_prox_e3_gr=sumPosMat_prox3(find(sumPosMat_prox3>grThan));
minus_pos_prox_e3_gr=sumPosMat_prox3(find(sumPosMat_prox3<-(grThan)));

plus_pos_mid_e3_gr=sumPosMat_mid3(find(sumPosMat_mid3>grThan));
minus_pos_mid_e3_gr=sumPosMat_mid3(find(sumPosMat_mid3<-(grThan)));

plus_pos_dist_e3_gr=sumPosMat_dist3(find(sumPosMat_dist3>grThan));
minus_pos_dist_e3_gr=sumPosMat_dist3(find(sumPosMat_dist3<-(grThan)));

hist_plus_prox_e3=hist(plus_pos_prox_e3,plus_pos_xp);
 hist_plus_mid_e3=hist(plus_pos_mid_e3,plus_pos_xp);
  hist_plus_dist_e3=hist(plus_pos_dist_e3,plus_pos_xp);
hist_minus_prox_e3=hist(minus_pos_prox_e3,minus_pos_xp);
 hist_minus_mid_e3=hist(minus_pos_mid_e3,minus_pos_xp);
  hist_minus_dist_e3=hist(minus_pos_dist_e3,minus_pos_xp)
 
  
  % travel histograms for all regions combined plus
    hist_plus_all_e1=hist([plus_pos_prox_e1,plus_pos_mid_e1,plus_pos_dist_e1],plus_pos_xp);
 
    hist_plus_all_e2=hist([plus_pos_prox_e2,plus_pos_mid_e2,plus_pos_dist_e2],plus_pos_xp);
    
    hist_plus_all_e3=hist([plus_pos_prox_e3,plus_pos_mid_e3,plus_pos_dist_e3],plus_pos_xp);

  % travel histograms for all regions combined minus
    hist_minus_all_e1=hist([minus_pos_prox_e1,minus_pos_mid_e1,minus_pos_dist_e1],minus_pos_xp);
 
    hist_minus_all_e2=hist([minus_pos_prox_e2,minus_pos_mid_e2,minus_pos_dist_e2],minus_pos_xp);
    
    hist_minus_all_e3=hist([minus_pos_prox_e3,minus_pos_mid_e3,minus_pos_dist_e3],minus_pos_xp);
    

else
end
  
end


plus_pos_wt1_all_gr = [plus_pos_prox_wt1_gr';plus_pos_mid_wt1_gr';plus_pos_dist_wt1_gr']';
plus_pos_wt2_all_gr = [plus_pos_prox_wt2_gr';plus_pos_mid_wt2_gr';plus_pos_dist_wt2_gr']';
plus_pos_wt3_all_gr = [plus_pos_prox_wt3_gr';plus_pos_mid_wt3_gr';plus_pos_dist_wt3_gr']';

plus_pos_ap1_all_gr = [plus_pos_prox_ap1_gr';plus_pos_mid_ap1_gr';plus_pos_dist_ap1_gr']';
plus_pos_ap2_all_gr = [plus_pos_prox_ap2_gr';plus_pos_mid_ap2_gr';plus_pos_dist_ap2_gr']';
plus_pos_ap3_all_gr = [plus_pos_prox_ap3_gr';plus_pos_mid_ap3_gr';plus_pos_dist_ap3_gr']';

plus_pos_e1_all_gr = [plus_pos_prox_e1_gr';plus_pos_mid_e1_gr';plus_pos_dist_e1_gr'];
plus_pos_e2_all_gr = [plus_pos_prox_e2_gr';plus_pos_mid_e2_gr';plus_pos_dist_e2_gr'];
plus_pos_e3_all_gr = [plus_pos_prox_e3_gr';plus_pos_mid_e3_gr';plus_pos_dist_e3_gr'];

%minus
minus_pos_wt1_all_gr = [minus_pos_prox_wt1_gr';minus_pos_mid_wt1_gr';minus_pos_dist_wt1_gr']';
minus_pos_wt2_all_gr = [minus_pos_prox_wt2_gr';minus_pos_mid_wt2_gr';minus_pos_dist_wt2_gr']';
minus_pos_wt3_all_gr = [minus_pos_prox_wt3_gr';minus_pos_mid_wt3_gr';minus_pos_dist_wt3_gr']';

minus_pos_ap1_all_gr = [minus_pos_prox_ap1_gr';minus_pos_mid_ap1_gr';minus_pos_dist_ap1_gr']';
minus_pos_ap2_all_gr = [minus_pos_prox_ap2_gr';minus_pos_mid_ap2_gr';minus_pos_dist_ap2_gr']';
minus_pos_ap3_all_gr = [minus_pos_prox_ap3_gr';minus_pos_mid_ap3_gr';minus_pos_dist_ap3_gr']';

minus_pos_e1_all_gr = [minus_pos_prox_e1_gr';minus_pos_mid_e1_gr';minus_pos_dist_e1_gr'];
minus_pos_e2_all_gr = [minus_pos_prox_e2_gr';minus_pos_mid_e2_gr';minus_pos_dist_e2_gr'];
minus_pos_e3_all_gr = [minus_pos_prox_e3_gr';minus_pos_mid_e3_gr';minus_pos_dist_e3_gr'];



%% Sum long distance travels

num_plus_long_traj(1)= sum(hist_plus_prox_c);
num_minus_long_traj(1)= sum(hist_minus_prox_c);

num_plus_long_traj(2)= sum(hist_plus_prox_ko);
num_minus_long_traj(2)= sum(hist_minus_prox_ko);

num_plus_long_traj(3)= sum(hist_plus_prox_wt);
num_minus_long_traj(3)= sum(hist_minus_prox_wt);

num_plus_long_traj(4)= sum(hist_plus_prox_ap);
num_minus_long_traj(4)= sum(hist_minus_prox_ap);

num_plus_long_traj(5)= sum(hist_plus_prox_e);
num_minus_long_traj(5)= sum(hist_minus_prox_e);



%% ctl
figure('Name','CTL Freq Travel Plots','NumberTitle','off'), 

 subplot(3,1,1), hold on, 
stairs(hist_plus_prox_c./sum(hist_plus_prox_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
stairs(hist_minus_prox_c./sum(hist_minus_prox_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
set(gca, 'XScale', 'log');
xlabel('Frequency'); ylabel('position (mm)'); 
xlim([0.0001 1]); ylim([-40 40]);
hold on, 
box on,

subplot(3,1,2), hold on, 
 stairs(hist_plus_mid_c./sum(hist_plus_mid_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
 hold on, 
 stairs(hist_minus_mid_c./sum(hist_minus_mid_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
 hold on, 
 set(gca, 'XScale', 'log');
xlim([0.0001 1]);ylim([-40 40]);
xlabel('Frequency'); ylabel(' position (mm)'); 
 box on,
 
 subplot(3,1,3), hold on, 
 stairs(hist_plus_dist_c./sum(hist_plus_dist_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
 hold on, 
 stairs(hist_minus_dist_c./sum(hist_minus_dist_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
 hold on, 
set(gca, 'XScale', 'log');
xlim([0.0001 1]);ylim([-40 40]);
xlabel('Frequency'); ylabel(' position (mm)'); 
box on,


%% ko
figure('Name','KO Freq Travel Plots','NumberTitle','off'), 

 subplot(3,1,1), hold on, 
  stairs(hist_plus_prox_c./sum(hist_plus_prox_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
stairs(hist_plus_prox_ko./sum(hist_plus_prox_ko),plus_pos_xp,'Color',dkBlue,'LineWidth',3);
hold on, 
 stairs(hist_minus_prox_c./sum(hist_minus_prox_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
stairs(hist_minus_prox_ko./sum(hist_minus_prox_ko),minus_pos_xp,'Color',dkBlue,'LineWidth',3);
hold on, 
set(gca, 'XScale', 'log');
xlabel('Frequency'); ylabel('position (mm)'); 
xlim([0.0001 1]); ylim([-40 40]);
hold on, 
box on,

subplot(3,1,2), hold on, 
 stairs(hist_plus_mid_c./sum(hist_plus_mid_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_plus_mid_ko./sum(hist_plus_mid_ko),plus_pos_xp,'Color',dkBlue,'LineWidth',3);
 hold on, 
  stairs(hist_minus_mid_c./sum(hist_minus_mid_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_minus_mid_ko./sum(hist_minus_mid_ko),minus_pos_xp,'Color',dkBlue,'LineWidth',3);
 hold on, 
 set(gca, 'XScale', 'log');
xlim([0.0001 1]);ylim([-40 40]);
xlabel('Frequency'); ylabel(' position (mm)'); 
 box on,
 
 subplot(3,1,3), hold on, 
  stairs(hist_plus_dist_c./sum(hist_plus_dist_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_plus_dist_ko./sum(hist_plus_dist_ko),plus_pos_xp,'Color',dkBlue,'LineWidth',3);
 hold on, 
  stairs(hist_minus_dist_c./sum(hist_minus_dist_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_minus_dist_ko./sum(hist_minus_dist_ko),minus_pos_xp,'Color',dkBlue,'LineWidth',3);
 hold on, 
set(gca, 'XScale', 'log');
xlim([0.0001 1]);ylim([-40 40]);
xlabel('Frequency'); ylabel(' position (mm)'); 
box on,

%% wt


sumWTprox_plus=(sum(hist_plus_prox_wt1)+sum(hist_plus_prox_wt2)+sum(hist_plus_prox_wt3));
sumWTprox_minus=(sum(hist_minus_prox_wt1)+sum(hist_minus_prox_wt2)+sum(hist_minus_prox_wt3));

sumWTmid_plus=(sum(hist_plus_mid_wt1)+sum(hist_plus_mid_wt2)+sum(hist_plus_mid_wt3));
sumWTmid_minus=(sum(hist_minus_mid_wt1)+sum(hist_minus_mid_wt2)+sum(hist_minus_mid_wt3));

sumWTdist_plus=(sum(hist_plus_dist_wt1)+sum(hist_plus_dist_wt2)+sum(hist_plus_dist_wt3));
sumWTdist_minus=(sum(hist_minus_dist_wt1)+sum(hist_minus_dist_wt2)+sum(hist_minus_dist_wt3));

%sum all regions
sumWTall_plus=(sum(hist_plus_all_wt1)+sum(hist_plus_all_wt2)+sum(hist_plus_all_wt3));
sumWTall_minus=(sum(hist_minus_all_wt1)+sum(hist_minus_all_wt2)+sum(hist_minus_all_wt3));

sumAPall_plus=(sum(hist_plus_all_ap1)+sum(hist_plus_all_ap2)+sum(hist_plus_all_ap3));
sumAPall_minus=(sum(hist_minus_all_ap1)+sum(hist_minus_all_ap2)+sum(hist_minus_all_ap3));

sumE14all_plus=(sum(hist_plus_all_e1)+sum(hist_plus_all_e2)+sum(hist_plus_all_e3));
sumE14all_minus=(sum(hist_minus_all_e1)+sum(hist_minus_all_e2)+sum(hist_minus_all_e3));



figure('Name','CTL allRegions Freq Travel Plots','NumberTitle','off'), 

 subplot(3,1,1), hold on, 
  stairs(hist_plus_all_c./sum(hist_plus_all_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_minus_all_c./sum(hist_minus_all_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
set(gca, 'XScale', 'log');
xlim([0.0001 1]);ylim([-40 40]);
xlabel('Frequency'); ylabel(' position (mm)'); 
box on,

figure('Name','CTL vs KO allRegions Freq Travel Plots','NumberTitle','off'), 

 subplot(3,1,1), hold on, 
  stairs(hist_plus_all_c./sum(hist_plus_all_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
stairs(hist_plus_all_ko./sum(hist_plus_all_ko),plus_pos_xp,'Color',dkBlue,'LineWidth',3);
hold on, 
 stairs(hist_minus_all_c./sum(hist_minus_all_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
stairs(hist_minus_all_ko./sum(hist_minus_all_ko),minus_pos_xp,'Color',dkBlue,'LineWidth',3);
hold on,  
set(gca, 'XScale', 'log');
xlim([0.0001 1]);ylim([-40 40]);
xlabel('Frequency'); ylabel(' position (mm)'); 
box on,

figure('Name','WT all regions Freq Travel Plots','NumberTitle','off'), 

 subplot(3,1,1), hold on, 
  stairs(hist_plus_all_c./sum(hist_plus_all_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_minus_all_c./sum(hist_minus_all_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 
stairs(hist_plus_all_wt1./sumWTall_plus,plus_pos_xp,'Color',lhtBlue,'LineWidth',4);
hold on, 
stairs(hist_plus_all_wt2./sumWTall_plus,plus_pos_xp,'Color',Orng,'LineWidth',3);
hold on, 
stairs(hist_plus_all_wt3./sumWTall_plus,plus_pos_xp,'Color',dkRed,'LineWidth',2);
hold on, 
 
 
stairs(hist_minus_all_wt1./sumWTall_minus,minus_pos_xp,'Color',lhtBlue,'LineWidth',4);
hold on, 
stairs(hist_minus_all_wt2./sumWTall_minus,minus_pos_xp,'Color',Orng,'LineWidth',3);
hold on, 
stairs(hist_minus_all_wt3./sumWTall_minus,minus_pos_xp,'Color',dkRed,'LineWidth',2);

set(gca, 'XScale', 'log');
xlim([0.0001 1]);ylim([-40 40]);
xlabel('Frequency'); ylabel(' position (mm)'); 
box on,


figure('Name','AP all regions Freq Travel Plots','NumberTitle','off'), 

 subplot(3,1,1), hold on, 
  stairs(hist_plus_all_c./sum(hist_plus_all_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_minus_all_c./sum(hist_minus_all_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 
stairs(hist_plus_all_ap1./sumAPall_plus,plus_pos_xp,'Color',lhtBlue,'LineWidth',4);
hold on, 
stairs(hist_plus_all_ap2./sumAPall_plus,plus_pos_xp,'Color',Orng,'LineWidth',3);
hold on, 
stairs(hist_plus_all_ap3./sumAPall_plus,plus_pos_xp,'Color',dkRed,'LineWidth',2);
hold on, 
 
 
stairs(hist_minus_all_ap1./sumAPall_minus,minus_pos_xp,'Color',lhtBlue,'LineWidth',4);
hold on, 
stairs(hist_minus_all_ap2./sumAPall_minus,minus_pos_xp,'Color',Orng,'LineWidth',3);
hold on, 
stairs(hist_minus_all_ap3./sumAPall_minus,minus_pos_xp,'Color',dkRed,'LineWidth',2);

set(gca, 'XScale', 'log');
xlim([0.0001 1]);ylim([-40 40]);
xlabel('Frequency'); ylabel(' position (mm)'); 
box on,


figure('Name','E14 all regions Freq Travel Plots','NumberTitle','off'), 

 subplot(3,1,1), hold on, 
  stairs(hist_plus_all_c./sum(hist_plus_all_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_minus_all_c./sum(hist_minus_all_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 
stairs(hist_plus_all_e1./sumE14all_plus,plus_pos_xp,'Color',lhtBlue,'LineWidth',4);
hold on, 
stairs(hist_plus_all_e2./sumE14all_plus,plus_pos_xp,'Color',Orng,'LineWidth',3);
hold on, 
stairs(hist_plus_all_e3./sumE14all_plus,plus_pos_xp,'Color',dkRed,'LineWidth',2);
hold on, 
 
 
stairs(hist_minus_all_e1./sumE14all_minus,minus_pos_xp,'Color',lhtBlue,'LineWidth',4);
hold on, 
stairs(hist_minus_all_e2./sumE14all_minus,minus_pos_xp,'Color',Orng,'LineWidth',3);
hold on, 
stairs(hist_minus_all_e3./sumE14all_minus,minus_pos_xp,'Color',dkRed,'LineWidth',2);

set(gca, 'XScale', 'log');
xlim([0.0001 1]);ylim([-40 40]);
xlabel('Frequency'); ylabel(' position (mm)'); 
box on,





  
figure('Name','WT Freq Travel Plots','NumberTitle','off'), 

 subplot(3,1,1), hold on, 
  stairs(hist_plus_prox_c./sum(hist_plus_prox_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
stairs(hist_plus_prox_ko./sum(hist_plus_prox_ko),plus_pos_xp,'Color',dkBlue,'LineWidth',3);
hold on, 
 stairs(hist_minus_prox_c./sum(hist_minus_prox_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
stairs(hist_minus_prox_ko./sum(hist_minus_prox_ko),minus_pos_xp,'Color',dkBlue,'LineWidth',3);
hold on,  
%  stairs(hist_plus_prox_wt./sumWTprox_plus,plus_pos_xp,'Color',dkRed,'LineWidth',4);
%  hold on, 
stairs(hist_plus_prox_wt1./sumWTprox_plus,plus_pos_xp,'Color',lhtBlue,'LineWidth',4);
hold on, 
stairs(hist_plus_prox_wt2./sumWTprox_plus,plus_pos_xp,'Color',Orng,'LineWidth',3);
hold on, 
stairs(hist_plus_prox_wt3./sumWTprox_plus,plus_pos_xp,'Color',dkRed,'LineWidth',2);
hold on, 
 
%  stairs(hist_minus_prox_wt./sumWTprox_minus,minus_pos_xp,'Color',dkRed,'LineWidth',4);
%  hold on, 
stairs(hist_minus_prox_wt1./sumWTprox_minus,minus_pos_xp,'Color',lhtBlue,'LineWidth',4);
hold on, 
stairs(hist_minus_prox_wt2./sumWTprox_minus,minus_pos_xp,'Color',Orng,'LineWidth',3);
hold on, 
stairs(hist_minus_prox_wt3./sumWTprox_minus,minus_pos_xp,'Color',dkRed,'LineWidth',2);
set(gca, 'XScale', 'log');
xlim([0.0001 1]);ylim([-40 40]);
xlabel('Frequency'); ylabel(' position (mm)'); 
box on,

 subplot(3,1,2), hold on, 
 stairs(hist_plus_mid_c./sum(hist_plus_mid_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_plus_mid_ko./sum(hist_plus_mid_ko),plus_pos_xp,'Color',dkBlue,'LineWidth',3);
 hold on, 
  stairs(hist_minus_mid_c./sum(hist_minus_mid_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_minus_mid_ko./sum(hist_minus_mid_ko),minus_pos_xp,'Color',dkBlue,'LineWidth',3);
 hold on, 
 
%   stairs(hist_plus_mid_wt./sumWTmid_plus,plus_pos_xp,'Color',dkRed,'LineWidth',4);
%   hold on, 
 stairs(hist_plus_mid_wt1./sumWTmid_plus,plus_pos_xp,'Color',lhtBlue,'LineWidth',4);
 hold on, 
 stairs(hist_plus_mid_wt2./sumWTmid_plus,plus_pos_xp,'Color',Orng,'LineWidth',3);
 hold on, 
 stairs(hist_plus_mid_wt3./sumWTmid_plus,plus_pos_xp,'Color',dkRed,'LineWidth',2);
 hold on, 
  
%   stairs(hist_minus_mid_wt./sumWTmid_minus,minus_pos_xp,'Color',dkRed,'LineWidth',4);
%   hold on, 
 stairs(hist_minus_mid_wt1./sumWTmid_minus,minus_pos_xp,'Color',lhtBlue,'LineWidth',4);
 hold on, 
 stairs(hist_minus_mid_wt2./sumWTmid_minus,minus_pos_xp,'Color',Orng,'LineWidth',3);
 hold on,  
 stairs(hist_minus_mid_wt3./sumWTmid_minus,minus_pos_xp,'Color',dkRed,'LineWidth',2);
 hold on, 
set(gca, 'XScale', 'log');
xlim([0.0001 1]);ylim([-40 40]);
xlabel('Frequency'); ylabel(' position (mm)'); 
box on,

 subplot(3,1,3), hold on, 
  stairs(hist_plus_dist_c./sum(hist_plus_dist_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_plus_dist_ko./sum(hist_plus_dist_ko),plus_pos_xp,'Color',dkBlue,'LineWidth',3);
 hold on, 
  stairs(hist_minus_dist_c./sum(hist_minus_dist_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_minus_dist_ko./sum(hist_minus_dist_ko),minus_pos_xp,'Color',dkBlue,'LineWidth',3);
 hold on,
 
%   stairs(hist_plus_dist_wt./sumWTdist_plus,plus_pos_xp,'Color',dkRed,'LineWidth',4);
%   hold on, 
 stairs(hist_plus_dist_wt1./sumWTdist_plus,plus_pos_xp,'Color',lhtBlue,'LineWidth',4);
 hold on, 
 stairs(hist_plus_dist_wt2./sumWTdist_plus,plus_pos_xp,'Color',Orng,'LineWidth',3);
 hold on, 
 stairs(hist_plus_dist_wt3./sumWTdist_plus,plus_pos_xp,'Color',dkRed,'LineWidth',2);
 hold on, 

%   stairs(hist_minus_dist_wt./sumWTdist_minus,minus_pos_xp,'Color',dkRed,'LineWidth',4);
%   hold on, 
 stairs(hist_minus_dist_wt1./sumWTdist_minus,minus_pos_xp,'Color',lhtBlue,'LineWidth',4);
 hold on, 
 stairs(hist_minus_dist_wt2./sumWTdist_minus,minus_pos_xp,'Color',Orng,'LineWidth',3);
 hold on,  
 stairs(hist_minus_dist_wt3./sumWTdist_minus,minus_pos_xp,'Color',dkRed,'LineWidth',2);
 hold on, 
set(gca, 'XScale', 'log');
xlim([0.0001 1]);ylim([-40 40]);
xlabel('Frequency'); ylabel(' position (mm)'); 
box on,

%% ap

sumAPprox_plus=(sum(hist_plus_prox_ap1)+sum(hist_plus_prox_ap2)+sum(hist_plus_prox_ap3));
sumAPprox_minus=(sum(hist_minus_prox_ap1)+sum(hist_minus_prox_ap2)+sum(hist_minus_prox_ap3));

sumAPmid_plus=(sum(hist_plus_mid_ap1)+sum(hist_plus_mid_ap2)+sum(hist_plus_mid_ap3));
sumAPmid_minus=(sum(hist_minus_mid_ap1)+sum(hist_minus_mid_ap2)+sum(hist_minus_mid_ap3));

sumAPdist_plus=(sum(hist_plus_dist_ap1)+sum(hist_plus_dist_ap2)+sum(hist_plus_dist_ap3));
sumAPdist_minus=(sum(hist_minus_dist_ap1)+sum(hist_minus_dist_ap2)+sum(hist_minus_dist_ap3));

figure('Name','AP Freq Travel Plots','NumberTitle','off'), 

 subplot(3,1,1), hold on, 
  stairs(hist_plus_prox_c./sum(hist_plus_prox_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
stairs(hist_plus_prox_ko./sum(hist_plus_prox_ko),plus_pos_xp,'Color',dkBlue,'LineWidth',3);
hold on, 
 stairs(hist_minus_prox_c./sum(hist_minus_prox_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
stairs(hist_minus_prox_ko./sum(hist_minus_prox_ko),minus_pos_xp,'Color',dkBlue,'LineWidth',3);
hold on, 

%  stairs(hist_plus_prox_ap./sumAPprox_plus,plus_pos_xp,'Color',dkRed,'LineWidth',4);
%  hold on, 
stairs(hist_plus_prox_ap1./sumAPprox_plus,plus_pos_xp,'Color',lhtBlue,'LineWidth',4);
hold on, 
stairs(hist_plus_prox_ap2./sumAPprox_plus,plus_pos_xp,'Color',Orng,'LineWidth',3);
hold on, 
stairs(hist_plus_prox_ap3./sumAPprox_plus,plus_pos_xp,'Color',dkRed,'LineWidth',2);
hold on, 

 
%  stairs(hist_minus_prox_ap./sumAPprox_minus,minus_pos_xp,'Color',dkRed,'LineWidth',4);
%  hold on, 
stairs(hist_minus_prox_ap1./sumAPprox_minus,minus_pos_xp,'Color',lhtBlue,'LineWidth',4);
hold on, 
stairs(hist_minus_prox_ap2./sumAPprox_minus,minus_pos_xp,'Color',Orng,'LineWidth',3);
hold on, 
stairs(hist_minus_prox_ap3./sumAPprox_minus,minus_pos_xp,'Color',dkRed,'LineWidth',2);
hold on,
set(gca, 'XScale', 'log');
xlim([0.0001 1]);ylim([-40 40]);
xlabel('Frequency'); ylabel('position (mm)'); 
box on,

 subplot(3,1,2), hold on, 
 stairs(hist_plus_mid_c./sum(hist_plus_mid_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_plus_mid_ko./sum(hist_plus_mid_ko),plus_pos_xp,'Color',dkBlue,'LineWidth',3);
 hold on, 
  stairs(hist_minus_mid_c./sum(hist_minus_mid_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_minus_mid_ko./sum(hist_minus_mid_ko),minus_pos_xp,'Color',dkBlue,'LineWidth',3);
 hold on, 
%   stairs(hist_plus_mid_ap./sumAPmid_plus,plus_pos_xp,'Color',dkRed,'LineWidth',4);
%   hold on, 
 stairs(hist_plus_mid_ap1./sumAPmid_plus,plus_pos_xp,'Color',lhtBlue,'LineWidth',4);
 hold on, 
 stairs(hist_plus_mid_ap2./sumAPmid_plus,plus_pos_xp,'Color',Orng,'LineWidth',3);
 hold on, 
 stairs(hist_plus_mid_ap3./sumAPmid_plus,plus_pos_xp,'Color',dkRed,'LineWidth',2);
 hold on, 

%   stairs(hist_minus_mid_ap./sumAPmid_minus,minus_pos_xp,'Color',dkRed,'LineWidth',4);
%   hold on, 
 stairs(hist_minus_mid_ap1./sumAPmid_minus,minus_pos_xp,'Color',lhtBlue,'LineWidth',4);
 hold on, 
 stairs(hist_minus_mid_ap2./sumAPmid_minus,minus_pos_xp,'Color',Orng,'LineWidth',3);
 hold on,  
 stairs(hist_minus_mid_ap3./sumAPmid_minus,minus_pos_xp,'Color',dkRed,'LineWidth',2);
 hold on, 
set(gca, 'XScale', 'log');
xlim([0.0001 1]);ylim([-40 40]);
xlabel('Frequency'); ylabel('position (mm)'); 
box on,

 subplot(3,1,3), hold on, 
  stairs(hist_plus_dist_c./sum(hist_plus_dist_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_plus_dist_ko./sum(hist_plus_dist_ko),plus_pos_xp,'Color',dkBlue,'LineWidth',3);
 hold on, 
  stairs(hist_minus_dist_c./sum(hist_minus_dist_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_minus_dist_ko./sum(hist_minus_dist_ko),minus_pos_xp,'Color',dkBlue,'LineWidth',3);
 hold on,
 
%   stairs(hist_plus_dist_ap./sumAPdist_plus,plus_pos_xp,'Color',dkRed,'LineWidth',4);
%   hold on, 
 stairs(hist_plus_dist_ap1./sumAPdist_plus,plus_pos_xp,'Color',lhtBlue,'LineWidth',4);
 hold on, 
 stairs(hist_plus_dist_ap2./sumAPdist_plus,plus_pos_xp,'Color',Orng,'LineWidth',3);
 hold on, 
 stairs(hist_plus_dist_ap3./sumAPdist_plus,plus_pos_xp,'Color',dkRed,'LineWidth',2);
 hold on, 
  
%   stairs(hist_minus_dist_ap./sumAPdist_minus,minus_pos_xp,'Color',dkRed,'LineWidth',4);
%   hold on, 
 stairs(hist_minus_dist_ap1./sumAPdist_minus,minus_pos_xp,'Color',lhtBlue,'LineWidth',4);
 hold on, 
 stairs(hist_minus_dist_ap2./sumAPdist_minus,minus_pos_xp,'Color',Orng,'LineWidth',3);
 hold on,  
 stairs(hist_minus_dist_ap3./sumAPdist_minus,minus_pos_xp,'Color',dkRed,'LineWidth',2);
 hold on, 
set(gca, 'XScale', 'log');
xlim([0.0001 1]);ylim([-40 40]);
xlabel('Frequency'); ylabel('position (mm)'); 
box on,

%% e14
sumE14prox_plus=(sum(hist_plus_prox_e1)+sum(hist_plus_prox_e2)+sum(hist_plus_prox_e3));
sumE14prox_minus=(sum(hist_minus_prox_e1)+sum(hist_minus_prox_e2)+sum(hist_minus_prox_e3));

sumE14mid_plus=(sum(hist_plus_mid_e1)+sum(hist_plus_mid_e2)+sum(hist_plus_mid_e3));
sumE14mid_minus=(sum(hist_minus_mid_e1)+sum(hist_minus_mid_e2)+sum(hist_minus_mid_e3));

sumE14dist_plus=(sum(hist_plus_dist_e1)+sum(hist_plus_dist_e2)+sum(hist_plus_dist_e3));
sumE14dist_minus=(sum(hist_minus_dist_e1)+sum(hist_minus_dist_e2)+sum(hist_minus_dist_e3));


figure('Name','E14 Freq Travel Plots','NumberTitle','off'), 
 subplot(3,1,1), hold on, 
  stairs(hist_plus_prox_c./sum(hist_plus_prox_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
stairs(hist_plus_prox_ko./sum(hist_plus_prox_ko),plus_pos_xp,'Color',dkBlue,'LineWidth',3);
hold on, 
 stairs(hist_minus_prox_c./sum(hist_minus_prox_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
stairs(hist_minus_prox_ko./sum(hist_minus_prox_ko),minus_pos_xp,'Color',dkBlue,'LineWidth',3);
hold on,  
%  stairs(hist_plus_prox_e./sumE14prox_plus,plus_pos_xp,'Color',dkRed,'LineWidth',4);
%  hold on, 
stairs(hist_plus_prox_e1./sumE14prox_plus,plus_pos_xp,'Color',lhtBlue,'LineWidth',4);
hold on, 
stairs(hist_plus_prox_e2./sumE14prox_plus,plus_pos_xp,'Color',Orng,'LineWidth',3);
hold on, 
stairs(hist_plus_prox_e3./sumE14prox_plus,plus_pos_xp,'Color',dkRed,'LineWidth',2);
hold on, 

%  stairs(hist_minus_prox_e./sumE14prox_minus,minus_pos_xp,'Color',dkRed,'LineWidth',4);
%  hold on, 
stairs(hist_minus_prox_e1./sumE14prox_minus,minus_pos_xp,'Color',lhtBlue,'LineWidth',4);
hold on, 
stairs(hist_minus_prox_e2./sumE14prox_minus,minus_pos_xp,'Color',Orng,'LineWidth',3);
hold on, 
stairs(hist_minus_prox_e3./sumE14prox_minus,minus_pos_xp,'Color',dkRed,'LineWidth',2);
hold on,
set(gca, 'XScale', 'log');
xlim([0.0001 1]);ylim([-40 40]);
xlabel('Frequency'); ylabel('position (mm)'); 
box on,

 subplot(3,1,2), hold on, 
 stairs(hist_plus_mid_c./sum(hist_plus_mid_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_plus_mid_ko./sum(hist_plus_mid_ko),plus_pos_xp,'Color',dkBlue,'LineWidth',3);
 hold on, 
  stairs(hist_minus_mid_c./sum(hist_minus_mid_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_minus_mid_ko./sum(hist_minus_mid_ko),minus_pos_xp,'Color',dkBlue,'LineWidth',3);
 hold on,  
%   stairs(hist_plus_mid_e./sumE14mid_plus,plus_pos_xp,'Color',dkRed,'LineWidth',4);
%   hold on, 
 stairs(hist_plus_mid_e1./sumE14mid_plus,plus_pos_xp,'Color',lhtBlue,'LineWidth',4);
 hold on, 
 stairs(hist_plus_mid_e2./sumE14mid_plus,plus_pos_xp,'Color',Orng,'LineWidth',3);
 hold on, 
 stairs(hist_plus_mid_e3./sumE14mid_plus,plus_pos_xp,'Color',dkRed,'LineWidth',2);
 hold on, 
 

%   stairs(hist_minus_mid_e./sumE14mid_minus,minus_pos_xp,'Color',dkRed,'LineWidth',4);
%   hold on, 
 stairs(hist_minus_mid_e1./sumE14mid_minus,minus_pos_xp,'Color',lhtBlue,'LineWidth',4);
 hold on, 
 stairs(hist_minus_mid_e2./sumE14mid_minus,minus_pos_xp,'Color',Orng,'LineWidth',3);
 hold on,  
 stairs(hist_minus_mid_e3./sumE14mid_minus,minus_pos_xp,'Color',dkRed,'LineWidth',2);
 hold on, 
set(gca, 'XScale', 'log');
xlim([0.0001 1]);ylim([-40 40]);
xlabel('Frequency'); ylabel('position (mm)'); 
box on,

 subplot(3,1,3), hold on, 
  stairs(hist_plus_dist_c./sum(hist_plus_dist_c),plus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_plus_dist_ko./sum(hist_plus_dist_ko),plus_pos_xp,'Color',dkBlue,'LineWidth',3);
 hold on, 
  stairs(hist_minus_dist_c./sum(hist_minus_dist_c),minus_pos_xp,'Color',mdGrey,'LineWidth',3);
hold on, 
 stairs(hist_minus_dist_ko./sum(hist_minus_dist_ko),minus_pos_xp,'Color',dkBlue,'LineWidth',3);
 hold on, 
%   stairs(hist_plus_dist_e./sumE14dist_plus,plus_pos_xp,'Color',dkRed,'LineWidth',4);
%   hold on, 
 stairs(hist_plus_dist_e1./sumE14dist_plus,plus_pos_xp,'Color',lhtBlue,'LineWidth',4);
 hold on, 
 stairs(hist_plus_dist_e2./sumE14dist_plus,plus_pos_xp,'Color',Orng,'LineWidth',3);
 hold on, 
 stairs(hist_plus_dist_e3./sumE14dist_plus,plus_pos_xp,'Color',dkRed,'LineWidth',2);
 hold on, 
  
%   stairs(hist_minus_dist_e./sumE14dist_minus,minus_pos_xp,'Color',dkRed,'LineWidth',4);
%   hold on, 
 stairs(hist_minus_dist_e1./sumE14dist_minus,minus_pos_xp,'Color',lhtBlue,'LineWidth',4);
 hold on, 
 stairs(hist_minus_dist_e2./sumE14dist_minus,minus_pos_xp,'Color',Orng,'LineWidth',3);
 hold on,  
 stairs(hist_minus_dist_e3./sumE14dist_minus,minus_pos_xp,'Color',dkRed,'LineWidth',2);
 hold on, 
set(gca, 'XScale', 'log');
xlim([0.0001 1]);ylim([-40 40]);
xlabel('Frequency'); ylabel('position (mm)'); 
box on,

%all_table_freq_travel_gr_all(1) = 
%plus
table_plus_prox_freq_travel_gr_all(1)= (numel(plus_pos_prox_c_gr)+numel(plus_pos_mid_c_gr)+numel(plus_pos_dist_c_gr))...
                                        /((numel(plus_pos_prox_c) + numel(plus_pos_mid_c) + numel(plus_pos_dist_c)));%+(numel(minus_pos_prox_c) + numel(minus_pos_mid_c) + numel(minus_pos_dist_c)));

table_plus_prox_freq_travel_gr_all(2)= (numel(plus_pos_prox_ko_gr)+numel(plus_pos_mid_ko_gr)+numel(plus_pos_dist_ko_gr))...
                                        /((numel(plus_pos_prox_ko) + numel(plus_pos_mid_ko) + numel(plus_pos_dist_ko)));% + (numel(minus_pos_prox_ko) + numel(minus_pos_mid_ko) + numel(minus_pos_dist_ko)));
                                    
table_plus_prox_freq_travel_gr_all(4)= (numel(plus_pos_wt1_all_gr))...
                                        /((numel(plus_pos_prox_wt1) + numel(plus_pos_mid_wt1) + numel(plus_pos_dist_wt1)));% + (numel(minus_pos_prox_wt1) + numel(minus_pos_mid_wt1) + numel(minus_pos_dist_wt1)));
                                       
table_plus_prox_freq_travel_gr_all(5)= (numel(plus_pos_wt2_all_gr))...
                                        /((numel(plus_pos_prox_wt2) + numel(plus_pos_mid_wt2) + numel(plus_pos_dist_wt2)));% + (numel(minus_pos_prox_wt2) + numel(minus_pos_mid_wt2) + numel(minus_pos_dist_wt2)));   

table_plus_prox_freq_travel_gr_all(6)= (numel(plus_pos_wt3_all_gr))...
                                        /((numel(plus_pos_prox_wt3) + numel(plus_pos_mid_wt3) + numel(plus_pos_dist_wt3)));% + (numel(minus_pos_prox_wt3) + numel(minus_pos_mid_wt3) + numel(minus_pos_dist_wt3)));                                    

table_plus_prox_freq_travel_gr_all(8)= (numel(plus_pos_ap1_all_gr))...
                                        /((numel(plus_pos_prox_ap1) + numel(plus_pos_mid_ap1) + numel(plus_pos_dist_ap1)));% + (numel(minus_pos_prox_ap1) + numel(minus_pos_mid_ap1) + numel(minus_pos_dist_ap1)));
                                       
table_plus_prox_freq_travel_gr_all(9)= (numel(plus_pos_ap2_all_gr))...
                                        /((numel(plus_pos_prox_ap2) + numel(plus_pos_mid_ap2) + numel(plus_pos_dist_ap2)));% + (numel(minus_pos_prox_ap2) + numel(minus_pos_mid_ap2) + numel(minus_pos_dist_ap2)));   

table_plus_prox_freq_travel_gr_all(10)= (numel(plus_pos_ap3_all_gr))...
                                        /((numel(plus_pos_prox_ap3) + numel(plus_pos_mid_ap3) + numel(plus_pos_dist_ap3)));% + (numel(minus_pos_prox_ap3) + numel(minus_pos_mid_ap3) + numel(minus_pos_dist_ap3)));                                    
                                    
table_plus_prox_freq_travel_gr_all(12)=  (numel(plus_pos_e1_all_gr))...
                                        /((numel(plus_pos_prox_e1) + numel(plus_pos_mid_e1) + numel(plus_pos_dist_e1)));% + (numel(minus_pos_prox_e1) + numel(minus_pos_mid_e1) + numel(minus_pos_dist_e1)));
                                       
table_plus_prox_freq_travel_gr_all(13)=  (numel(plus_pos_e2_all_gr))...
                                        /((numel(plus_pos_prox_e2) + numel(plus_pos_mid_e2) + numel(plus_pos_dist_e2)));% + (numel(minus_pos_prox_e2) + numel(minus_pos_mid_e2) + numel(minus_pos_dist_e2)));   

table_plus_prox_freq_travel_gr_all(14)=  (numel(plus_pos_e3_all_gr))...
                                        /((numel(plus_pos_prox_e3) + numel(plus_pos_mid_e3) + numel(plus_pos_dist_e3)));% + (numel(minus_pos_prox_e3) + numel(minus_pos_mid_e3) + numel(minus_pos_dist_e3)));                                    
                                    
%minus
table_minus_prox_freq_travel_gr_all(1)=  (numel(minus_pos_prox_c_gr)+numel(minus_pos_mid_c_gr)+numel(minus_pos_dist_c_gr))...
                                        /((numel(minus_pos_prox_c) + numel(minus_pos_mid_c) + numel(minus_pos_dist_c)));% + (numel(plus_pos_prox_c) + numel(plus_pos_mid_c) + numel(plus_pos_dist_c)));

table_minus_prox_freq_travel_gr_all(2)=  (numel(minus_pos_prox_ko_gr)+numel(minus_pos_mid_ko_gr)+numel(minus_pos_dist_ko_gr))...
                                        /((numel(minus_pos_prox_ko) + numel(minus_pos_mid_ko) + numel(minus_pos_dist_ko)));% + (numel(plus_pos_prox_ko) + numel(plus_pos_mid_ko) + numel(plus_pos_dist_ko)));
                                    
table_minus_prox_freq_travel_gr_all(4)=  (numel(minus_pos_wt1_all_gr))...
                                        /((numel(minus_pos_prox_wt1) + numel(minus_pos_mid_wt1) + numel(minus_pos_dist_wt1)));% + (numel(plus_pos_prox_wt1) + numel(plus_pos_mid_wt1) + numel(plus_pos_dist_wt1)));
                                       
table_minus_prox_freq_travel_gr_all(5)=  (numel(minus_pos_wt2_all_gr))...
                                        /((numel(minus_pos_prox_wt2) + numel(minus_pos_mid_wt2) + numel(minus_pos_dist_wt2)));% + (numel(plus_pos_prox_wt2) + numel(plus_pos_mid_wt2) + numel(plus_pos_dist_wt2)));   

table_minus_prox_freq_travel_gr_all(6)=  (numel(minus_pos_wt3_all_gr))...
                                        /((numel(minus_pos_prox_wt3) + numel(minus_pos_mid_wt3) + numel(minus_pos_dist_wt3)));% + (numel(plus_pos_prox_wt3) + numel(plus_pos_mid_wt3) + numel(plus_pos_dist_wt3)));                                    

table_minus_prox_freq_travel_gr_all(8)=  (numel(minus_pos_ap1_all_gr))...
                                        /((numel(minus_pos_prox_ap1) + numel(minus_pos_mid_ap1) + numel(minus_pos_dist_ap1)));% + (numel(plus_pos_prox_ap1) + numel(plus_pos_mid_ap1) + numel(plus_pos_dist_ap1)));
                                       
table_minus_prox_freq_travel_gr_all(9)=  (numel(minus_pos_ap2_all_gr))...
                                        /((numel(minus_pos_prox_ap2) + numel(minus_pos_mid_ap2) + numel(minus_pos_dist_ap2)));% + (numel(plus_pos_prox_ap2) + numel(plus_pos_mid_ap2) + numel(plus_pos_dist_ap2)));   

table_minus_prox_freq_travel_gr_all(10)= (numel(minus_pos_ap3_all_gr))...
                                        /((numel(minus_pos_prox_ap3) + numel(minus_pos_mid_ap3) + numel(minus_pos_dist_ap3)));% + (numel(plus_pos_prox_ap3) + numel(plus_pos_mid_ap3) + numel(plus_pos_dist_ap3)));                                    
                                    
table_minus_prox_freq_travel_gr_all(12)= (numel(minus_pos_e1_all_gr))...
                                        /((numel(minus_pos_prox_e1) + numel(minus_pos_mid_e1) + numel(minus_pos_dist_e1)));% + (numel(plus_pos_prox_e1) + numel(plus_pos_mid_e1) + numel(plus_pos_dist_e1)));
                                       
table_minus_prox_freq_travel_gr_all(13)= (numel(minus_pos_e2_all_gr))...
                                        /((numel(minus_pos_prox_e2) + numel(minus_pos_mid_e2) + numel(minus_pos_dist_e2)));% + (numel(plus_pos_prox_e2) + numel(plus_pos_mid_e2) + numel(plus_pos_dist_e2)));   

table_minus_prox_freq_travel_gr_all(14)= (numel(minus_pos_e3_all_gr))...
                                        /((numel(minus_pos_prox_e3) + numel(minus_pos_mid_e3) + numel(minus_pos_dist_e3)));% + (numel(plus_pos_prox_e3) + numel(plus_pos_mid_e3) + numel(plus_pos_dist_e3)));                                    
                                    
    
                                    
  %% group long range trajectories in all regions by tau intensity level for each condition                                  
                                    
                                    
                                    
 table_plus_freq_travel_gr(1)= (numel(plus_pos_prox_c_gr)+numel(plus_pos_mid_c_gr)+numel(plus_pos_dist_c_gr))   /(numel(plus_pos_prox_c) + numel(plus_pos_mid_c) +  numel(plus_pos_dist_c));
 table_plus_freq_travel_gr(2)=   (numel(plus_pos_prox_ko_gr)+numel(plus_pos_mid_ko_gr)+numel(plus_pos_dist_ko_gr))/(numel(plus_pos_prox_ko)+ numel(plus_pos_mid_ko) + numel(plus_pos_dist_ko));
 table_plus_freq_travel_gr(3)=  (numel(plus_pos_prox_wt_gr)+numel(plus_pos_mid_wt_gr)+numel(plus_pos_dist_wt_gr))/(numel(plus_pos_prox_wt)+ numel(plus_pos_mid_wt) + numel(plus_pos_dist_wt));
 table_plus_freq_travel_gr(4)=  (numel(plus_pos_prox_ap_gr)+numel(plus_pos_mid_ap_gr)+numel(plus_pos_dist_ap_gr))/(numel(plus_pos_prox_ap)+ numel(plus_pos_mid_ap) + numel(plus_pos_dist_ap));
 table_plus_freq_travel_gr(5)=  (numel(plus_pos_prox_e_gr)+numel(plus_pos_mid_e_gr)+numel(plus_pos_dist_e_gr))   /(numel(plus_pos_prox_e) + numel(plus_pos_mid_e) +  numel(plus_pos_dist_e));
 
 table_minus_freq_travel_gr(1)= (numel(minus_pos_prox_c_gr)+numel(minus_pos_mid_c_gr)+numel(minus_pos_dist_c_gr))   /(numel(minus_pos_prox_c) + numel(minus_pos_mid_c) +  numel(minus_pos_dist_c));
 table_minus_freq_travel_gr(2)=   (numel(minus_pos_prox_ko_gr)+numel(minus_pos_mid_ko_gr)+numel(minus_pos_dist_ko_gr))/(numel(minus_pos_prox_ko)+ numel(minus_pos_mid_ko) + numel(minus_pos_dist_ko));
 table_minus_freq_travel_gr(3)=  (numel(minus_pos_prox_wt_gr)+numel(minus_pos_mid_wt_gr)+numel(minus_pos_dist_wt_gr))/(numel(minus_pos_prox_wt)+ numel(minus_pos_mid_wt) + numel(minus_pos_dist_wt));
 table_minus_freq_travel_gr(4)=  (numel(minus_pos_prox_ap_gr)+numel(minus_pos_mid_ap_gr)+numel(minus_pos_dist_ap_gr))/(numel(minus_pos_prox_ap)+ numel(minus_pos_mid_ap) + numel(minus_pos_dist_ap));
 table_minus_freq_travel_gr(5)=  (numel(minus_pos_prox_e_gr)+numel(minus_pos_mid_e_gr)+numel(minus_pos_dist_e_gr))   /(numel(minus_pos_prox_e) + numel(minus_pos_mid_e) +  numel(minus_pos_dist_e));
 
table_plus_prox_freq_travel_gr(1)= numel(plus_pos_prox_c_gr)/numel(plus_pos_prox_c);
table_plus_prox_freq_travel_gr(2)= numel(plus_pos_prox_ko_gr)/numel(plus_pos_prox_ko);

% % bin by tau int
table_plus_prox_freq_travel_gr(4)= numel(plus_pos_prox_wt1_gr)/numel(plus_pos_prox_wt);
table_plus_prox_freq_travel_gr(5)= numel(plus_pos_prox_wt2_gr)/numel(plus_pos_prox_wt);
table_plus_prox_freq_travel_gr(6)= numel(plus_pos_prox_wt3_gr)/numel(plus_pos_prox_wt);

table_plus_prox_freq_travel_gr(8)= numel(plus_pos_prox_ap1_gr)/numel(plus_pos_prox_ap);
table_plus_prox_freq_travel_gr(9)= numel(plus_pos_prox_ap2_gr)/numel(plus_pos_prox_ap);
table_plus_prox_freq_travel_gr(10)= numel(plus_pos_prox_ap3_gr)/numel(plus_pos_prox_ap);

table_plus_prox_freq_travel_gr(12)= numel(plus_pos_prox_e1_gr)/numel(plus_pos_prox_e);
table_plus_prox_freq_travel_gr(13)= numel(plus_pos_prox_e2_gr)/numel(plus_pos_prox_e);
table_plus_prox_freq_travel_gr(14)= numel(plus_pos_prox_e3_gr)/numel(plus_pos_prox_e);



table_minus_prox_freq_travel_gr(1)= numel(minus_pos_prox_c_gr)/numel(minus_pos_prox_c);
table_minus_prox_freq_travel_gr(2)= numel(minus_pos_prox_ko_gr)/numel(minus_pos_prox_ko);

% %bin by tau int
table_minus_prox_freq_travel_gr(4)= numel(minus_pos_prox_wt1_gr)/numel(minus_pos_prox_wt);
table_minus_prox_freq_travel_gr(5)= numel(minus_pos_prox_wt2_gr)/numel(minus_pos_prox_wt);
table_minus_prox_freq_travel_gr(6)= numel(minus_pos_prox_wt3_gr)/numel(minus_pos_prox_wt);

table_minus_prox_freq_travel_gr(8)= numel(minus_pos_prox_ap1_gr)/numel(minus_pos_prox_ap);
table_minus_prox_freq_travel_gr(9)= numel(minus_pos_prox_ap2_gr)/numel(minus_pos_prox_ap);
table_minus_prox_freq_travel_gr(10)= numel(minus_pos_prox_ap3_gr)/numel(minus_pos_prox_ap);

table_minus_prox_freq_travel_gr(12)= numel(minus_pos_prox_e1_gr)/numel(minus_pos_prox_e);
table_minus_prox_freq_travel_gr(13)= numel(minus_pos_prox_e2_gr)/numel(minus_pos_prox_e);
table_minus_prox_freq_travel_gr(14)= numel(minus_pos_prox_e3_gr)/numel(minus_pos_prox_e);



table_plus_mid_freq_travel_gr(1)= numel(plus_pos_mid_c_gr)/numel(plus_pos_mid_c);
table_plus_mid_freq_travel_gr(2)= numel(plus_pos_mid_ko_gr)/numel(plus_pos_mid_ko);

% %bin by tau int
 table_plus_mid_freq_travel_gr(4)= numel(plus_pos_mid_wt1_gr)/numel(plus_pos_mid_wt);
 table_plus_mid_freq_travel_gr(5)= numel(plus_pos_mid_wt2_gr)/numel(plus_pos_mid_wt);
 table_plus_mid_freq_travel_gr(6)= numel(plus_pos_mid_wt3_gr)/numel(plus_pos_mid_wt);

 table_plus_mid_freq_travel_gr(8)= numel(plus_pos_mid_ap1_gr)/numel(plus_pos_mid_ap);
 table_plus_mid_freq_travel_gr(9)= numel(plus_pos_mid_ap2_gr)/numel(plus_pos_mid_ap);
 table_plus_mid_freq_travel_gr(10)= numel(plus_pos_mid_ap3_gr)/numel(plus_pos_mid_ap);

 table_plus_mid_freq_travel_gr(12)= numel(plus_pos_mid_e1_gr)/numel(plus_pos_mid_e);
 table_plus_mid_freq_travel_gr(13)= numel(plus_pos_mid_e2_gr)/numel(plus_pos_mid_e);
 table_plus_mid_freq_travel_gr(14)= numel(plus_pos_mid_e3_gr)/numel(plus_pos_mid_e);


table_minus_mid_freq_travel_gr(1)= numel(minus_pos_mid_c_gr)/numel(minus_pos_mid_c);
table_minus_mid_freq_travel_gr(2)= numel(minus_pos_mid_ko_gr)/numel(minus_pos_mid_ko);

% %bin by tau int
table_minus_mid_freq_travel_gr(4)= numel(minus_pos_mid_wt1_gr)/numel(minus_pos_mid_wt);
table_minus_mid_freq_travel_gr(5)= numel(minus_pos_mid_wt2_gr)/numel(minus_pos_mid_wt);
table_minus_mid_freq_travel_gr(6)= numel(minus_pos_mid_wt3_gr)/numel(minus_pos_mid_wt);

table_minus_mid_freq_travel_gr(8)= numel(minus_pos_mid_ap1_gr)/numel(minus_pos_mid_ap);
table_minus_mid_freq_travel_gr(9)= numel(minus_pos_mid_ap2_gr)/numel(minus_pos_mid_ap);
table_minus_mid_freq_travel_gr(10)= numel(minus_pos_mid_ap3_gr)/numel(minus_pos_mid_ap);

table_minus_mid_freq_travel_gr(12)= numel(minus_pos_mid_e1_gr)/numel(minus_pos_mid_e);
table_minus_mid_freq_travel_gr(13)= numel(minus_pos_mid_e2_gr)/numel(minus_pos_mid_e);
table_minus_mid_freq_travel_gr(14)= numel(minus_pos_mid_e3_gr)/numel(minus_pos_mid_e);


table_plus_dist_freq_travel_gr(1)= numel(plus_pos_dist_c_gr)/numel(plus_pos_dist_c);
table_plus_dist_freq_travel_gr(2)= numel(plus_pos_dist_ko_gr)/numel(plus_pos_dist_ko);

% %bin by tau int
 table_plus_dist_freq_travel_gr(4)= numel(plus_pos_dist_wt1_gr)/numel(plus_pos_dist_wt);
 table_plus_dist_freq_travel_gr(5)= numel(plus_pos_dist_wt2_gr)/numel(plus_pos_dist_wt);
 table_plus_dist_freq_travel_gr(6)= numel(plus_pos_dist_wt3_gr)/numel(plus_pos_dist_wt);
 
 table_plus_dist_freq_travel_gr(8)= numel(plus_pos_dist_ap1_gr)/numel(plus_pos_dist_ap);
 table_plus_dist_freq_travel_gr(9)= numel(plus_pos_dist_ap2_gr)/numel(plus_pos_dist_ap);
 table_plus_dist_freq_travel_gr(10)= numel(plus_pos_dist_ap3_gr)/numel(plus_pos_dist_ap);

 table_plus_dist_freq_travel_gr(12)= numel(plus_pos_dist_e1_gr)/numel(plus_pos_dist_e);
 table_plus_dist_freq_travel_gr(13)= numel(plus_pos_dist_e2_gr)/numel(plus_pos_dist_e);
 table_plus_dist_freq_travel_gr(14)= numel(plus_pos_dist_e3_gr)/numel(plus_pos_dist_e);


table_minus_dist_freq_travel_gr(1)= numel(minus_pos_dist_c_gr)/numel(minus_pos_dist_c);
table_minus_dist_freq_travel_gr(2)= numel(minus_pos_dist_ko_gr)/numel(minus_pos_dist_ko);

% %bin by tau int
table_minus_dist_freq_travel_gr(4)= numel(minus_pos_dist_wt1_gr)/numel(minus_pos_dist_wt);
table_minus_dist_freq_travel_gr(5)= numel(minus_pos_dist_wt2_gr)/numel(minus_pos_dist_wt);
table_minus_dist_freq_travel_gr(6)= numel(minus_pos_dist_wt3_gr)/numel(minus_pos_dist_wt);

table_minus_dist_freq_travel_gr(8)= numel(minus_pos_dist_ap1_gr)/numel(minus_pos_dist_ap);
table_minus_dist_freq_travel_gr(9)= numel(minus_pos_dist_ap2_gr)/numel(minus_pos_dist_ap);
table_minus_dist_freq_travel_gr(10)= numel(minus_pos_dist_ap3_gr)/numel(minus_pos_dist_ap);

table_minus_dist_freq_travel_gr(12)= numel(minus_pos_dist_e1_gr)/numel(minus_pos_dist_e);
table_minus_dist_freq_travel_gr(13)= numel(minus_pos_dist_e2_gr)/numel(minus_pos_dist_e);
table_minus_dist_freq_travel_gr(14)= numel(minus_pos_dist_e3_gr)/numel(minus_pos_dist_e);

figure('Name','ALL Freq Travel Plots above lower tau exp thresh','NumberTitle','off'), 
 subplot(3,1,1), hold on,
plot(table_plus_freq_travel_gr, 'bo');
plot(-table_minus_freq_travel_gr, 'ro');
xlim([0 6]); ylim([-0.15 0.15]); box on,


figure('Name','Freq Travel Plots by region','NumberTitle','off'), 
 subplot(3,1,1), hold on,
plot(table_plus_prox_freq_travel_gr, 'bo');
plot(-table_minus_prox_freq_travel_gr, 'ro');
xlim([0 15]); ylim([-0.15 0.15]); box on, xlabel('prox');

subplot(3,1,2), hold on,
plot(table_plus_mid_freq_travel_gr, 'bo');
plot(-table_minus_mid_freq_travel_gr, 'ro');
xlim([0 15]); ylim([-0.15 0.15]); box on, xlabel('mid');

subplot(3,1,3), hold on,
plot(table_plus_dist_freq_travel_gr, 'bo');
plot(-table_minus_dist_freq_travel_gr, 'ro');
xlim([0 15]); ylim([-0.15 0.15]); box on,xlabel('dist');


figure('Name','Freq Travel Plots all, low, med, high tau exp','NumberTitle','off'), 
 subplot(3,1,1), hold on,
plot(table_plus_prox_freq_travel_gr_all, 'bo');
plot(-table_minus_prox_freq_travel_gr_all, 'ro');
xlim([0 15]); ylim([-0.15 0.15]); box on,




 toc
 %% Save Data   
    if save_file == 1
      
  else 
      display('did not save');
    end       



