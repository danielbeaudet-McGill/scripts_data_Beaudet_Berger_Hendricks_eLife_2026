%% Analysis of all tracks for multiple conditions for output data from KymoButler single motor data
clear all; close all; clc; 

%  addpath('/Users/danielbeaudet/Desktop/test/');
set(0,'DefaultFigureWindowStyle','docked');
addpath('/Users/danielbeaudet/Desktop/Neuron_codes/');
% addpath('/Users/danielbeaudet/Desktop/kin2Qdot_tauphosph_motility_assay/');
% addpath('/Users/danielbeaudet/Desktop/MATLAB-Codes_My versions/breakyaxis/');
%  addpath('/Users/danielbeaudet/Desktop/Kin560_tau_kymobutler_data_V2/');
 addpath('/Volumes/ROG/Degree_of_Colocalization/');

tic
rng(3)
plot_traj= 0; % plot figures of trajectories 1 yes; 0 no%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nboot=1000;
%% Savitsky Golay smoothing parameters
span=10;    % 10 is good, 25 is good as well
pwr=1;      % 1 is good, 2 is good

Duration_limit=40;
min_lr=0.5;

window_size=5;

tau_thresh=1.09;
chos= [1,2,3,4];%,4,5]; %mock, WT, AP, E14
x=1:1:100; y=0.0:0.01:0.99;
Th_Bins=[1.09, 1.2, 1.75, 5];

procColor="#d95f02";
diffColor="#1b9e77";
statColor="#7570b3";

proxColor="#e0f3db";
midColor ="#a8ddb5";
distColor="#43a2ca";

mdGrey=[0.5 0.5 0.5];

dkBlue=[0 0.2470 0.4410];
lhtBlue=[0.3010 0.7450 0.9330];
Orng=[0.9290 0.6940 0.1250];
dkRed=[0.6350 0.0780 0.1840];

for k_choose = chos

if k_choose==1 % CTL  
    nam= 'MOCK';
%load('mock_lysate_kin1_data.mat', 'ab');
load('mock_lysate_kif1a_data.mat', 'ab');

for jh=1:numel(ab)
    ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
end
ab_mock= ab;
%clear ab;
      
  
elseif k_choose==2 % WT tau 
    nam= 'WT_tau';
 %load('WT_tau_kin1_data.mat', 'ab');
load('WT_tau_kif1a_data.mat', 'ab');
for jh=1:numel(ab)
    ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
    end
ab_wt=ab;
%clear ab;

        
elseif k_choose==3 % AP tau
    nam= 'AP_tau';
 %load('AP_tau_kin1_data.mat', 'ab');
load('AP_tau_kif1a_data.mat', 'ab');
for jh=1:numel(ab)
    ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
    end
ab_ap=ab;
%clear ab;


elseif k_choose==4 % E14 tau
    nam= 'E14_tau';
 %load('E14_tau_kin1_data.mat', 'ab');
load('E14_tau_kif1a_data.mat', 'ab');
for jh=1:numel(ab)
    ab(jh).timedisp= abs([0;ab(jh).time(1)-ab(jh).time(2:end)]);
    end
ab_e14=ab;
%clear ab;

   
end 

    num_revs=[];
    rev_rate=[];
    run=[];
    run_time=[];
   
    pause=[];
    pause_time=[];
    np_trajPos=[]; sumPosMat=[];
    hist_xkrev=[]; 

    VelInst=[];
    
    posA=[]; timA=[];
    for i=1:length(ab)
         if numel(ab(i).time) < Duration_limit && ab(i).sumPos >= min_lr || numel(ab(i).time) < Duration_limit
         posA{i}=ab(i).pos;
         timA{i}=ab(i).time;
         sumPosMat(i)=(ab(i).sumPos);
         
         pos= posA{i};
         time=timA{i};
           pos=smooth(pos,span,'sgolay',pwr);
          
          res=analyze_run_length_reversals_sm(time,pos,min_lr,0, k_choose);
         
               num_revs= [num_revs,res.num_revs];
               rev_rate=[rev_rate,res.reversal_rate];
               run=[run;res.run];
               run_time=[run_time;res.run_time];
               pause= [pause;res.pause];
               pause_time=[pause_time;res.pause_time];
         else
         end
 
             
             

    end
        
  if plot_traj==1  
% plot trajectories
minPlot=-10; maxPlot=10;
figure('Name',strcat(nam, ' Trajectories'),'NumberTitle','off')
for kd = 1:length(ab)
       if numel(ab(kd).time) < Duration_limit && ab(kd).sumPos >= min_lr || numel(ab(kd).time) < Duration_limit

        fp=plot(ab(kd).pos, ab(kd).frame, '-','linewidth',3);
        hold on,
       else
       end
end
xlabel('mock position (\mum)'), ylabel('Time (s)'), %ylim([minPlot maxPlot]); xlim([0 60]);

  else
  end
  
  clear ab
  

%% Travel distance 
xp_traj=0:0.5:20;
np_trajPos= hist(sumPosMat(sumPosMat>min_lr),xp_traj); 
 

xm_traj=-100:0.5:0;
nm_trajPos= hist(sumPosMat(sumPosMat<-min_lr),xm_traj); 


figure('Name',strcat(nam, ' Travel Distance'),'NumberTitle','off'), 
subplot(1,3,1), hold on,% histogram of ALL plus- and minus- end processive runs; freq vs. displacement (nm)
C2=bar(xp_traj,np_trajPos./sum(np_trajPos),'facealpha', 1, 'BarWidth', 0.9,'FaceColor', proxColor);
hold on,
C3=bar(xm_traj,nm_trajPos./sum(nm_trajPos),'facealpha', 1, 'BarWidth', 0.9,'FaceColor', proxColor);
hold on,
xlim([0 10]); ylim([0 0.4]);
ylabel('fraction of events'),xlabel('displacement (\mum)');
title('travel distance'); hold on,


%% Plot travel distance frequency


plus_pos_xp=0:1:40;
minus_pos_xp=-40:1:0;

if k_choose==1 %CTL
plus_pos_mock=sumPosMat(find(sumPosMat>0));
minus_pos_mock=sumPosMat(find(sumPosMat<0));
hist_plus_mock=hist(plus_pos_mock,plus_pos_xp);
hist_minus_mock=hist(minus_pos_mock,minus_pos_xp);
 

elseif k_choose==2 %WT
plus_pos_wt=sumPosMat(find(sumPosMat>0));
minus_pos_wt=sumPosMat(find(sumPosMat<0));
hist_plus_wt=hist(plus_pos_wt,plus_pos_xp);
hist_minus_wt=hist(minus_pos_wt,minus_pos_xp);


elseif k_choose==3 %AP
plus_pos_ap=sumPosMat(find(sumPosMat>0));
minus_pos_ap=sumPosMat(find(sumPosMat<0));
hist_plus_ap=hist(plus_pos_ap,plus_pos_xp);
hist_minus_ap=hist(minus_pos_ap,minus_pos_xp);

elseif k_choose==4 %E14
plus_pos_e=sumPosMat(find(sumPosMat>0));
minus_pos_e=sumPosMat(find(sumPosMat<0));
hist_plus_e=hist(plus_pos_e,plus_pos_xp);
hist_minus_e=hist(minus_pos_e,minus_pos_xp);
else
end
  

if k_choose==1
    rev_rate_mock=rev_rate;
elseif k_choose==2
    rev_rate_wt=rev_rate;
elseif k_choose==3
    rev_rate_ap=rev_rate;            
elseif k_choose==4
    rev_rate_e=rev_rate;
 
end


%% Processive runs

  
proc_plus_run=[];proc_plus_time=[];proc_minus_run=[];proc_minus_time=[];


bmu_total_time_proc=[];


proc_plus_run=run(find(run>min_lr));
proc_plus_time=run_time(find(run>min_lr));
proc_minus_run=run(find(run<-min_lr));
proc_minus_time=run_time(find(run<-min_lr));



proc_plus_vel= proc_plus_run./proc_plus_time;
proc_minus_vel= proc_minus_run./proc_minus_time;


[bci_plus_proc_vel,bsums_plus_proc_vel]=bootci(nboot,{@mean, proc_plus_vel},'alpha',.05,'type','per');
    bci_plus_proc_vel=bci_plus_proc_vel';
    bmu_plus_proc_vel = mean(bsums_plus_proc_vel);
    
[bci_minus_proc_vel,bsums_minus_proc_vel]=bootci(nboot,{@mean, proc_minus_vel},'alpha',.05,'type','per');
    bci_minus_proc_vel=bci_minus_proc_vel';
    bmu_minus_proc_vel = mean(bsums_minus_proc_vel);

    
    
%total_time_proc_prox=sum(proc_plus_time_prox)+sum(proc_minus_time_prox);
[bci_proc,bsums_proc]=bootci(nboot,{@sum, [proc_plus_time]},'alpha',.05,'type','per');
    bci_proc=bci_proc';
    bmu_total_time_proc = mean(bsums_proc);

fraction_plus_proc=sum(proc_plus_time)./bmu_total_time_proc;
fraction_minus_proc=sum(proc_minus_time)./bmu_total_time_proc;


% bootstrap sums/ total time


[bci_proc_plus,bsums_proc_plus] = bootci(nboot,{@sum,proc_plus_time},'alpha',.05,'type','per');
bci_proc_plus=bci_proc_plus./bmu_total_time_proc';
bmu_proc_plus = mean(bsums_proc_plus./bmu_total_time_proc);

[bci_proc_minus,bsums_proc_minus] = bootci(nboot,{@sum,proc_minus_time},'alpha',.05,'type','per');
bci_proc_minus=bci_proc_minus./bmu_total_time_proc';
bmu_proc_minus = mean(bsums_proc_minus./bmu_total_time_proc);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if k_choose==1
    proc_plus_run_mock=proc_plus_run;  
    proc_minus_run_mock=proc_minus_run;
        
elseif k_choose==2
    proc_plus_run_wt=proc_plus_run;  
    proc_minus_run_wt=proc_minus_run;
    
elseif k_choose==3
    proc_plus_run_ap=proc_plus_run;  
    proc_minus_run_ap=proc_minus_run;  
    
elseif k_choose==4
   proc_plus_run_e=proc_plus_run;  
    proc_minus_run_e=proc_minus_run; 

end


if k_choose==1
    proc_plus_vel_mock=proc_plus_vel;  
    proc_minus_vel_mock=proc_minus_vel;
       
elseif k_choose==2
    proc_plus_vel_wt=proc_plus_vel;  
    proc_minus_vel_wt=proc_minus_vel;
    
elseif k_choose==3
    proc_plus_vel_ap=proc_plus_vel;  
    proc_minus_vel_ap=proc_minus_vel;
    
elseif k_choose==4
    proc_plus_vel_e=proc_plus_vel;  
    proc_minus_vel_e=proc_minus_vel;
    
end


if k_choose==1
proc_plus_time_mock = proc_plus_time;
proc_minus_time_mock= proc_minus_time;


elseif k_choose==2
proc_plus_time_wt = proc_plus_time;
proc_minus_time_wt= proc_minus_time;


elseif k_choose==3
proc_plus_time_ap = proc_plus_time;
proc_minus_time_ap= proc_minus_time;

elseif k_choose==4
proc_plus_time_e = proc_plus_time;
proc_minus_time_e= proc_minus_time;

end


[bci_procR_plus,bsums_procR_plus] = bootci(nboot,{@mean,proc_plus_run},'alpha',.05,'type','per');
bci_procR_plus=bci_procR_plus';
bmu_procR_plus = mean(bsums_procR_plus);

[bci_procR_minus,bsums_procR_minus] = bootci(nboot,{@mean,proc_minus_run},'alpha',.05,'type','per');
bci_procR_minus=bci_procR_minus';
bmu_procR_minus = mean(bsums_procR_minus);



  bmu_total_time_pause=[];
 


%   total_time_stat_prox=sum(stat_time_prox);
  [bci_pause_time,bsums_pause_time] = bootci(nboot,{@sum,pause_time},'alpha',.05,'type','per');
   bci_pause_time=bci_pause_time';
    bmu_total_time_pause = mean(bsums_pause_time);


 total_time= sum([bmu_total_time_proc,  bmu_total_time_pause], "all");
 


 if k_choose == 1
     total_time_mock = total_time;
     total_time_proc_mock = bmu_total_time_proc/total_time; 
       bci_total_time_proc_mock=bci_proc/total_time;
     total_time_pause_mock = bmu_total_time_pause/total_time;
       bci_total_time_pause_mock=bci_pause_time/total_time;
                 
    
       bsums_proc_plus_mock = bsums_proc_plus./bmu_total_time_proc;
       bsums_proc_minus_mock= bsums_proc_minus./bmu_total_time_proc;
      
       
       
       bsums_proc_mock = bsums_proc./total_time;
       bsums_pause_mock = bsums_pause_time./total_time;
       
     
 elseif k_choose == 2
        total_time_wt = total_time;
     total_time_proc_wt = bmu_total_time_proc/total_time; 
       bci_total_time_proc_wt=bci_proc/total_time;
     total_time_pause_wt = bmu_total_time_pause/total_time;
       bci_total_time_pause_wt =bci_pause_time/total_time;
                 
    
       bsums_proc_plus_wt = bsums_proc_plus./bmu_total_time_proc;
       bsums_proc_minus_wt= bsums_proc_minus./bmu_total_time_proc;       
       
       bsums_proc_wt = bsums_proc./total_time;
       bsums_pause_wt = bsums_pause_time./total_time;
     
 elseif k_choose == 3
                 total_time_ap = total_time;
     total_time_proc_ap = bmu_total_time_proc/total_time; 
       bci_total_time_proc_ap=bci_proc/total_time;
     total_time_pause_ap = bmu_total_time_pause/total_time;
       bci_total_time_pause_ap =bci_pause_time/total_time;
                 
    
       bsums_proc_plus_ap = bsums_proc_plus./bmu_total_time_proc;
       bsums_proc_minus_ap= bsums_proc_minus./bmu_total_time_proc;
       
       
       bsums_proc_ap = bsums_proc./total_time;
       bsums_pause_ap = bsums_pause_time./total_time;
     
       
 elseif k_choose == 4
                   total_time_e = total_time;
     total_time_proc_e = bmu_total_time_proc/total_time; 
       bci_total_time_proc_e=bci_proc/total_time;
     total_time_pause_e = bmu_total_time_pause/total_time;
       bci_total_time_pause_e =bci_pause_time/total_time;
                 
    
       bsums_proc_plus_e = bsums_proc_plus./bmu_total_time_proc;
       bsums_proc_minus_e= bsums_proc_minus./bmu_total_time_proc;
       
       
       bsums_proc_e = bsums_proc./total_time;
       bsums_pause_e = bsums_pause_time./total_time;
     
     
 end
     

figure('Name',strcat(nam, ' Total time'),'NumberTitle','off'), 
subplot(1,3,1), hold on,
b1=bar(2, bmu_total_time_proc/total_time,'BarWidth',0.5,'Facealpha',1, 'FaceColor', procColor);
b1=bar(3, bmu_total_time_pause/total_time,'BarWidth',0.5,'Facealpha',1, 'FaceColor', statColor);
  xlim([0 4]); ylim([0 0.9]);
 ylabel('fraction of time' ); 

 
 
%% Processive Run lengths  
Rlp_c =[]; np_proc_run_plus=[]; np_proc_run_fit=[]; Rl_plus=[];
xp_run=0.75:0.250:7;% kin1-7 kin3- 15;
np_proc_run_plus= hist(proc_plus_run,xp_run); 
xp_fit=0.75:0.250:7;%15;
np_proc_run_fit= hist(proc_plus_run,xp_fit); 

xm_run=-60:0.5:0;
np_proc_run_minus= -hist(proc_minus_run,xm_run);   

Rl_plus=(np_proc_run_plus./sum(np_proc_run_plus));

 [Rlp_c,gof_Rlp_c, op1]=fit(xp_run',Rl_plus','exp1');

 if k_choose==1
    Rlp_plus_mock=Rlp_c;
    np_proc_run_fit_mock=np_proc_run_fit;
    np_proc_run_plus_mock=np_proc_run_plus;
elseif k_choose==2
    Rlp_plus_WT=Rlp_c;
    np_proc_run_fit_WT=np_proc_run_fit;
    np_proc_run_plus_WT=np_proc_run_plus;
elseif k_choose==3
    Rlp_plus_AP=Rlp_c;
    np_proc_run_fit_AP=np_proc_run_fit;
    np_proc_run_plus_AP=np_proc_run_plus;
elseif k_choose==4
    Rlp_plus_E14=Rlp_c;
    np_proc_run_fit_E14=np_proc_run_fit;
    np_proc_run_plus_E14=np_proc_run_plus;
 end

 figure('Name',strcat(nam, ' Proc RL'),'NumberTitle','off'), 
subplot(1,3,1), hold on,% histogram of ALL plus- and minus- end processive runs; freq vs. displacement (nm)
c1=bar(xp_run,np_proc_run_plus./sum(np_proc_run_plus),'facealpha', 1, 'BarWidth', 0.9, 'FaceColor', proxColor);
hold on,
plot(Rlp_c,[xp_fit]',[(np_proc_run_fit./sum(np_proc_run_fit))]');
hold on,

xlim([0 8]); ylim([0 0.35]); % for kin1
%xlim([0 16]); ylim([0 0.25]); % for kin3

ylabel(["fraction of events"]);
xlabel('displacement (\mum)');
title('run lengths');

 %% Processive velocities
velp_c =[]; np_proc_vel_plus=[]; np_proc_vel_fit=[]; Vel_plus=[];
xp_vel=0.0:0.250:3;% kin1-7 kin3- 15;
np_proc_vel_plus= hist(proc_plus_vel,xp_vel); 
xp_fit_vel=0.0:0.250:3;%15;
np_proc_vel_fit= hist(proc_plus_vel,xp_fit_vel); 


vel_plus=(np_proc_vel_plus./sum(np_proc_vel_plus));

 [velp_c,gof_velp_c, op1]=fit(xp_vel',vel_plus','exp1');

 if k_choose==1
    velp_plus_mock=velp_c;
    np_proc_vel_fit_mock=np_proc_vel_fit;
    np_proc_vel_plus_mock=np_proc_vel_plus;
elseif k_choose==2
    velp_plus_WT=velp_c;
    np_proc_vel_fit_WT=np_proc_vel_fit;
    np_proc_vel_plus_WT=np_proc_vel_plus;
elseif k_choose==3
    velp_plus_AP=velp_c;
    np_proc_vel_fit_AP=np_proc_vel_fit;
    np_proc_vel_plus_AP=np_proc_vel_plus;
elseif k_choose==4
    velp_plus_E14=velp_c;
    np_proc_vel_fit_E14=np_proc_vel_fit;
    np_proc_vel_plus_E14=np_proc_vel_plus;
 end

 figure('Name',strcat(nam, ' Proc Velocities'),'NumberTitle','off'), 
subplot(1,3,1), hold on,% histogram of ALL plus- and minus- end processive runs; freq vs. displacement (nm)
c1=bar(xp_vel,np_proc_vel_plus./sum(np_proc_vel_plus),'facealpha', 1, 'BarWidth', 0.9, 'FaceColor', proxColor);
hold on,

%xlim([0 8]); ylim([0 0.35]); % for kin1
xlim([0 3]); ylim([0 0.5]); % for kin3

ylabel(["fraction of events"]);
xlabel('velocity (um/s)');
title('velocities');


 
 %% Processive dwell time

 xp_dwtime=0.5:0.250:7.5;%15;
  clear dwtime_p_c np_proc_dwtime_plus np_proc_dwtime_fit
np_proc_dwtime_plus= hist(proc_plus_time,xp_dwtime); 
xp_fit_dwtime=  0.5:0.25:7.5;%15;
np_proc_dwtime_fit= hist(proc_plus_time,xp_fit_dwtime); 

dwtime_plus=(np_proc_dwtime_plus./sum(np_proc_dwtime_plus));

 [dwtime_p_c,gof_dwtime_p_c, op1]=fit(xp_dwtime',dwtime_plus','exp1');

 if k_choose==1
    dwtime_p_plus_mock=dwtime_p_c;
    np_proc_dwtime_fit_mock=np_proc_dwtime_fit;
    np_proc_dwtime_plus_mock=np_proc_dwtime_plus;
elseif k_choose==2
    dwtime_p_plus_WT=dwtime_p_c;
    np_proc_dwtime_fit_WT=np_proc_dwtime_fit;
    np_proc_dwtime_plus_WT=np_proc_dwtime_plus;
elseif k_choose==3
    dwtime_p_plus_AP=dwtime_p_c;
    np_proc_dwtime_fit_AP=np_proc_dwtime_fit;
    np_proc_dwtime_plus_AP=np_proc_dwtime_plus;
elseif k_choose==4
    dwtime_p_plus_E14=dwtime_p_c;
    np_proc_dwtime_fit_E14=np_proc_dwtime_fit;
    np_proc_dwtime_plus_E14=np_proc_dwtime_plus;
 end

figure('Name',strcat(nam, ' Proc dwell time'),'NumberTitle','off'), 
subplot(1,3,1), hold on,% histogram of ALL plus- and minus- end processive runs; freq vs. displacement (nm)
c1=bar(xp_dwtime,np_proc_dwtime_plus./sum(np_proc_dwtime_plus),'facealpha', 1, 'BarWidth', 0.9, 'FaceColor', proxColor);
hold on,
plot(dwtime_p_c,[xp_fit_dwtime]',[(np_proc_dwtime_fit./sum(np_proc_dwtime_fit))]');
hold on,

xlim([0 8]); ylim([0 0.3]);
ylabel(["fraction of events"]);
xlabel('time (s)');
title('dwell times');





%% P-values Run Lengths
if k_choose==1
bmu_plus_RL_mock   = bmu_procR_plus;
bmu_minus_RL_mock  = bmu_procR_minus;
bsums_plus_RL_mock = bsums_procR_plus;
bsums_minus_RL_mock= bsums_procR_minus;



elseif k_choose==2
bmu_plus_RL_wt   = bmu_procR_plus;
bmu_minus_RL_wt  = bmu_procR_minus;
bsums_plus_RL_wt = bsums_procR_plus;
bsums_minus_RL_wt= bsums_procR_minus;

elseif k_choose==3
bmu_plus_RL_ap   = bmu_procR_plus;
bmu_minus_RL_ap  = bmu_procR_minus;
bsums_plus_RL_ap = bsums_procR_plus;
bsums_minus_RL_ap= bsums_procR_minus;

elseif k_choose==4
bmu_plus_RL_e   = bmu_procR_plus;
bmu_minus_RL_e  = bmu_procR_minus;
bsums_plus_RL_e = bsums_procR_plus;
bsums_minus_RL_e= bsums_procR_minus;

end


%% P-values Velocity
if k_choose==1
bmu_plus_vel_mock   = bmu_plus_proc_vel;
bmu_minus_vel_mock  = bmu_minus_proc_vel;
bsums_plus_vel_mock = bsums_plus_proc_vel;
bsums_minus_vel_mock= bsums_minus_proc_vel;


elseif k_choose==2
bmu_plus_vel_wt   = bmu_plus_proc_vel;
bmu_minus_vel_wt  = bmu_minus_proc_vel;
bsums_plus_vel_wt = bsums_plus_proc_vel;
bsums_minus_vel_wt= bsums_minus_proc_vel;

elseif k_choose==3
bmu_plus_vel_ap   = bmu_plus_proc_vel;
bmu_minus_vel_ap  = bmu_minus_proc_vel;
bsums_plus_vel_ap = bsums_plus_proc_vel;
bsums_minus_vel_ap= bsums_minus_proc_vel;

elseif k_choose==4
bmu_plus_vel_e   = bmu_plus_proc_vel;
bmu_minus_vel_e  = bmu_minus_proc_vel;
bsums_plus_vel_e = bsums_plus_proc_vel;
bsums_minus_vel_e= bsums_minus_proc_vel;
end

end


figure('Name',strcat(' Proc RL ALL '),'NumberTitle','off'), hold on,
subplot(1,3,1), hold on,% histogram of ALL plus- and minus- end processive runs; freq vs. displacement (nm)
bar(xp_run,np_proc_run_plus_mock./sum(np_proc_run_plus_mock),'facealpha', 0.25, 'BarWidth', 0.9, 'FaceColor', 'y');
bar(xp_run,np_proc_run_plus_WT./sum(np_proc_run_plus_WT),'facealpha', 0.25, 'BarWidth', 0.9, 'FaceColor', 'r');
bar(xp_run,np_proc_run_plus_AP./sum(np_proc_run_plus_AP),'facealpha', 0.25, 'BarWidth', 0.9, 'FaceColor', 'g');
bar(xp_run,np_proc_run_plus_E14./sum(np_proc_run_plus_E14),'facealpha', 0.25, 'BarWidth', 0.9, 'FaceColor', 'b');

hold on,
c1=plot(Rlp_plus_mock,[xp_fit]',[(np_proc_run_fit_mock./sum(np_proc_run_fit_mock))]', 'y-');
c2=plot(Rlp_plus_WT,[xp_fit]',[(np_proc_run_fit_WT./sum(np_proc_run_fit_WT))]', 'r-');
c3=plot(Rlp_plus_AP,[xp_fit]',[(np_proc_run_fit_AP./sum(np_proc_run_fit_AP))]', 'g-');
c4=plot(Rlp_plus_E14,[xp_fit]',[(np_proc_run_fit_E14./sum(np_proc_run_fit_E14))]', 'b-');

set([c1(2)],'color','k');
set([c2(2)],'color','r');
set([c3(2)],'color','g');
set([c4(2)],'color','b');


hold on,

xlim([0 8]); ylim([0 0.35]);
ylabel(["fraction of events"]);
xlabel('displacement (\mum)');
title('run lengths');







%% P value RL
%mock vs wt
p_val_mock_wt_plus_RL= numel(find((abs(bsums_plus_RL_mock) - abs(bsums_plus_RL_wt)) <= 0))/nboot;%(bmu_plus_RL_prox_ctl-bmu_plus_RL_prox_ko)))/ nboot;
p_val_mock_wt_plus_vel = bootstrap_pvalue(bsums_plus_vel_wt, bsums_plus_vel_mock);
%mock vs ap
p_val_mock_ap_plus_RL= numel(find((abs(bsums_plus_RL_mock) - abs(bsums_plus_RL_ap)) <= 0))/nboot;%(bmu_plus_RL_prox_ctl-bmu_plus_RL_prox_ko)))/ nboot;
p_val_mock_ap_plus_vel = bootstrap_pvalue(bsums_plus_vel_ap, bsums_plus_vel_mock);

%mock vs e14
p_val_mock_e_plus_RL= numel(find((abs(bsums_plus_RL_mock) - abs(bsums_plus_RL_e)) <= 0))/nboot;%(bmu_plus_RL_prox_ctl-bmu_plus_RL_prox_ko)))/ nboot;
p_val_mock_e_plus_vel = bootstrap_pvalue(bsums_plus_vel_e, bsums_plus_vel_mock);

% wt vs ap
p_val_wt_ap_plus_RL= numel(find((abs(bsums_plus_RL_wt) - abs(bsums_plus_RL_ap)) <= 0))/nboot;%(bmu_plus_RL_prox_ctl-bmu_plus_RL_prox_ko)))/ nboot;
p_val_wt_ap_plus_vel = bootstrap_pvalue(bsums_plus_vel_wt, bsums_plus_vel_ap);


%wt vs e14
p_val_wt_e14_plus_RL= numel(find((bsums_plus_RL_wt - bsums_plus_RL_e) >= 0))/nboot;%(bmu_plus_RL_prox_ctl-bmu_plus_RL_prox_ko)))/ nboot;
p_val_wt_e14_plus_vel = bootstrap_pvalue(bsums_plus_vel_wt, bsums_plus_vel_e);

% ap vs e14
p_val_ap_e14_plus_RL= numel(find((abs(bsums_plus_RL_ap) - abs(bsums_plus_RL_e)) >= 0))/nboot;%(bmu_plus_RL_prox_ctl-bmu_plus_RL_prox_ko)))/ nboot;
p_val_ap_e14_plus_vel = bootstrap_pvalue(bsums_plus_vel_ap, bsums_plus_vel_e);


p_val_wt_e14_btFunc = bootstrap_pvalue(bsums_plus_RL_wt, bsums_plus_RL_e);
p_val_wt_ap_btFunc = bootstrap_pvalue(bsums_plus_RL_ap, bsums_plus_RL_wt);
p_val_ap_e14_btFunc = bootstrap_pvalue(bsums_plus_RL_ap, bsums_plus_RL_e);


%% P value total time
       
%mock vs wt
p_val_mock_wt_time_proc= numel(find((abs(bsums_proc_mock) - abs(bsums_proc_wt)) <= 0))/nboot;%(bmu_plus_RL_prox_ctl-bmu_plus_RL_prox_ko)))/ nboot;
p_val_mock_wt_time_pause= numel(find((abs(bsums_pause_mock) - abs(bsums_pause_wt)) >= 0))/nboot;%(bmu_plus_RL_prox_ctl-bmu_plus_RL_prox_ko)))/ nboot;

%mock vs ap
p_val_mock_ap_time_proc= numel(find((abs(bsums_proc_mock) - abs(bsums_proc_ap))  <= 0))/nboot;%(bmu_plus_RL_prox_ctl-bmu_plus_RL_prox_ko)))/ nboot;
p_val_mock_ap_time_pause= numel(find((abs(bsums_pause_mock) - abs(bsums_pause_ap)) >= 0))/nboot;%(bmu_plus_RL_prox_ctl-bmu_plus_RL_prox_ko)))/ nboot;

%mock vs e14
p_val_mock_e_time_proc= numel(find((abs(bsums_proc_mock) - abs(bsums_proc_e)) <= 0))/nboot;%(bmu_plus_RL_prox_ctl-bmu_plus_RL_prox_ko)))/ nboot;
p_val_mock_e_time_pause= numel(find((abs(bsums_pause_mock) - abs(bsums_pause_e)) >= 0))/nboot;%(bmu_plus_RL_prox_ctl-bmu_plus_RL_prox_ko)))/ nboot;

% wt vs ap
p_val_wt_ap_time_proc= numel(find((abs(bsums_proc_wt) - abs(bsums_proc_ap)) <= 0))/nboot;%(bmu_plus_RL_prox_ctl-bmu_plus_RL_prox_ko)))/ nboot;
p_val_wt_ap_time_pause= numel(find((abs(bsums_pause_wt) - abs(bsums_pause_ap)) >= 0))/nboot;%(bmu_plus_RL_prox_ctl-bmu_plus_RL_prox_ko)))/ nboot;

%wt vs e14
p_val_wt_e14_time_proc= numel(find((abs(bsums_proc_wt) - abs(bsums_proc_e)) >= 0))/nboot;%(bmu_plus_RL_prox_ctl-bmu_plus_RL_prox_ko)))/ nboot;
p_val_wt_e14_time_pause= numel(find((abs(bsums_pause_wt) - abs(bsums_pause_e)) <= 0))/nboot;%(bmu_plus_RL_prox_ctl-bmu_plus_RL_prox_ko)))/ nboot;

%ap vs e14
p_val_ap_e14_time_proc= numel(find((abs(bsums_proc_ap) - abs(bsums_proc_e)) >= 0))/nboot;%(bmu_plus_RL_prox_ctl-bmu_plus_RL_prox_ko)))/ nboot;
p_val_ap_e14_time_pause= numel(find((abs(bsums_pause_ap) - abs(bsums_pause_e)) <= 0))/nboot;%(bmu_plus_RL_prox_ctl-bmu_plus_RL_prox_ko)))/ nboot;


 x=[1 2 3 4];
 y=[total_time_proc_mock total_time_pause_mock;...
     total_time_proc_wt total_time_pause_wt;...
     total_time_proc_ap total_time_pause_ap;...
     total_time_proc_e total_time_pause_e];
 
 y2=[total_time_proc_mock  total_time_pause_mock;...
      total_time_proc_wt  total_time_pause_wt;...
      total_time_proc_ap  total_time_pause_ap;...
      total_time_proc_e  total_time_pause_e];
 
err_L= [bci_total_time_proc_mock(1)-total_time_proc_mock, ...
    bci_total_time_pause_mock(1)-total_time_pause_mock; ...
    bci_total_time_proc_wt(1)-total_time_proc_wt, ...
    bci_total_time_pause_wt(1)-total_time_pause_wt; ...
    bci_total_time_proc_ap(1)-total_time_proc_ap, ...
    bci_total_time_pause_ap(1)-total_time_pause_ap; ...
    bci_total_time_proc_e(1)-total_time_proc_e, ...
    bci_total_time_pause_e(1)-total_time_pause_e];

err_L2= [bci_total_time_proc_mock(1)-total_time_proc_mock, ...
    bci_total_time_pause_mock(1)-total_time_pause_mock; ...      
    bci_total_time_proc_wt(1)-total_time_proc_wt, ...
    bci_total_time_pause_wt(1)-total_time_pause_wt; ... 
    bci_total_time_proc_ap(1)-total_time_proc_ap, ...
    bci_total_time_pause_ap(1)-total_time_pause_ap; ...
    bci_total_time_proc_e(1)-total_time_proc_e, ...
    bci_total_time_pause_e(1)-total_time_pause_e];
    
    err_U= [  bci_total_time_proc_mock(2)-total_time_proc_mock,...
    bci_total_time_pause_mock(2)-total_time_pause_mock;...   
    bci_total_time_proc_wt(2)-total_time_proc_wt,... 
    bci_total_time_pause_wt(2)-total_time_pause_wt;...
    bci_total_time_proc_ap(2)-total_time_proc_ap,...
    bci_total_time_pause_ap(2)-total_time_pause_ap;...
    bci_total_time_proc_e(2)-total_time_proc_e,...
    bci_total_time_pause_e(2)-total_time_pause_e];


err_U2= [bci_total_time_proc_mock(2)-total_time_proc_mock,...
    bci_total_time_pause_mock(2)-total_time_pause_mock;...
    bci_total_time_proc_wt(2)-total_time_proc_wt,...
    bci_total_time_pause_wt(2)-total_time_pause_wt;...
    bci_total_time_proc_ap(2)-total_time_proc_ap,...
    bci_total_time_pause_ap(2)-total_time_pause_ap;...
    bci_total_time_proc_e(2)-total_time_proc_e,...
    bci_total_time_pause_e(2)-total_time_pause_e];
    
 x2=[1 2 3 4; 1 2 3 4]'; xneg=zeros(size(x2));xpos=zeros(size(x2));
figure('Name','Fraction of total time stacked V2 ','NumberTitle','off'), 
subplot(2,2,1), % all conditions proximal
b=bar(x,y2,"stacked",'BarWidth', 0.8); hold on,
 errorbar(x2,cumsum(y2')', err_L2,err_U2,xneg,xpos,'.k');
hold on,
b(1).FaceColor = procColor; b(2).FaceColor = statColor;
ylim([0.0 1.2]); xlim([0 5]);
ylabel('fraction of time'); 
xticks([1 2 3 4]);
xticklabels({'CTL','WT', 'AP', 'E14'});



    
   
[bci_procR_plus_mock,bsums_procR_plus_mock] = bootci(nboot,{@mean,proc_plus_run_mock},'alpha',.05,'type','per');
bci_procR_plus_mock=bci_procR_plus_mock';
bmu_procR_plus_mock = mean(bsums_procR_plus_mock);

[bci_procR_minus_mock,bsums_procR_minus_mock] = bootci(nboot,{@mean,proc_minus_run_mock},'alpha',.05,'type','per');
bci_procR_minus_mock=bci_procR_minus_mock';
bmu_procR_minus_mock = mean(bsums_procR_minus_mock);


[bci_procR_plus_wt,bsums_procR_plus_wt] = bootci(nboot,{@mean,proc_plus_run_wt},'alpha',.05,'type','per');
bci_procR_plus_wt=bci_procR_plus_wt';
bmu_procR_plus_wt = mean(bsums_procR_plus_wt);

[bci_procR_minus_wt,bsums_procR_minus_wt] = bootci(nboot,{@mean,proc_minus_run_wt},'alpha',.05,'type','per');
bci_procR_minus_wt=bci_procR_minus_wt';
bmu_procR_minus_wt = mean(bsums_procR_minus_wt);


[bci_procR_plus_ap,bsums_procR_plus_ap] = bootci(nboot,{@mean,proc_plus_run_ap},'alpha',.05,'type','per');
bci_procR_plus_ap=bci_procR_plus_ap';
bmu_procR_plus_ap = mean(bsums_procR_plus_ap);

[bci_procR_minus_ap,bsums_procR_minus_ap] = bootci(nboot,{@mean,proc_minus_run_ap},'alpha',.05,'type','per');
bci_procR_minus_ap=bci_procR_minus_ap';
bmu_procR_minus_ap = mean(bsums_procR_minus_ap);


[bci_procR_plus_e,bsums_procR_plus_e] = bootci(nboot,{@mean,proc_plus_run_e},'alpha',.05,'type','per');
bci_procR_plus_e=bci_procR_plus_e';
bmu_procR_plus_e = mean(bsums_procR_plus_e);

[bci_procR_minus_e,bsums_procR_minus_e] = bootci(nboot,{@mean,proc_minus_run_e},'alpha',.05,'type','per');
bci_procR_minus_e=bci_procR_minus_e';
bmu_procR_minus_e = mean(bsums_procR_minus_e);

%% Mean RL diffusive, processive, and stationary runs
figure('Name',strcat(nam, ' Mean Run Lengths v2'),'NumberTitle','off'),

subplot(1,3,1), hold on,
b1=bar(1, bmu_procR_plus_mock,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(1,bmu_procR_plus_mock,bci_procR_plus_mock(1)-bmu_procR_plus_mock,bci_procR_plus_mock(2)-bmu_procR_plus_mock,'k','linestyle','none')';

b1=bar(2, bmu_procR_plus_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(2,bmu_procR_plus_wt,bci_procR_plus_wt(1)-bmu_procR_plus_wt,bci_procR_plus_wt(2)-bmu_procR_plus_wt,'k','linestyle','none')';

b1=bar(3, bmu_procR_plus_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(3,bmu_procR_plus_ap,bci_procR_plus_ap(1)-bmu_procR_plus_ap,bci_procR_plus_ap(2)-bmu_procR_plus_ap,'k','linestyle','none')';

b1=bar(4, bmu_procR_plus_e,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(4,bmu_procR_plus_e,bci_procR_plus_e(1)-bmu_procR_plus_e,bci_procR_plus_e(2)-bmu_procR_plus_e,'k','linestyle','none')';
 ylim([0 4]);
 ylabel('mean run length (um)'); xlabel('proximal');
xticks([1,2,3,4]); set(gca,'xticklabel',{'mock','WT','AP','E14'});



[bci_vel_plus_mock,bsums_vel_plus_mock] = bootci(nboot,{@mean,proc_plus_vel_mock},'alpha',.05,'type','per');
bci_vel_plus_mock=bci_vel_plus_mock';
bmu_vel_plus_mock = mean(bsums_vel_plus_mock);


[bci_vel_plus_wt,bsums_vel_plus_wt] = bootci(nboot,{@mean,proc_plus_vel_wt},'alpha',.05,'type','per');
bci_vel_plus_wt=bci_vel_plus_wt';
bmu_vel_plus_wt = mean(bsums_vel_plus_wt);



[bci_vel_plus_ap,bsums_vel_plus_ap] = bootci(nboot,{@mean,proc_plus_vel_ap},'alpha',.05,'type','per');
bci_vel_plus_ap=bci_vel_plus_ap';
bmu_vel_plus_ap = mean(bsums_vel_plus_ap);


[bci_vel_plus_e,bsums_vel_plus_e] = bootci(nboot,{@mean,proc_plus_vel_e},'alpha',.05,'type','per');
bci_vel_plus_e=bci_vel_plus_e';
bmu_vel_plus_e = mean(bsums_vel_plus_e);



%% Mean  processive runs velocities
figure('Name',strcat(nam, ' Mean Velocities v2'),'NumberTitle','off'),

subplot(1,3,1), hold on,
b1=bar(1, bmu_vel_plus_mock,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(1,bmu_vel_plus_mock,bci_vel_plus_mock(1)-bmu_vel_plus_mock,bci_vel_plus_mock(2)-bmu_vel_plus_mock,'k','linestyle','none')';

b1=bar(2, bmu_vel_plus_wt,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(2,bmu_vel_plus_wt,bci_vel_plus_wt(1)-bmu_vel_plus_wt,bci_vel_plus_wt(2)-bmu_vel_plus_wt,'k','linestyle','none')';

b1=bar(3, bmu_vel_plus_ap,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(3,bmu_vel_plus_ap,bci_vel_plus_ap(1)-bmu_vel_plus_ap,bci_vel_plus_ap(2)-bmu_vel_plus_ap,'k','linestyle','none')';

b1=bar(4, bmu_vel_plus_e,'BarWidth',0.9,'Facealpha',1, 'FaceColor', proxColor);
e1=errorbar(4,bmu_vel_plus_e,bci_vel_plus_e(1)-bmu_vel_plus_e,bci_vel_plus_e(2)-bmu_vel_plus_e,'k','linestyle','none')';
  ylim([0 1.8]);
 ylabel('mean velocity (um/s)'); xlabel('proximal');
xticks([1,2,3,4]); set(gca,'xticklabel',{'mock','WT','AP','E14'});


toc
