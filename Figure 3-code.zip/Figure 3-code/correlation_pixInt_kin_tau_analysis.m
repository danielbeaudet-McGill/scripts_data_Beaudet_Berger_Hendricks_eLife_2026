%% Code that finds the degree of colocalization of kinesin motors and tau along microtubules

% 1) Input Kin intensity- in ImageJ, change the image stack to 8-bit,
% make a sum stack of the entire timelapse (1-595frames), then use the
% linescan ROI to make a plot profile, and save the pixel intensities as a
% .csv file.
% 2) Input Kin background intensity- do the same as step 1, except- move 
% the linescan away from the microtubule and perform another plot profile,
% save as a .csv file.
% 3) Input Tau intensity- for the 8-bit image of tau, use the same linescan
% and perform a plot intensity, it doesn not need to be for the SUM stack,
% just a single frame will do. 
% 4) Input Tau background intensity- move the linescan away from the
% microtubule and perform another plot profile, save as a .csv file.


% Beaudet, D., Hendricks Lab, January 2025

clear all, close all
set(0,'DefaultFigureWindowStyle','docked')
addpath('/Users/danielbeaudet/Desktop/MATLAB-Codes_My versions/');

 mdGrey=[0.5 0.5 0.5];

chos= [1,2,3];%,4,5]; %mock, WT, AP, E14

for choose = chos
    
if choose==1
  datdir = ('/Volumes/ROG/colocalization_data/Kin560_WTtau/');
 %datdir = ('/Volumes/ROG/colocalization_data/Kif1a_WTtau/');

 save_dir = ('/Users/danielbeaudet/Desktop/colocalization_data/');

 plotInt_tau = dir(fullfile(datdir, 'tauInt_*.csv'));
 %plotInt_tau = dir(fullfile(datdir, 'plot_Values_*.csv'));

 plotInt_BG_tau = dir(fullfile(datdir, 'BG_Plot_Values*.csv'));

 plotInt_kin = dir(fullfile(datdir, 'STD*.csv'));
  %plotInt_kin = dir(fullfile(datdir, 'SUM_*.csv'));

 plotInt_BG_kin = dir(fullfile(datdir, 'BG_SUM_kin*.csv'));
 ld=numel(plotInt_tau); 
 
 ResultsWT.tauI_bgI=[];
 ResultsWT.kinInt_corr=[];
 
 for k=1:numel(plotInt_tau)
        % reads .csv files of tau intensity and BG profiles
        coords_tauInt{k} = readmatrix(fullfile(datdir,plotInt_tau(k).name));
        coordsBGtau{k} = readmatrix(fullfile(datdir,plotInt_BG_tau(k).name));
        mean_coordsBGtau= mean(coordsBGtau{k}(:,2));
        
        % reads .csv files of kin SUM intensity and BG profiles
        coords_kin{k} = readmatrix(fullfile(datdir,plotInt_kin(k).name));
        coordsBG_kin{k} = readmatrix(fullfile(datdir,plotInt_BG_kin(k).name));
        mean_coordsBG_kin= mean(coordsBG_kin{k}(:,2));

        ResultsWT(k).tauI_bgI=(coords_tauInt{k}(:,2)-mean_coordsBGtau);
         ResultsWT(k).tauI_bgI(ResultsWT(k).tauI_bgI<0)=0;
        ResultsWT(k).kinInt_corr=(coords_kin{k}(:,2));%-mean_coordsBG_kin)./256 ;
        Res_kinInt_corr_WT{k}=(ResultsWT(k).kinInt_corr(:));%./(max(ResultsWT(k).kinInt_corr));
        Res_tauInt_corr_WT{k}=(ResultsWT(k).tauI_bgI(:));%./(max(ResultsWT(k).tauI_bgI));


 end
elseif choose==2
  %datdir = ('/Volumes/ROG/colocalization_data/Kin560_APtau/');
 datdir = ('/Volumes/ROG/colocalization_data/Kif1a_APtau/');

 save_dir = ('/Users/danielbeaudet/Desktop/colocalization_data/');

 plotInt_tau = dir(fullfile(datdir, 'tauInt_*.csv'));
 %plotInt_tau = dir(fullfile(datdir, 'plot_Values_*.csv'));

 plotInt_BG_tau = dir(fullfile(datdir, 'BG_Plot_Values*.csv'));

 plotInt_kin = dir(fullfile(datdir, 'STD*.csv'));
  %plotInt_kin = dir(fullfile(datdir, 'SUM_*.csv'));
  
 plotInt_BG_kin = dir(fullfile(datdir, 'BG_SUM_kin*.csv'));
 ld=numel(plotInt_tau); 
 
 ResultsAP.tauI_bgI=[];
 ResultsAP.kinInt_corr=[];
 
 for k=1:numel(plotInt_tau)
        % reads .csv files of tau intensity and BG profiles
        coords_tauInt{k} = readmatrix(fullfile(datdir,plotInt_tau(k).name));
        coordsBGtau{k} = readmatrix(fullfile(datdir,plotInt_BG_tau(k).name));
        mean_coordsBGtau= mean(coordsBGtau{k}(:,2));
        
        % reads .csv files of kin SUM intensity and BG profiles
        coords_kin{k} = readmatrix(fullfile(datdir,plotInt_kin(k).name));
        coordsBG_kin{k} = readmatrix(fullfile(datdir,plotInt_BG_kin(k).name));
        mean_coordsBG_kin= mean(coordsBG_kin{k}(:,2));

        ResultsAP(k).tauI_bgI=(coords_tauInt{k}(:,2)-mean_coordsBGtau);
         ResultsAP(k).tauI_bgI(ResultsAP(k).tauI_bgI<0)=0;
        ResultsAP(k).kinInt_corr=(coords_kin{k}(:,2));%-mean_coordsBG_kin)./256 ;
        Res_kinInt_corr_AP{k}=(ResultsAP(k).kinInt_corr(:));%./(max(ResultsAP(k).kinInt_corr));
        Res_tauInt_corr_AP{k}=(ResultsAP(k).tauI_bgI(:));%./(max(ResultsAP(k).tauI_bgI));


 end 
 
elseif choose==3
      %datdir = ('/Volumes/ROG/colocalization_data/Kin560_E14tau/');
     datdir = ('/Volumes/ROG/colocalization_data/Kif1a_E14tau/');

 save_dir = ('/Users/danielbeaudet/Desktop/colocalization_data/');
 
 plotInt_tau = dir(fullfile(datdir, 'tauInt_*.csv'));
 %plotInt_tau = dir(fullfile(datdir, 'plot_Values_*.csv'));

 plotInt_BG_tau = dir(fullfile(datdir, 'BG_Plot_Values*.csv'));

 plotInt_kin = dir(fullfile(datdir, 'STD*.csv'));
 % plotInt_kin = dir(fullfile(datdir, 'SUM_*.csv'));
  
  
 plotInt_BG_kin = dir(fullfile(datdir, 'BG_SUM_kin*.csv'));
 ld=numel(plotInt_tau); 
 
 ResultsE14.tauI_bgI=[];
 ResultsE14.kinInt_corr=[];
 
 for k=1:numel(plotInt_tau)
        % reads .csv files of tau intensity and BG profiles
        coords_tauInt{k} = readmatrix(fullfile(datdir,plotInt_tau(k).name));
        coordsBGtau{k} = readmatrix(fullfile(datdir,plotInt_BG_tau(k).name));
        mean_coordsBGtau= mean(coordsBGtau{k}(:,2));
        
        % reads .csv files of kin SUM intensity and BG profiles
        coords_kin{k} = readmatrix(fullfile(datdir,plotInt_kin(k).name));
        coordsBG_kin{k} = readmatrix(fullfile(datdir,plotInt_BG_kin(k).name));
        mean_coordsBG_kin= mean(coordsBG_kin{k}(:,2));

        ResultsE14(k).tauI_bgI=(coords_tauInt{k}(:,2)-mean_coordsBGtau);
         ResultsE14(k).tauI_bgI(ResultsE14(k).tauI_bgI<0)=0;
        ResultsE14(k).kinInt_corr=(coords_kin{k}(:,2));%-mean_coordsBG_kin)./256 ;
        Res_kinInt_corr_E14{k}=(ResultsE14(k).kinInt_corr(:));%./(max(ResultsE14(k).kinInt_corr));
        Res_tauInt_corr_E14{k}=(ResultsE14(k).tauI_bgI(:));%./(max(ResultsE14(k).tauI_bgI));
 end
end
end

  Res_kinInt_WT=vertcat(Res_kinInt_corr_WT{:});
  Res_tauInt_WT=vertcat(Res_tauInt_corr_WT{:});
sum_kinInt_WT=sum(Res_kinInt_WT);


  Res_kinInt_AP=vertcat(Res_kinInt_corr_AP{:});
  Res_tauInt_AP=vertcat(Res_tauInt_corr_AP{:});
sum_kinInt_AP=length(Res_kinInt_AP);

  Res_kinInt_E14=vertcat(Res_kinInt_corr_E14{:});
  Res_tauInt_E14=vertcat(Res_tauInt_corr_E14{:});
sum_kinInt_E14=length(Res_kinInt_E14);




 figure(11), hold on,
 scatter(Res_tauInt_WT,Res_kinInt_WT, 30, 'MarkerFaceColor','g', 'MarkerEdgeColor','g')
xlabel('normalized kinesin Intensity'); ylabel('normalized tau_{Int}/BG_{Int} WT'); xlim([0 256]); ylim([0 256]);
 
figure(22), hold on,
scatter(Res_tauInt_AP,Res_kinInt_AP, 30, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
xlabel('normalized kinesin Intensity'); ylabel('normalized tau_{Int}/BG_{Int} AP'); xlim([0 256]); ylim([0 256]);

 figure(33), hold on,
scatter(Res_tauInt_E14,Res_kinInt_E14, 30, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
xlabel('normalized kinesin Intensity'); ylabel('normalized tau_{Int}/BG_{Int} E14'); xlim([0 256]); ylim([0 256]);



P_WT = corrcoef(Res_kinInt_WT,Res_tauInt_WT);%, 'Type', 'Spearman');
P_AP = corrcoef(Res_kinInt_AP,Res_tauInt_AP);%, 'Type', 'Spearman');
P_E14 = corrcoef(Res_kinInt_E14,Res_tauInt_E14);%, 'Type', 'Spearman');




 nBinsX = [0:16:256];
 nBinsY = [0:16:256];

% nBinsX = [0:0.08:1];
% nBinsY = [0:0.08:1];
[N_wt, xEdges_wt, yEdges_wt] = histcounts2(Res_tauInt_WT, Res_kinInt_WT, ...
                                  nBinsX, nBinsY);

Nfrac_wt = N_wt ./ sum(N_wt(:));

figure(1)
imagesc(xEdges_wt, yEdges_wt, Nfrac_wt)
 axis xy
ylabel('Kin intensity')
xlabel('WT Tau intensity')
colormap("jet");
colorbar
caxis([0 0.008])



[N_ap, xEdges_ap, yEdges_ap] = histcounts2(Res_tauInt_AP, Res_kinInt_AP, ...
                                  nBinsX, nBinsY);

Nfrac_ap = N_ap ./ sum(N_ap(:));

figure(2)
imagesc(xEdges_ap, yEdges_ap, Nfrac_ap)
axis xy
ylabel('Kin intensity')
xlabel('AP Tau intensity')
colormap("jet");
colorbar
caxis([0 0.008])




[N_e, xEdges_e, yEdges_e] = histcounts2(Res_tauInt_E14, Res_kinInt_E14, ...
                                  nBinsX, nBinsY);

Nfrac_e = N_e ./ sum(N_e(:));

figure(3)
imagesc(xEdges_e, yEdges_e, Nfrac_e)
axis xy
ylabel('Kin intensity')
xlabel('E14 Tau intensity')
colormap("jet");
colorbar
caxis([0 0.008])