%% This code will compare the binding kinetic and motility data from single molecule kymograph analysis

clear all; close all; clc; 

clear all, close all
set(0,'DefaultFigureWindowStyle','docked')
addpath('/Users/danielbeaudet/Desktop/MATLAB-Codes_My versions/');
addpath('/Volumes/ROG/Degree_of_Colocalization/');

addpath('/Users/danielbeaudet/Desktop/Abdullah-codes-master-2/General codes 2/raacampbell-notBoxPlot-7d90c27/code/');
addpath('/Users/danielbeaudet/Desktop/Abdullah-codes-master-2/General codes 2/raacampbell-notBoxPlot-7d90c27/code/+NBP/');
addpath('/Users/danielbeaudet/Desktop/Abdullah-codes-master-2/General codes/');
% kymograph parameters
 pixel_size = 0.160;%*2; %um/pixel
 exp_time =  0.20168; %s/frame 1 pixel == 1 frame   
 DT=exp_time; % multiply by a factor of 2 since the image was resized
 kcol=[0 0 1]; 
 mdGrey=[0.5 0.5 0.5];

%  displacement_threshold = 0.25;%.16;%-5;% 0.16 % analysis of all tracks or just motile tracks 
%  max_time_thresh = 40;
 
chos= [1,2,3,4];%,4,5]; %mock, WT, AP, E14
rng(5)

for k_choose = chos

if k_choose==1 % CTL  
    nam= 'MOCK';
 load('mock_7kin1_results.mat', 'binding_kinetics', 'motility_in_patches_results', 'patchFinder_results');
%load('mock_8kif1a_results.mat', 'binding_kinetics', 'motility_in_patches_results', 'patchFinder_results');

pf_mock= patchFinder_results;
bk_mock= binding_kinetics;
mp_mock= motility_in_patches_results;
clear binding_kinetics motility_in_patches_results patchFinder_results;
      
  
elseif k_choose==2 % WT tau 
    nam= 'WT_tau';
  load('WTtau_8kin1_results.mat', 'binding_kinetics', 'motility_in_patches_results', 'patchFinder_results');
%load('WTtau_8kif1a_results.mat', 'binding_kinetics', 'motility_in_patches_results', 'patchFinder_results');

pf_wt= patchFinder_results;
bk_wt= binding_kinetics;
mp_wt= motility_in_patches_results;
clear binding_kinetics motility_in_patches_results patchFinder_results;

        
elseif k_choose==3 % AP tau
    nam= 'AP_tau';
  load('APtau_8kin1_results.mat', 'binding_kinetics', 'motility_in_patches_results', 'patchFinder_results');
%load('APtau_8kif1a_results.mat', 'binding_kinetics', 'motility_in_patches_results', 'patchFinder_results');

pf_ap= patchFinder_results;
bk_ap= binding_kinetics;
mp_ap= motility_in_patches_results;
clear binding_kinetics motility_in_patches_results patchFinder_results;

elseif k_choose==4 % E14 tau
    nam= 'E14_tau';
  load('E14tau_8kin1_results.mat', 'binding_kinetics', 'motility_in_patches_results', 'patchFinder_results');
%load('E14tau_8kif1a_results.mat', 'binding_kinetics', 'motility_in_patches_results', 'patchFinder_results');

pf_e14= patchFinder_results;
bk_e14= binding_kinetics;
mp_e14= motility_in_patches_results;
clear binding_kinetics motility_in_patches_results patchFinder_results;

   
end 

end
%e14
for ui=1:length(bk_e14)
%  bk_e14(ui).k_on_outPatch(isnan(bk_e14(ui).k_on_inPatch))=nan;
%  bk_e14(ui).k_off_outPatch(isnan(bk_e14(ui).k_off_inPatch))=nan;
bk_e14(ui).k_on_inPatch(isnan(bk_e14(ui).k_on_inPatch))=nan;
bk_e14(ui).k_off_inPatch(isnan(bk_e14(ui).k_off_inPatch))=nan;
end

%mock

for oi=1:length(bk_mock)
    bk_mock_k_on_outPatch(oi)=bk_mock(oi).k_on_outPatch.*60;
    bk_mock_k_off_outPatch(oi)=bk_mock(oi).k_off_outPatch.*60;
    bk_mock_k_on_inPatch(oi)=bk_mock(oi).k_on_inPatch.*60;
    bk_mock_k_off_inPatch(oi)=bk_mock(oi).k_off_inPatch.*60;
end

for oi=1:length(bk_wt)
    bk_wt_k_on_outPatch(oi)=bk_wt(oi).k_on_outPatch.*60;
    bk_wt_k_off_outPatch(oi)=bk_wt(oi).k_off_outPatch.*60;
    bk_wt_k_on_inPatch(oi)=bk_wt(oi).k_on_inPatch.*60;
    bk_wt_k_off_inPatch(oi)=bk_wt(oi).k_off_inPatch.*60;
end

for oi=1:length(bk_ap)
    bk_ap_k_on_outPatch(oi)=bk_ap(oi).k_on_outPatch.*60;
    bk_ap_k_off_outPatch(oi)=bk_ap(oi).k_off_outPatch.*60;
    bk_ap_k_on_inPatch(oi)=bk_ap(oi).k_on_inPatch.*60;
    bk_ap_k_off_inPatch(oi)=bk_ap(oi).k_off_inPatch.*60;
end


for oi=1:length(bk_e14)
    bk_e14_k_on_outPatch(oi)=bk_e14(oi).k_on_outPatch.*60;
    bk_e14_k_off_outPatch(oi)=bk_e14(oi).k_off_outPatch.*60;
    bk_e14_k_on_inPatch(oi)=bk_e14(oi).k_on_inPatch.*60;
    bk_e14_k_off_inPatch(oi)=bk_e14(oi).k_off_inPatch.*60;
end



mean_k_on_outPatch_mock = mean(bk_mock_k_on_outPatch);
mean_k_on_inPatch_mock = mean(bk_mock_k_on_inPatch);
mean_k_off_outPatch_mock = mean(bk_mock_k_off_outPatch);
mean_k_off_inPatch_mock = mean(bk_mock_k_off_inPatch);

sem_k_on_outPatch_mock = std(bk_mock_k_on_outPatch)/sqrt(length(bk_mock_k_on_outPatch));
sem_k_on_inPatch_mock = std(bk_mock_k_on_inPatch)/sqrt(length(bk_mock_k_on_inPatch));
sem_k_off_outPatch_mock = std(bk_mock_k_off_outPatch)/sqrt(length(bk_mock_k_off_outPatch));
sem_k_off_inPatch_mock = std(bk_mock_k_off_inPatch)/sqrt(length(bk_mock_k_off_inPatch));
    
%WT tau
mean_k_on_outPatch_wt = mean(bk_wt_k_on_outPatch);%/mean_k_on_outPatch_mock;
mean_k_on_inPatch_wt = mean(bk_wt_k_on_inPatch);%/mean_k_on_outPatch_mock;
mean_k_off_outPatch_wt = mean(bk_wt_k_off_outPatch);%/mean_k_on_outPatch_mock;
mean_k_off_inPatch_wt = mean(bk_wt_k_off_inPatch);%/mean_k_on_outPatch_mock;

sem_k_on_outPatch_wt = std(bk_wt_k_on_outPatch)/sqrt(length(bk_wt_k_on_outPatch));%/mean_k_on_outPatch_mock;
sem_k_on_inPatch_wt = std(bk_wt_k_on_inPatch)/sqrt(length(bk_wt_k_on_inPatch));%/mean_k_on_outPatch_mock;
sem_k_off_outPatch_wt = std(bk_wt_k_off_outPatch)/sqrt(length(bk_wt_k_off_outPatch));%/mean_k_on_outPatch_mock;
sem_k_off_inPatch_wt = std(bk_wt_k_off_inPatch)/sqrt(length(bk_wt_k_off_inPatch));%/mean_k_on_outPatch_mock;

%AP tau
mean_k_on_outPatch_ap = mean(bk_ap_k_on_outPatch);%/mean_k_on_outPatch_mock;
mean_k_on_inPatch_ap = mean(bk_ap_k_on_inPatch);%/mean_k_on_outPatch_mock;
mean_k_off_outPatch_ap = mean(bk_ap_k_off_outPatch);%/mean_k_on_outPatch_mock;
mean_k_off_inPatch_ap = mean(bk_ap_k_off_inPatch);%/mean_k_on_outPatch_mock;

sem_k_on_outPatch_ap = std(bk_ap_k_on_outPatch)/sqrt(length(bk_ap_k_on_outPatch));%/mean_k_on_outPatch_mock;
sem_k_on_inPatch_ap = std(bk_ap_k_on_inPatch)/sqrt(length(bk_ap_k_on_inPatch));%/mean_k_on_outPatch_mock;
sem_k_off_outPatch_ap = std(bk_ap_k_off_outPatch)/sqrt(length(bk_ap_k_off_outPatch));%/mean_k_on_outPatch_mock;
sem_k_off_inPatch_ap = std(bk_ap_k_off_inPatch)/sqrt(length(bk_ap_k_off_inPatch));%/mean_k_on_outPatch_mock;

%E14 tau
mean_k_on_outPatch_e14 = nanmean(bk_e14_k_on_outPatch);%/mean_k_on_outPatch_mock;
mean_k_on_inPatch_e14 = nanmean(bk_e14_k_on_inPatch);%/mean_k_on_outPatch_mock;
mean_k_off_outPatch_e14 = nanmean(bk_e14_k_off_outPatch);%/mean_k_on_outPatch_mock;
mean_k_off_inPatch_e14 = nanmean(bk_e14_k_off_inPatch);%/mean_k_on_outPatch_mock;


sem_k_on_outPatch_e14 = nanstd(bk_e14_k_on_outPatch)/sqrt(length(bk_e14_k_on_outPatch));%/mean_k_on_outPatch_mock;
sem_k_on_inPatch_e14 = nanstd(bk_e14_k_on_inPatch)/sqrt(length(bk_e14_k_on_inPatch));%/mean_k_on_outPatch_mock;
sem_k_off_outPatch_e14 = nanstd(bk_e14_k_off_outPatch)/sqrt(length(bk_e14_k_off_outPatch));%/mean_k_on_outPatch_mock;
sem_k_off_inPatch_e14 = nanstd(bk_e14_k_off_inPatch)/sqrt(length(bk_e14_k_off_inPatch));%/mean_k_on_outPatch_mock;

%bootstrap means
nboot=10000;






% Out Patch
%mock
[bci_k_on_outPatch_mock,bsums_k_on_outPatch_mock] = bootci(nboot,{@nanmean,[bk_mock_k_on_outPatch]},'alpha',.1,'type','per');
bci_k_on_outPatch_mock=bci_k_on_outPatch_mock';
bmu_k_on_outPatch_mock = mean(bsums_k_on_outPatch_mock);

[bci_k_off_outPatch_mock,bsums_k_off_outPatch_mock] = bootci(nboot,{@nanmean,[bk_mock_k_off_outPatch]},'alpha',.1,'type','per');
bci_k_off_outPatch_mock=bci_k_off_outPatch_mock';
bmu_k_off_outPatch_mock = mean(bsums_k_off_outPatch_mock);

%wt
[bci_k_on_outPatch_wt,bsums_k_on_outPatch_wt] = bootci(nboot,{@nanmean,[bk_wt_k_on_outPatch]},'alpha',.1,'type','per');
bci_k_on_outPatch_wt=bci_k_on_outPatch_wt';
bmu_k_on_outPatch_wt = mean(bsums_k_on_outPatch_wt);

[bci_k_off_outPatch_wt,bsums_k_off_outPatch_wt] = bootci(nboot,{@nanmean,[bk_wt_k_off_outPatch]},'alpha',.1,'type','per');
bci_k_off_outPatch_wt=bci_k_off_outPatch_wt';
bmu_k_off_outPatch_wt = mean(bsums_k_off_outPatch_wt);

%ap
[bci_k_on_outPatch_ap,bsums_k_on_outPatch_ap] = bootci(nboot,{@nanmean,[bk_ap_k_on_outPatch]},'alpha',.1,'type','per');
bci_k_on_outPatch_ap=bci_k_on_outPatch_ap';
bmu_k_on_outPatch_ap = mean(bsums_k_on_outPatch_ap);

[bci_k_off_outPatch_ap,bsums_k_off_outPatch_ap] = bootci(nboot,{@nanmean,[bk_ap_k_off_outPatch]},'alpha',.1,'type','per');
bci_k_off_outPatch_ap=bci_k_off_outPatch_ap';
bmu_k_off_outPatch_ap = mean(bsums_k_off_outPatch_ap);

%e14
[bci_k_on_outPatch_e14,bsums_k_on_outPatch_e14] = bootci(nboot,{@nanmean,[bk_e14_k_on_outPatch]},'alpha',.1,'type','per');
bci_k_on_outPatch_e14=bci_k_on_outPatch_e14';
bmu_k_on_outPatch_e14 = mean(bsums_k_on_outPatch_e14);

[bci_k_off_outPatch_e14,bsums_k_off_outPatch_e14] = bootci(nboot,{@nanmean,[bk_e14_k_off_outPatch]},'alpha',.1,'type','per');
bci_k_off_outPatch_e14=bci_k_off_outPatch_e14';
bmu_k_off_outPatch_e14 = mean(bsums_k_off_outPatch_e14);

% IN Patch

%wt
[bci_k_on_inPatch_wt,bsums_k_on_inPatch_wt] = bootci(nboot,{@nanmean,[bk_wt_k_on_inPatch]},'alpha',.1,'type','per');
bci_k_on_inPatch_wt=bci_k_on_inPatch_wt';
bmu_k_on_inPatch_wt = mean(bsums_k_on_inPatch_wt);

[bci_k_off_inPatch_wt,bsums_k_off_inPatch_wt] = bootci(nboot,{@nanmean,[bk_wt_k_off_inPatch]},'alpha',.1,'type','per');
bci_k_off_inPatch_wt=bci_k_off_inPatch_wt';
bmu_k_off_inPatch_wt = mean(bsums_k_off_inPatch_wt);

%ap
[bci_k_on_inPatch_ap,bsums_k_on_inPatch_ap] = bootci(nboot,{@nanmean,[bk_ap_k_on_inPatch]},'alpha',.1,'type','per');
bci_k_on_inPatch_ap=bci_k_on_inPatch_ap';
bmu_k_on_inPatch_ap = mean(bsums_k_on_inPatch_ap);

[bci_k_off_inPatch_ap,bsums_k_off_inPatch_ap] = bootci(nboot,{@nanmean,[bk_ap_k_off_inPatch]},'alpha',.1,'type','per');
bci_k_off_inPatch_ap=bci_k_off_inPatch_ap';
bmu_k_off_inPatch_ap = mean(bsums_k_off_inPatch_ap);



[bci_k_on_inPatch_e14,bsums_k_on_inPatch_e14] = bootci(nboot,{@nanmean,[bk_e14_k_on_inPatch]},'alpha',.1,'type','per');
bci_k_on_inPatch_e14=bci_k_on_inPatch_e14';
bmu_k_on_inPatch_e14 = mean(bsums_k_on_inPatch_e14);

[bci_k_off_inPatch_e14,bsums_k_off_inPatch_e14] = bootci(nboot,{@nanmean,[bk_e14_k_off_inPatch]},'alpha',.1,'type','per');
bci_k_off_inPatch_e14=bci_k_off_inPatch_e14';
bmu_k_off_inPatch_e14 = mean(bsums_k_off_inPatch_e14);



n_resamples=1000;
[pvalue_wt_in_kon_mock, CI]  = bootstrap_test(bsums_k_on_inPatch_wt, bsums_k_on_outPatch_mock, n_resamples) ;
[pvalue_ap_in_kon_mock, CI]  = bootstrap_test(bsums_k_on_inPatch_ap, bsums_k_on_outPatch_mock, n_resamples) ;
[pvalue_e14_in_kon_mock, CI] = bootstrap_test(bsums_k_on_inPatch_e14,bsums_k_on_outPatch_mock, n_resamples) ;

[pvalue_wt_in_koff_mock, CI]  = bootstrap_test(bsums_k_off_inPatch_wt, bsums_k_on_outPatch_mock, n_resamples) ;
[pvalue_ap_in_koff_mock, CI]  = bootstrap_test(bsums_k_off_inPatch_ap, bsums_k_on_outPatch_mock, n_resamples) ;
[pvalue_e14_in_koff_mock, CI] = bootstrap_test(bsums_k_off_inPatch_e14,bsums_k_on_outPatch_mock, n_resamples) ;


[pvalue_wt_out_kon_mock, CI]  = bootstrap_test(bsums_k_on_outPatch_wt, bsums_k_on_outPatch_mock, n_resamples) ;
[pvalue_ap_out_kon_mock, CI]  = bootstrap_test(bsums_k_on_outPatch_ap, bsums_k_on_outPatch_mock, n_resamples) ;
[pvalue_e14_out_kon_mock, CI] = bootstrap_test(bsums_k_on_outPatch_e14,bsums_k_on_outPatch_mock, n_resamples) ;

[pvalue_wt_out_koff_mock, CI]  = bootstrap_test(bsums_k_off_outPatch_wt, bsums_k_on_outPatch_mock, n_resamples) ;
[pvalue_ap_out_koff_mock, CI]  = bootstrap_test(bsums_k_off_outPatch_ap, bsums_k_on_outPatch_mock, n_resamples) ;
[pvalue_e14_out_koff_mock, CI] = bootstrap_test(bsums_k_off_outPatch_e14,bsums_k_on_outPatch_mock, n_resamples) ;


 % Number of bootstrap resamples
    n_resamples = 1000;
    
    for ui=1:length(bk_wt)
       wt_frq_on(ui)= bk_wt(ui).k_on_inPatch./bk_wt(ui).k_on_outPatch;
       wt_frq_off(ui)= bk_wt(ui).k_on_inPatch./bk_wt(ui).k_on_outPatch;

    end
    for ui=1:length(bk_ap)
       ap_frq_on(ui)= bk_ap(ui).k_on_inPatch./bk_ap(ui).k_on_outPatch;
       ap_frq_off(ui)= bk_ap(ui).k_on_inPatch./bk_ap(ui).k_on_outPatch;

    end
    for ui=1:length(bk_e14)
       e14_frq_on(ui)= bk_e14(ui).k_on_inPatch./bk_e14(ui).k_on_outPatch;
       e14_frq_off(ui)= bk_e14(ui).k_on_inPatch./bk_e14(ui).k_on_outPatch;

    end
    
    wt_frq_on=wt_frq_on';
    ap_frq_on=ap_frq_on';
    e14_frq_on=e14_frq_on';
    
    e14_frq_on(isnan(e14_frq_on))=[];
    
    wt_frq_off=wt_frq_off';
    ap_frq_off=ap_frq_off';
    e14_frq_off=e14_frq_off';
    
    e14_frq_off(isnan(e14_frq_off))=[];

    % Perform bootstrap comparisons
    [p_AP_WT_on, CI_AP_WT_on] = bootstrap_test(ap_frq_on, wt_frq_on,  n_resamples);
    [p_E14_WT_on, CI_E14_WT_on] = bootstrap_test(e14_frq_on, wt_frq_on,  n_resamples);
    [p_E14_AP_on, CI_E14_AP_on] = bootstrap_test(e14_frq_on, ap_frq_on,  n_resamples);

    % Display results
    fprintf('ON AP vs WT: p = %.4f, CI = [%.4f, %.4f]\n', p_AP_WT_on, CI_AP_WT_on(1), CI_AP_WT_on(2));
    fprintf('ON E14 vs WT: p = %.4f, CI = [%.4f, %.4f]\n', p_E14_WT_on, CI_E14_WT_on(1), CI_E14_WT_on(2));
    fprintf('ON E14 vs AP: p = %.4f, CI = [%.4f, %.4f]\n', p_E14_AP_on, CI_E14_AP_on(1), CI_E14_AP_on(2));

    
    % Perform bootstrap comparisons
    [p_AP_WT_off, CI_AP_WT_off] = bootstrap_test(ap_frq_off, wt_frq_off,  n_resamples);
    [p_E14_WT_off, CI_E14_WT_off] = bootstrap_test(e14_frq_off, wt_frq_off, n_resamples);
    [p_E14_AP_off, CI_E14_AP_off] = bootstrap_test(e14_frq_off, ap_frq_off, n_resamples);

    % Display results
    fprintf('OFF AP vs WT: p = %.4f, CI = [%.4f, %.4f]\n', p_AP_WT_off, CI_AP_WT_off(1), CI_AP_WT_off(2));
    fprintf('OFF E14 vs WT: p = %.4f, CI = [%.4f, %.4f]\n', p_E14_WT_off, CI_E14_WT_off(1), CI_E14_WT_off(2));
    fprintf('OFF E14 vs AP: p = %.4f, CI = [%.4f, %.4f]\n', p_E14_AP_off, CI_E14_AP_off(1), CI_E14_AP_off(2));

   
    
 %mock
 for gh=1:length(bk_mock_k_on_outPatch)
    kon_out_in(gh,1) = bk_mock_k_on_outPatch(gh)./bk_mock_k_on_outPatch(gh);
%     SEM_mock_kon_out_in   = std(bk_mock_k_on_outPatch./bk_mock_k_on_outPatch) /sqrt(length(bk_mock_k_on_outPatch));
 end
 
    %wt
for gh=1:length(bk_wt_k_on_inPatch)   
    kon_out_in(gh,2)= bk_wt_k_on_inPatch(gh)./bk_wt_k_on_outPatch(gh);
    %SEM_wt_kon_out_in   = std(bk_wt_k_on_inPatch./bk_wt_k_on_outPatch) /sqrt(length(bk_wt_k_on_inPatch));       
end

for gh=1:length(bk_wt_k_off_inPatch)
    kon_out_in(gh,3)= bk_wt_k_off_inPatch(gh)./bk_wt_k_off_outPatch(gh);
    %SEM_wt_koff_out_in   = std(bk_wt_k_off_inPatch./bk_wt_k_off_outPatch) /sqrt(length(bk_wt_k_off_inPatch));
end
    %ap
for gh=1:length(bk_ap_k_on_inPatch)
    kon_out_in(gh,4)= bk_ap_k_on_inPatch(gh)./bk_ap_k_on_outPatch(gh);
    %SEM_ap_kon_out_in   = std(bk_ap_k_on_inPatch./bk_ap_k_on_outPatch) /sqrt(length(bk_ap_k_on_inPatch));
end 

for gh=1:length(bk_ap_k_off_inPatch)
    kon_out_in(gh,5)= bk_ap_k_off_inPatch(gh)./bk_ap_k_off_outPatch(gh);
    %SEM_ap_koff_out_in   = std(bk_ap_k_off_inPatch./bk_ap_k_off_outPatch) /sqrt(length(bk_ap_k_off_inPatch));
end

    %e14
for gh=1:length(bk_e14_k_on_inPatch)
    kon_out_in(gh,6)= bk_e14_k_on_inPatch(gh)./bk_e14_k_on_outPatch(gh);
    %SEM_e14_kon_out_in   = nanstd(bk_e14_k_on_inPatch./bk_e14_k_on_outPatch) /sqrt(length(bk_e14_k_on_inPatch));
end

for gh=1:length(bk_e14_k_off_inPatch)
    kon_out_in(gh,7)= bk_e14_k_off_inPatch(gh)./bk_e14_k_off_outPatch(gh);
    %SEM_e14_koff_out_in   = nanstd(bk_e14_k_off_inPatch./bk_e14_k_off_outPatch) /sqrt(length(bk_e14_k_off_inPatch));
end  


 for fi=length(bk_mock_k_on_outPatch):length(kon_out_in)
     kon_out_in(fi,1)=NaN;
 end
 
for fi=length(bk_wt_k_on_outPatch):length(kon_out_in)
     kon_out_in(fi,2)=NaN;
end
 
for fi=length(bk_wt_k_off_outPatch):length(kon_out_in)
     kon_out_in(fi,3)=NaN;
end

 for fi=length(bk_ap_k_on_outPatch):length(kon_out_in)
     kon_out_in(fi,4)=NaN;
end
 
for fi=length(bk_ap_k_off_outPatch):length(kon_out_in)
     kon_out_in(fi,5)=NaN;
end
 

 
for qi=1:length(bk_mock)
    
    table_Kon(qi,1)= bk_mock(qi).k_on_outPatch.*60;%./mean_k_on_outPatch_mock; 
    table_Kon(qi,2)= bk_mock(qi).k_on_inPatch.*60;%./mean_k_on_outPatch_mock;
      
    table_Koff(qi,1)= bk_mock(qi).k_off_outPatch.*60;%./mean_k_on_outPatch_mock;
    table_Koff(qi,2)= bk_mock(qi).k_off_inPatch.*60;%./mean_k_on_outPatch_mock;
end
    
for qi=1:length(bk_wt)
    
    table_Kon(qi,3)= bk_wt(qi).k_on_outPatch.*60;%./(bk_wt(qi).k_on_outPatch + bk_wt(qi).k_on_inPatch);%./mean_k_on_outPatch_mock; 
    table_Kon(qi,4)= bk_wt(qi).k_on_inPatch.*60;%./(bk_wt(qi).k_on_outPatch + bk_wt(qi).k_on_inPatch);%./mean_k_on_outPatch_mock;
      
    table_Koff(qi,3)= bk_wt(qi).k_off_outPatch.*60;%./(bk_wt(qi).k_off_outPatch + bk_wt(qi).k_off_inPatch);%./mean_k_on_outPatch_mock;
    table_Koff(qi,4)= bk_wt(qi).k_off_inPatch.*60;%./(bk_wt(qi).k_off_outPatch + bk_wt(qi).k_off_inPatch);%./mean_k_on_outPatch_mock;
end
    
for qi=1:length(bk_ap)
    
    table_Kon(qi,5)= bk_ap(qi).k_on_outPatch.*60;%./(bk_ap(qi).k_on_outPatch + bk_ap(qi).k_on_inPatch);%./mean_k_on_outPatch_mock; 
    table_Kon(qi,6)= bk_ap(qi).k_on_inPatch.*60;%./(bk_ap(qi).k_on_outPatch + bk_ap(qi).k_on_inPatch);%./mean_k_on_outPatch_mock;
      
    table_Koff(qi,5)= bk_ap(qi).k_off_outPatch.*60;%./(bk_ap(qi).k_off_outPatch + bk_ap(qi).k_off_inPatch);%./mean_k_on_outPatch_mock;
    table_Koff(qi,6)= bk_ap(qi).k_off_inPatch.*60;%./(bk_ap(qi).k_off_outPatch + bk_ap(qi).k_off_inPatch);%./mean_k_on_outPatch_mock;
end

for qi=1:length(bk_e14)
    
    table_Kon(qi,7)= bk_e14(qi).k_on_outPatch.*60;% ./(bk_e14(qi).k_on_outPatch + bk_e14(qi).k_on_inPatch);%./mean_k_on_outPatch_mock; 
    table_Kon(qi,8)= bk_e14(qi).k_on_inPatch.*60;%./(bk_e14(qi).k_on_outPatch + bk_e14(qi).k_on_inPatch);%./mean_k_on_outPatch_mock;
      
    table_Koff(qi,7)= bk_e14(qi).k_off_outPatch.*60;% ./ (bk_e14(qi).k_off_outPatch + bk_e14(qi).k_off_inPatch);%./mean_k_on_outPatch_mock;
    table_Koff(qi,8)= bk_e14(qi).k_off_inPatch.*60;% ./ (bk_e14(qi).k_off_outPatch + bk_e14(qi).k_off_inPatch);%./mean_k_on_outPatch_mock;
end


 for fi=length(bk_mock):length(table_Kon)
     table_Kon(fi,1)=NaN;
     table_Kon(fi,2)=NaN;
 end
 
  for fi=length(bk_wt):length(table_Kon)
      table_Kon(fi,3)=NaN;
      table_Kon(fi,4)=NaN;
  end
 
   for fi=length(bk_ap):length(table_Kon)
      table_Kon(fi,5)=NaN;
      table_Kon(fi,6)=NaN;
 end

%   for fi=length(bk_e14):length(table_Kon)
%       table_Kon(fi,7)=NaN;
%       table_Kon(fi,8)=NaN;
%   end
 
 for fi=length(bk_mock):length(table_Koff)
     table_Koff(fi,1)=NaN;
     table_Koff(fi,2)=NaN;
 end
 
  for fi=length(bk_wt):length(table_Koff)
      table_Koff(fi,3)=NaN;
      table_Koff(fi,4)=NaN;
  end
 
   for fi=length(bk_ap):length(table_Koff)
      table_Koff(fi,5)=NaN;
      table_Koff(fi,6)=NaN;
 end

%   for fi=length(bk_e14):length(table_Kon)
%       table_Kon(fi,7)=NaN;
%       table_Kon(fi,8)=NaN;
%   end
% table_Kon(table_Kon==0)=nan;
% table_Koff(table_Koff==0)=nan;

%% paired ttest for k_on values
[h_pairedtt_kon_wt_out_in , p_pairedtt_kon_wt_out_in]  = ttest2(bk_wt_k_on_outPatch , bk_wt_k_on_inPatch);
[h_pairedtt_kon_ap_out_in , p_pairedtt_kon_ap_out_in]  = ttest2(bk_ap_k_on_outPatch , bk_ap_k_on_inPatch);
[h_pairedtt_kon_e14_out_in, p_pairedtt_kon_e14_out_in] = ttest2(bk_e14_k_on_outPatch , bk_e14_k_on_inPatch);

[h_pairedtt_koff_wt_out_in , p_pairedtt_koff_wt_out_in]  = ttest2(bk_wt_k_off_outPatch , bk_wt_k_off_inPatch);
[h_pairedtt_koff_ap_out_in , p_pairedtt_koff_ap_out_in]  = ttest2(bk_ap_k_off_outPatch , bk_ap_k_off_inPatch);
[h_pairedtt_koff_e14_out_in, p_pairedtt_koff_e14_out_in] = ttest2(bk_e14_k_off_outPatch , bk_e14_k_off_inPatch);


%% ttest for mean k_on values
% in patches
[h_mean_kon_mock_wt_in , p_mean_kon_mock_wt_in]  = ttest2(bk_mock_k_on_outPatch , bk_wt_k_on_inPatch);
[h_mean_kon_mock_ap_in , p_mean_kon_mock_ap_in]  = ttest2(bk_mock_k_on_outPatch , bk_ap_k_on_inPatch);
[h_mean_kon_mock_e14_in , p_mean_kon_mock_e14_in]  = ttest2(bk_mock_k_on_outPatch , bk_e14_k_on_inPatch);

[h_mean_kon_wt_ap_in , p_mean_kon_wt_ap_in]  = ttest2(bk_wt_k_on_inPatch , bk_ap_k_on_inPatch);
[h_mean_kon_wt_e14_in , p_mean_kon_wt_e14_in]  = ttest2(bk_wt_k_on_inPatch , bk_e14_k_on_inPatch);
[h_mean_kon_ap_e14_in , p_mean_kon_ap_e14_in]  = ttest2(bk_ap_k_on_inPatch , bk_e14_k_on_inPatch);

% out of patches
[h_mean_kon_mock_wt_out , p_mean_kon_mock_wt_out]  = ttest2(bk_mock_k_on_outPatch , bk_wt_k_on_outPatch);
[h_mean_kon_mock_ap_out , p_mean_kon_mock_ap_out]  = ttest2(bk_mock_k_on_outPatch , bk_ap_k_on_outPatch);
[h_mean_kon_mock_e14_out , p_mean_kon_mock_e14_out]  = ttest2(bk_mock_k_on_outPatch , bk_e14_k_on_outPatch);

[h_mean_kon_wt_ap_out , p_mean_kon_wt_ap_out]  = ttest2(bk_wt_k_on_outPatch , bk_ap_k_on_outPatch);
[h_mean_kon_wt_e14_out , p_mean_kon_wt_e14_out]  = ttest2(bk_wt_k_on_outPatch , bk_e14_k_on_outPatch);
[h_mean_kon_ap_e14_out , p_mean_kon_ap_e14_out]  = ttest2(bk_ap_k_on_outPatch , bk_e14_k_on_outPatch);


%% ttest for mean k_off values
% in patches
[h_mean_koff_mock_wt_in , p_mean_koff_mock_wt_in]  = ttest2(bk_mock_k_off_outPatch , bk_wt_k_off_inPatch);
[h_mean_koff_mock_ap_in , p_mean_koff_mock_ap_in]  = ttest2(bk_mock_k_off_outPatch , bk_ap_k_off_inPatch);
[h_mean_koff_mock_e14_in , p_mean_koff_mock_e14_in]  = ttest2(bk_mock_k_off_outPatch , bk_e14_k_off_inPatch);

[h_mean_koff_wt_ap_in , p_mean_koff_wt_ap_in]  = ttest2(bk_wt_k_off_inPatch , bk_ap_k_off_inPatch);
[h_mean_koff_wt_e14_in , p_mean_koff_wt_e14_in]  = ttest2(bk_wt_k_off_inPatch , bk_e14_k_off_inPatch);
[h_mean_koff_ap_e14_in , p_mean_koff_ap_e14_in]  = ttest2(bk_ap_k_off_inPatch , bk_e14_k_off_inPatch);

% out of patches
[h_mean_koff_mock_wt_out , p_mean_koff_mock_wt_out]  = ttest2(bk_mock_k_off_outPatch , bk_wt_k_off_outPatch);
[h_mean_koff_mock_ap_out , p_mean_koff_mock_ap_out]  = ttest2(bk_mock_k_off_outPatch , bk_ap_k_off_outPatch);
[h_mean_koff_mock_e14_out , p_mean_koff_mock_e14_out]  = ttest2(bk_mock_k_off_outPatch , bk_e14_k_off_outPatch);

[h_mean_koff_wt_ap_out , p_mean_koff_wt_ap_out]  = ttest2(bk_wt_k_off_outPatch , bk_ap_k_off_outPatch);
[h_mean_koff_wt_e14_out , p_mean_koff_wt_e14_out]  = ttest2(bk_wt_k_off_outPatch , bk_e14_k_off_outPatch);
[h_mean_koff_ap_e14_out , p_mean_koff_ap_e14_out]  = ttest2(bk_ap_k_off_outPatch , bk_e14_k_off_outPatch);


figure('Name',' notboxplot K_ons','NumberTitle','off')
h1=notBoxPlot(table_Kon);%,'style','patch','jitter',0.5);
%  set(h1.data,'MarkerFaceColor',kcol,'MarkerEdgeColor','k', 'MarkerSize', 8);
%  set(h1.mu, 'Color', 'k', 'LineWidth', 2);
%  set(h1.sdPtch, 'EdgeColor',kcol_grey , 'FaceColor', kcol_grey);
%  set(h1.semPtch,'EdgeColor','b' , 'FaceColor', 'b');
 ylim([0 3.6]);
  %ylim([0 0.015]);

 box on;
 


figure('Name',' K_ons','NumberTitle','off')

% Plot a boxplot for the data
hold on;
boxplot(table_Kon, 'Widths', 0.5, 'Labels',...
    {'K_on out mock', 'K_on in mock', 'K_on out WT', 'K_on in WT',...
    'K_on out AP', 'K_on in AP', 'K_on out E14', 'K_on in E14'}, 'Colors', 'k');

% Overlay paired data points with connecting lines
numPairs = size(table_Kon, 1); % Number of paired data points
for i = 1:numPairs
    plot([1, 2], table_Kon(i, (1:2)), '-o', 'Color', [0.5 0.5 0.5], 'MarkerFaceColor', 'b'); % Connecting lines
    plot([3, 4], table_Kon(i, (3:4)), '-o', 'Color', [0.5 0.5 0.5], 'MarkerFaceColor', 'b'); % Connecting lines
    plot([5, 6], table_Kon(i, (5:6)), '-o', 'Color', [0.5 0.5 0.5], 'MarkerFaceColor', 'b'); % Connecting lines
    plot([7, 8], table_Kon(i, (7:8)), '-o', 'Color', [0.5 0.5 0.5], 'MarkerFaceColor', 'b'); % Connecting lines

end

% Customize plot appearance
xlabel('Conditions');
ylabel('Values');
title('Boxplot with Pairwise Data Points');
set(gca, 'FontSize', 12);
 ylim([0 3.6]); xlim([0 9]);
 % ylim([0 0.015]);xlim([0 9]);

hold off;
    

figure('Name',' notboxplot K_offs','NumberTitle','off')
h1=notBoxPlot(table_Koff);%,'style','patch','jitter',0.5);
%  set(h1.data,'MarkerFaceColor',kcol,'MarkerEdgeColor','k', 'MarkerSize', 8);
%  set(h1.mu, 'Color', 'k', 'LineWidth', 2);
%  set(h1.sdPtch, 'EdgeColor',kcol_grey , 'FaceColor', kcol_grey);
%  set(h1.semPtch,'EdgeColor','b' , 'FaceColor', 'b');
 ylim([0 3.6]);
 %ylim([0 0.015]);
 box on;
 
% Create a figure
figure('Name',' K_offs','NumberTitle','off')

% Plot a boxplot for the data
hold on;
boxplot(table_Koff, 'Widths', 0.5, 'Labels',...
    {'K_{off} out mock', 'K_{off} in mock', 'K_{off} out WT', 'K_{off} in WT',...
    'K_{off} out AP', 'K_{off} in AP', 'K_{off} out E14', 'K_{off} in E14'}, 'Colors', 'k');

% Overlay paired data points with connecting lines
numPairs = size(table_Koff, 1); % Number of paired data points
for i = 1:numPairs
    plot([1, 2], table_Koff(i, (1:2)), '-o', 'Color', [0.5 0.5 0.5], 'MarkerFaceColor', 'b'); % Connecting lines
    plot([3, 4], table_Koff(i, (3:4)), '-o', 'Color', [0.5 0.5 0.5], 'MarkerFaceColor', 'b'); % Connecting lines
    plot([5, 6], table_Koff(i, (5:6)), '-o', 'Color', [0.5 0.5 0.5], 'MarkerFaceColor', 'b'); % Connecting lines
    plot([7, 8], table_Koff(i, (7:8)), '-o', 'Color', [0.5 0.5 0.5], 'MarkerFaceColor', 'b'); % Connecting lines

end

% Customize plot appearance
xlabel('Conditions');
ylabel('Values');
title('Boxplot with Pairwise Data Points');
set(gca, 'FontSize', 12);
  ylim([0 3.6]); xlim([0 9]);
% ylim([0 0.015]); xlim([0 9]);

hold off;
    



function [p_value, CI] = bootstrap_test(data1, data2, n_resamples)

    % Number of samples in each dataset
    n1 = length(data1);
    n2 = length(data2);

    % Preallocate arrays for bootstrapped means
    boot_means1 = zeros(n_resamples, 1);
    boot_means2 = zeros(n_resamples, 1);

    % Perform bootstrap resampling
    for i = 1:n_resamples
        boot_means1(i) = mean(datasample(data1, n1, 'Replace', true));
        boot_means2(i) = mean(datasample(data2, n2, 'Replace', true));
    end

    % Compute the difference of means
    boot_diff = boot_means2 - boot_means1;

    % Compute p-value (fraction of times the difference crosses zero)
    p_value = min(mean(boot_diff <= 0), mean(boot_diff >= 0)) * 2;  % Two-tailed test

    % Compute 95% confidence interval
    CI = prctile(boot_diff, [2.5, 97.5]);
end
